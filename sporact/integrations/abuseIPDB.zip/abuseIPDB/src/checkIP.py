import requests
from sporact_base.sporact_base_action import SporactBaseAction


class CheckIPAction(SporactBaseAction):
    def run(self, ip):
        api_key = self.conf.get("api_key")
        url = "https://api.abuseipdb.com/api/v2/check"
        headers = {
            "Accept": "application/json",
            "Key": "{}".format(api_key),
        }
        params = {"ipAddress": ip}
        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            resp = response.json().get('data', {})
            resp["response_code"] = 200
            return resp
        else:
            return {
                "ipAddress": ip,
                "isPublic": None,
                "ipVersion": None,
                "abuseConfidenceScore": 0,
                "countryCode": "",
                "usageType": "",
                "isp": "",
                "domain": "",
                "totalReports": 0,
                "numDistinctUsers": 0,
                "response_code": 0
            }
