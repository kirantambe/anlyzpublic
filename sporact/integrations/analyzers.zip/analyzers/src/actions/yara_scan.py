from sporact_base.sporact_base_action import SporactBaseAction
import requests
import urllib.parse
import io
import os

class AnalyzRsBaseAction(SporactBaseAction):
    API_ENDPOINT = "/"
    METHOD = "GET"

    def __init__(self, extracontent):
        super().__init__(extracontent)

    def make_request(self, request_data=None, headers=None):
        server = "https://api.analyze.rs/"
        url = f"{server}{self.API_ENDPOINT}"

        headers = {
            "x-api-key": "{}".format(self.conf.get("api_key")),
        }

        response = None
        if self.METHOD == "GET":
            response = requests.get(url, headers=headers, verify=False)

        elif self.METHOD == "POST":
            if request_data:
                for (key, value) in request_data.items():
                    if value == 'None':
                        request_data[key] = None
                if request_data.get('file'):
                    sample = request_data.get('file')
                    response = requests.post(url, files=sample, headers=headers, verify=False)
                else:
                    response = requests.post(url, headers=headers, json=request_data, verify=False)
            else:
                response = requests.post(url, headers=headers, verify=False)

        if not response:
            error_message = f"We encountered an error connecting to the Anlyz API on {server}"
            try:
                if response.status_code == 404:
                    return self.get_empty_response()
                error_message = response.json().get("message")
            except:
                pass

            raise Exception(error_message)

        if response.status_code == 200:
            response_dict = response.json()
            response_dict["response_code"] = response.status_code
            return self.process_result(response_dict)
        raise Exception(f"The Anlyz server returned and invalid response code {response.status_code}")

    def process_result(self, result):
        if "msg" in result:
            raise Exception(result["msg"])
        if type(result) == list:
            return {"results": result}
        return result

    def run(self, headers=None, **request_data):
        return self.make_request( request_data, headers=headers)

    def get_empty_response(self):
        return {}

class YaraScan(AnalyzRsBaseAction):
    API_ENDPOINT = "file/scan/yara"
    METHOD = "POST"

    def get_empty_response(self):
        return {
            "meta": {
                "message": "No signatures were matched"
            },
            "yara_signatures_detected": []
        }

    def run(self, url):
        if url.startswith('/'):
            url = urllib.parse.urljoin(self.SPORACT_URL, url)

        file = requests.get(url)
        attachment = io.BytesIO(file.content)
        files = [
            ('file',(os.path.basename(file.url), attachment, file.headers['Content-type']))
        ]
        return super(YaraScan, self).run(file=files)

