import requests

from sporact_base.sporact_base_action import SporactBaseAction


class AnalyzRsBaseAction(SporactBaseAction):
    API_ENDPOINT = "/"
    METHOD = "GET"

    def __init__(self, extracontent):
        super().__init__(extracontent)

    def make_request(self, request_data=None, headers=None):
        server = "https://api.analyze.rs/"
        url = f"{server}{self.API_ENDPOINT}"

        headers = {
            "x-api-key": "{}".format(self.conf.get("api_key")),
        }

        response = None
        if self.METHOD == "GET":
            response = requests.get(url, headers=headers, verify=False)
        elif self.METHOD == "POST":
            if request_data:
                for (key, value) in request_data.items():
                    if value == 'None':
                        request_data[key] = None
                if request_data.get('file'):
                    sample = request_data.get('file')
                    response = requests.post(url, files=sample, headers=headers, verify=False)
                else:
                    response = requests.post(url, headers=headers, json=request_data, verify=False)
            else:
                response = requests.post(url, headers=headers, verify=False)

        if not response:
            raise Exception(f"We encountered an error connecting to the Analyz API on {server}")

        if response.status_code == 200:
            try:
                response_dict = response.json()
                response_dict["response_code"] = response.status_code
                return self.process_result(response_dict)
            except Exception as e:
                return self.process_result(response.content.decode("utf-8"))
        raise Exception(f"The Anlyz server returned and invalid response code {response.status_code}")

    def process_result(self, result):
        if "msg" in result:
            raise Exception(result["msg"])
        if type(result) == list:
            return {"results": result}
        return result

    def run(self, headers=None, **request_data):
        return self.make_request( request_data, headers=headers)