CONFIG = {
    "conf": {
        "api_key": "16b24ff8db9440c0b080c3ab7c445e0f",
        "server": "https://api.analyze.rs/"
    }
}