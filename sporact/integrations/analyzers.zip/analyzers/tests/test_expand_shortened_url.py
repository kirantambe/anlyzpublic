from src.actions.expand_shortened_url import ExpandShortenedUrl
from .config import CONFIG
import unittest


class TestExpandShortenedUrl(unittest.TestCase):

    def test_expand_shortened_url(self):
        action = ExpandShortenedUrl(CONFIG)
        res = action.run("https://gns.io/1RQl2")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
