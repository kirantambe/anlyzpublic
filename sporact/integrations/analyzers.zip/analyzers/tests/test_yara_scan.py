from src.actions.yara_scan import YaraScan
from .config import CONFIG
import unittest


class TestYaraScan(unittest.TestCase):

    def test_yara_scan(self):
        action = YaraScan(CONFIG)
        res = action.run("http://localhost:8000/virus")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
