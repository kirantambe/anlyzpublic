import requests

from sporact_base.sporact_base_action import SporactBaseAction


class LookupIP(SporactBaseAction):

    def run(self, ip):

        api_url = "https://cde.anlyz.io/ti"
        params = {"ip": ip, "group_by_time": False, "include_paid": True, "limit": 10}
        headers = {"X-API-KEY": self.conf.get("api_key")}
        response = requests.post(api_url, headers=headers, json=params)
        self.LOG.info(f"#############Calling ANLYZ TI with {ip}")
        if response.status_code == 200:
            result = {
                "response_code": response.status_code,
                "results": response.json()
            }
            return result
        else:
            return {"response_code": 0, "results": []}


