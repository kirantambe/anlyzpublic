import requests
from sporact_base.sporact_base_action import SporactBaseAction


class TestIntegration(SporactBaseAction):
    def run(self, conf, inputs):
        # Domain format should be google.com. Just google will not work
        search_text = inputs[0]["value"]
        params = {"search": search_text}
        headers = {"X-API-KEY": conf.get("api_key")}

        url = "https://cde.anlyz.io/ti"
        response = requests.post(url, headers=headers, json=params)
        if response.status_code == 200:
            response_dict = (("message", "Successfully tested the configuration!"), ("status", "success"))
        else:
            response_dict = (("message", "Invalid configuration!"), ("status", "failed"))
        return response_dict
