import requests
import time
from sporact_base.sporact_base_action import SporactBaseAction


class ScanURLAction(SporactBaseAction):

    def get_insights_url(self, url):
        api_url = "https://developers.checkphish.ai/api/neo/scan/status"
        data = {
            "apiKey": self.conf.get("api_key"),
            "jobID": job_id,
            "insights": True,
        }
        response = requests.post(api_url, json=data).json()
        if "status" in response and response.get("status", "") == "DONE":
            return response.get("insights", "")

    def submit_url(self, url):
        api_url = "https://developers.checkphish.ai/api/neo/scan"
        data = {"apiKey": self.conf.get("api_key"), "urlInfo": {"url": url}}
        response = requests.post(api_url, json=data).json()
        if "jobID" not in response:
            raise Exception("URL not accepted by checkphish")

        return response.get("jobID")

    def get_insights(self, insights_url):
        api_url = "https://checkphish.ai/api/v2/insights/url/"
        final_url = f"{api_url}{'/'.join(insights_url.split('/')[-2:])}"
        response = requests.get(final_url).json()
        if response.status_code == 200:
            scan_results = response.json().get("scanResults")
            return {
                "host": scan_results.get("host", ""),
                "cryptominingApps": scan_results.get("cryptominingApps", ""),
                "siteTitle": scan_results.get("siteTitle", ""),
                "disposition": scan_results.get("disposition", ""),
                "dstUrl": scan_results.get("dstUrl", ""),
                "createdTS": scan_results.get("createdTS", ""),
                "primary_domain": scan_results.get("primary_domain", ""),
                "firstSeenTS": scan_results.get("firstSeenTS", ""),
                "ip": scan_results.get("ip", ""),
                "timestamp": scan_results.get("timestamp", ""),
                "srcUrl": scan_results.get("srcUrl", ""),
                "country": scan_results.get("country", ""),
                "countryCode": scan_results.get("countryCode", ""),
                "networkOwner": scan_results.get("networkOwner", ""),
                "asn": scan_results.get("asn", ""),
                "brandId": scan_results.get("brandId", ""),
                "brandName": scan_results.get("brandName", ""),
                "brandSeoPath": scan_results.get("brandSeoPath", ""),
                "urlSHA256": scan_results.get("urlSHA256", ""),
                "cert": scan_results.get("cert", ""),
            }
        raise Exception("Failed to get insights for the url")

    def run(self, url):
        max_retries = 5
        retries_done = 0
        job_id = self.submit_url(url)

        while retries_done < max_retries:
            insights_url = self.get_insights_url(job_id)
            if insights_url:
                return self.get_insights(insights_url)
            else:
                time.sleep(2)
                retries_done += 1

        raise Exception("Max retries exceeded but still couldn't get insights")



