import requests
from sporact_base.sporact_base_action import SporactBaseAction


class TestIntegration(SporactBaseAction):
    def run(self, conf, inputs):
        # Domain format should be google.com. Just google will not work
        url = inputs[0]["value"]
        data = {"apiKey": conf.get("api_key"), "urlInfo": {"url": url}}

        api_url = "https://developers.checkphish.ai/api/neo/scan"
        response = requests.post(api_url, json=data)
        if response.status_code == 200:
            if "errorMessage" in response.json():
                response_dict = (("message", "Invalid configuration!"), ("status", "failed"))
                return response_dict
            response_dict = (("message", "Successfully tested the configuration!"), ("status", "success"))
        else:
            response_dict = (("message", "Invalid configuration!"), ("status", "failed"))
        return response_dict

