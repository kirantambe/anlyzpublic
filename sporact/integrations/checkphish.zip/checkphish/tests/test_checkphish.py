from src.checkphish import CheckPhishAction
from .config import CHECKPHISH_API_KEY
import unittest


class TestCheckPhishAction(unittest.TestCase):
    def test_query_ip(self):
        action = CheckPhishAction({"api_key": CHECKPHISH_API_KEY})
        res = action.run("http://webidlogin101997.5gbfree.com/")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
