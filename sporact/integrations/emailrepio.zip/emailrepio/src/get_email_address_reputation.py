from sporact_base.sporact_base_action import SporactBaseAction
import requests
import json


class GetEmailAddressreputation(SporactBaseAction):

    def __init__(self, extracontent):
        super().__init__(extracontent)

    def run(self, email):
        api_key, url = self.conf.get(
            "api_key"), self.conf.get("url")

        header = {
            "Content-Type": "application/json",
            "Key": api_key
        }
        
        try:
            response = requests.get(url + email, headers=header)
            response = response.text
            response = {"EmailRepIO_GetEmailAddressReputation_output": response}
        except Exception as e:
            response = {"EmailRepIO_GetEmailAddressReputation_output": {"Error": f"{e}"} }
        
        return response