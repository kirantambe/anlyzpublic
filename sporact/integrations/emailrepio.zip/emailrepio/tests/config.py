GET_EMAIL_ADDRESS_REPUTATION = {
      "conf": {
            "url": "https://emailrep.io/",
            "api_key": "z7737ybc76esbwvrvev4p0uum48pys5mnkmb8pzbrr724ps4",
            "params" : {
                "email" : "bhargavdesai.1907@gmail.com"
            }
      }
}