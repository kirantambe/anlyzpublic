import unittest


class TestGetEmailAddressReputation(unittest.TestCase):
    def test_get_email_address_reputation(self):
        import sys
        sys.path.append('../emailrep_io/')

        from tests.config import GET_EMAIL_ADDRESS_REPUTATION
        from src.get_email_address_reputation import GetEmailAddressreputation
        email = GET_EMAIL_ADDRESS_REPUTATION['conf']['params']['email']
        action = GetEmailAddressreputation(GET_EMAIL_ADDRESS_REPUTATION)
        action_response = action.run(email=email)
        # self.assertTrue("response_code" in action_response,
        #                 'error in response')
        # self.assertEqual(action_response.get("response_code"),
        #                  200, "status code is not 200")
