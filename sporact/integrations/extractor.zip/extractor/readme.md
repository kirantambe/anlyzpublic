# ExtractorIntegrations Integration

**Product Name**: ExtractorIntegrations

**Version**: 

## Actions

### Action: extractor.ip_extractor

#### Action Type: MISTRAL

#### Description: 
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| text | string | None | The text content|

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| ips | array | A list of IP addresses|

### Action: extractor.url_extractor

#### Action Type: MISTRAL

#### Description: 
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| text | string | None | The text content|
| remove_query_params | boolean | None | Indicates if query parameters should be removed from URLs|

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| urls | array | A list of URLs|

### Action: extractor.domain_extractor

#### Action Type: MISTRAL

#### Description: 
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| text | string | None | The text content|

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| domains | array | A list of domain names|

### Action: extractor.email_extractor

#### Action Type: MISTRAL

#### Description: 
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| text | string | None | The text content|

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| emails | array | A list of email addresses|

