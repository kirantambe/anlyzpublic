from urllib.parse import urlsplit

import iocextract
from sporact_base.sporact_base_action import SporactBaseAction


class DomainExtractorAction(SporactBaseAction):
    def run(self, text):
        domains = []
        if not isinstance(text, str):
            text = str(text)

        domains = [email.split("@")[-1] for email in iocextract.extract_emails(text)]

        for email in iocextract.extract_emails(text):
            try:
                domains.append(email.split("@")[-1])
            except:
                pass

        for url in iocextract.extract_urls(text, refang=True):
            try:
                domains.append(urlsplit(url).hostname)
            except:
                pass

        return {"domains": domains}
