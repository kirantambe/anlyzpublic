import os
import pathlib
from urllib.parse import urlsplit
import re
import json
import iocextract
from sporact_base.sporact_base_action import SporactBaseAction


class DomainExtractorAction(SporactBaseAction):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Load TLDs once during initialization
        cur_dir = pathlib.Path(__file__).parent.resolve()
        file_path = os.path.join(cur_dir, "domains.json")
        with open(file_path) as f:
            self.TLDS = json.load(f)

    def _is_valid_domain(self, domain):
        if not domain:
            return False
        try:
            # Check if domain follows basic domain format
            if not re.match(r'^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$', domain):
                return False
            # Check if TLD is valid
            return domain.split(".")[-1] in self.TLDS
        except Exception:
            return False

    def run(self, text):
        if not isinstance(text, str):
            text = str(text)

        # Replacing HTML tags with spaces
        cleaned_text = re.sub("<.*?>", " ", text)
        # Normalizing spaces
        cleaned_text = re.sub(r'\s+', ' ', cleaned_text)

        seen = set()
        unique_domains = []

        # Extract domains from emails
        for email in iocextract.extract_emails(cleaned_text):
            try:
                domain = email.split("@")[-1]
                if domain not in seen and self._is_valid_domain(domain):
                    seen.add(domain)
                    unique_domains.append(domain)
            except Exception:
                continue

        # Extract domains from URLs
        for url in iocextract.extract_urls(cleaned_text, refang=True):
            try:
                domain = urlsplit(url).hostname
                if domain and domain not in seen and self._is_valid_domain(domain):
                    seen.add(domain)
                    unique_domains.append(domain)
            except Exception:
                continue

        # Extract standalone domains
        domain_pattern = r'(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6}'
        for domain in re.findall(domain_pattern, cleaned_text):
            if domain not in seen and self._is_valid_domain(domain):
                seen.add(domain)
                unique_domains.append(domain)

        return {"domains": unique_domains}
