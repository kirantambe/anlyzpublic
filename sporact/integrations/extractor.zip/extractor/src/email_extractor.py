import iocextract
from sporact_base.sporact_base_action import SporactBaseAction


class EmailExtractorAction(SporactBaseAction):
    def run(self, text):
        if not isinstance(text, str):
            text = str(text)
        return {
            "emails": [email for email in iocextract.extract_emails(text, refang=True)]
        }
