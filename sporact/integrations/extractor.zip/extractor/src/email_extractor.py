import iocextract
from sporact_base.sporact_base_action import SporactBaseAction
import re

class EmailExtractorAction(SporactBaseAction):
    def _is_valid_email(self, email):
        try:
            # Basic email validation pattern
            pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
            return bool(re.match(pattern, email))
        except Exception:
            return False

    def run(self, text):
        if not isinstance(text, str):
            text = str(text)

        # Replacing HTML tags with spaces
        cleaned_text = re.sub("<.*?>", " ", text)
        # Normalizing spaces
        cleaned_text = re.sub(r'\s+', ' ', cleaned_text)

        # Extract emails and remove duplicates while preserving order
        seen = set()
        unique_emails = []
        for email in iocextract.extract_emails(cleaned_text, refang=True):
            if email not in seen and self._is_valid_email(email):
                seen.add(email)
                unique_emails.append(email)

        return {"emails": unique_emails}
