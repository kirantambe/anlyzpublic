import iocextract
from sporact_base.sporact_base_action import SporactBaseAction
import re
import ipaddress


class IPExtractorAction(SporactBaseAction):
    def _is_valid_ip(self, ip_str):
        try:
            # Remove any leading/trailing whitespace
            ip_str = ip_str.strip()
            # Try to create an IP address object - this will validate the format
            ipaddress.ip_address(ip_str)
            # Additional check to ensure it matches IPv4 format (x.x.x.x)
            if not re.match(r'^(?:\d{1,3}\.){3}\d{1,3}$', ip_str):
                return False
            return True
        except ValueError:
            return False

    def run(self, text):
        if not isinstance(text, str):
            text = str(text)
            
        # Replacing HTML tags with spaces
        cleaned_text = re.sub("<.*?>", " ", text)
        # Normalizing newlines
        cleaned_text = re.sub(r'\s+', ' ', cleaned_text)
        # Add space before periods at end of lines to separate them from IPs
        cleaned_text = re.sub(r'\.(?=\s|$)', ' .', cleaned_text)
        
        # Extract IPs and remove duplicates while preserving order
        seen = set()
        unique_ips = []
        for ip in iocextract.extract_ips(cleaned_text, refang=True):
            if ip not in seen and self._is_valid_ip(ip):
                seen.add(ip)
                unique_ips.append(ip)
                
        return {"ips": unique_ips}
