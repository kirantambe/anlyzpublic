import iocextract
from sporact_base.sporact_base_action import SporactBaseAction


class IPExtractorAction(SporactBaseAction):
    def run(self, text):
        if not isinstance(text, str):
            text = str(text)
        return {"ips": [ip for ip in iocextract.extract_ips(text, refang=True)]}
