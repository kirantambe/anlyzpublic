import iocextract
from sporact_base.sporact_base_action import SporactBaseAction
import re
from urllib.parse import urlparse


class UrlExtractorAction(SporactBaseAction):
    def _is_valid_url(self, url):
        try:
            # Parse the URL
            result = urlparse(url)
            # Check if we have at least a scheme and netloc (domain)
            return all([result.scheme, result.netloc])
        except Exception:
            return False

    def run(self, text, remove_query_params=False):
        if not isinstance(text, str):
            text = str(text)

        # Replacing HTML tags with spaces
        cleaned_text = re.sub("<.*?>", " ", text)
        # Normalizing spaces
        cleaned_text = re.sub(r'\s+', ' ', cleaned_text)

        seen = set()
        unique_urls = []
        for url in iocextract.extract_urls(cleaned_text, refang=True):
            if remove_query_params:
                url = url.split("?")[0]
            
            if url not in seen and self._is_valid_url(url):
                seen.add(url)
                unique_urls.append(url)

        return {"urls": unique_urls}
