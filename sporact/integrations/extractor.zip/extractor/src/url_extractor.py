import iocextract
from sporact_base.sporact_base_action import SporactBaseAction


class UrlExtractorAction(SporactBaseAction):
    def run(self, text):
        if not isinstance(text, str):
            text = str(text)

        urls = [url for url in iocextract.extract_urls(text, refang=True)]
        # if remove_query_params:
        urls = [url.split("?")[0] for url in urls]
        return {"urls": urls}
