from src.domain_extractor import DomainExtractorAction
import unittest


class TestDomainExtractorAction(unittest.TestCase):
    def test_domain_extractor(self):
        action = DomainExtractorAction(conf={})
        res = action.run(
            "I really love example[.]com!"
            "All the bots are on hxxp://example.com/bad/url these days."
            "C2: tcp://example[.]com:8989/bad"
        )
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get('response_code'), 200)
