from src.email_extractor import EmailExtractorAction
import unittest


class TestEmailExtractorAction(unittest.TestCase):
    def test_ip_extractor(self):
        action = EmailExtractorAction(conf={})
        res = action.run(
            "me@example.com hello"
        )
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get('response_code'), 200)
