from src.ip_extractor import IPExtractorAction
import unittest


class TestIPExtractorAction(unittest.TestCase):
    def test_ip_extractor(self):
        action = IPExtractorAction(conf={})
        res = action.run(
            "2001:cdba:0000:0000:0000:0000:3257:9652 ff01:0:0:0:0:0:0:2 hello 192.168.12.24"
        )
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get('response_code'), 200)
