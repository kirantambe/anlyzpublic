import json

from .base_fortigate_action import BaseFortigateAction
import requests
import logging


class GetAddressGroupAction(BaseFortigateAction):
    def run(self, conf_name, group_name):
        api_url = f"api/v2/cmdb/firewall/addrgrp/{group_name}"
        results = self.get(conf_name, api_url)
        return {"results": results}


class GetAddressGroupsAction(BaseFortigateAction):
    def run(self, conf_name):
        api_url = f"api/v2/cmdb/firewall/addrgrp/"
        results = self.get(conf_name, api_url)
        return {"results": results}


class UpdateAddressGroupAction(BaseFortigateAction):
    def run(self, conf_name, group_name, data):
        if isinstance(data, str):
            data = json.loads(data)

        api_url = "api/v2/cmdb/firewall/addrgrp/" + requests.utils.quote(
            group_name, safe=""
        )
        if not self.does_exist(conf_name, api_url):
            logging.error(
                f'Requested address group "{group_name}" does not exist in Firewall config.'
            )
            raise Exception(f"{group_name} does not exist")
        result = self.put(conf_name, api_url, data)
        return result


class CreateAddressGroupAction(BaseFortigateAction):
    def run(self, conf_name, group_name, data):
        if isinstance(data, str):
            data = json.loads(data)

        api_url = "api/v2/cmdb/firewall/addrgrp/"
        if self.does_exist(conf_name, api_url + group_name):
            raise Exception(f"{group_name} already exists")
        result = self.post(conf_name, api_url, data)
        return result


class DeleteAddressGroupAction(BaseFortigateAction):
    def run(self, conf_name, group_name):
        api_url = "api/v2/cmdb/firewall/addrgrp/" + group_name
        result = self.delete(conf_name, api_url)
        return result
