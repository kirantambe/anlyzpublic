from .base_fortigate_action import BaseFortigateAction
import requests
import logging
import json


class GetFirewallAddressAction(BaseFortigateAction):
    def run(self, conf_name, name):
        api_url = f"api/v2/cmdb/firewall/address/{name}"
        results = self.get(conf_name, api_url)
        result = results[0]
        return {
            "q_origin_key": result.get("q_origin_key", ""),
            "name": result.get("name", ""),
            "uuid": result.get("uuid", ""),
            "subnet": result.get("subnet", ""),
            "type": result.get("type", ""),
            "start-ip": result.get("start-ip", ""),
            "end-ip": result.get("end-ip", ""),
            "fqdn": result.get("fqdn", ""),
            "country": result.get("country", ""),
            "wildcard-fqdn": result.get("wildcard-fqdn", ""),
            "cache-ttl": result.get("cache-ttl", ""),
            "wildcard": result.get("wildcard", ""),
            "sdn": result.get("sdn", ""),
            "tenant": result.get("tenant", ""),
            "organization": result.get("organization", ""),
            "epg-name": result.get("epg-name", ""),
            "subnet-name": result.get("subnet-name", ""),
            "sdn-tag": result.get("sdn-tag", ""),
            "policy-group": result.get("policy-group", ""),
            "comment": result.get("comment", ""),
            "visibility": result.get("visibility", ""),
            "associated-interface": result.get("associated-interface", ""),
            "color": result.get("color", ""),
            "filter": result.get("filter", ""),
            "obj-id": result.get("obj-id", ""),
            "list": result.get("list", ""),
            "tagging": result.get("tagging", ""),
            "allow-routing": result.get("allow-routing", ""),
        }


class GetFirewallAddressesAction(BaseFortigateAction):
    def run(self, conf_name):
        api_url = f"api/v2/cmdb/firewall/address/"
        results = self.get(conf_name, api_url)
        return results


class UpdateFirewallAddressAction(BaseFortigateAction):
    def run(self, conf_name, name, data):
        if isinstance(data, str):
            data = json.loads(data)

        api_url = "api/v2/cmdb/firewall/address/" + requests.utils.quote(name, safe="")
        if not self.does_exist(conf_name, api_url):
            logging.error(
                f'Requested address "{name}" does not exist in Firewall config.'
            )
            raise Exception(f"{name} does not exist")
        result = self.put(conf_name, api_url, data)
        return {"status": result.get("status")}


class CreateFirewallAddressAction(BaseFortigateAction):
    def run(self, conf_name, name, data):
        if isinstance(data, str):
            data = json.loads(data)

        api_url = "api/v2/cmdb/firewall/address/"
        if self.does_exist(conf_name, api_url + name):
            raise Exception(f"{name} already exists")
        result = self.post(conf_name, api_url, data)
        return {"status": result.get("status")}


class DeleteFirewallAddressAction(BaseFortigateAction):
    def run(self, conf_name, name):
        api_url = "api/v2/cmdb/firewall/address/" + name
        result = self.delete(conf_name, api_url)
        return {"status": result.get("status")}
