import json

from .base_fortigate_action import BaseFortigateAction
import requests
import logging


class GetFirewallPolicyAction(BaseFortigateAction):
    def run(self, conf_name, policy_id):
        api_url = f"api/v2/cmdb/firewall/policy/{policy_id}"
        results = self.get(conf_name, api_url)
        return results


class GetFirewallPoliciesAction(BaseFortigateAction):
    def run(self, conf_name):
        api_url = f"api/v2/cmdb/firewall/policy/"
        results = self.get(conf_name, api_url)
        return results

# TODO: Move Policy


class UpdateFirewallPolicyAction(BaseFortigateAction):
    def run(self, conf_name, policy_id, data):
        if isinstance(data, str):
            data = json.loads(data)

        api_url = "api/v2/cmdb/firewall/policy/" + requests.utils.quote(
            policy_id, safe=""
        )
        if not self.does_exist(conf_name, api_url):
            logging.error(
                f'Requested policy "{policy_id}" does not exist in Firewall config.'
            )
            raise Exception(f"{policy_id} does not exist")
        result = self.put(conf_name, api_url, data)
        return result


class CreateFirewallPolicyAction(BaseFortigateAction):
    def run(self, conf_name, policy_id, data):
        if isinstance(data, str):
            data = json.loads(data)

        api_url = "api/v2/cmdb/firewall/policy/"
        if self.does_exist(conf_name, api_url + policy_id):
            raise Exception(f"{policy_id} already exists")
        result = self.post(conf_name, api_url, data)
        return result


class DeleteFirewallPolicyAction(BaseFortigateAction):
    def run(self, conf_name, policy_id):
        api_url = "api/v2/cmdb/firewall/policy/" + policy_id
        result = self.delete(conf_name, api_url)
        return result
