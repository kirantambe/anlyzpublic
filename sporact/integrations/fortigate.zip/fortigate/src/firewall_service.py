import json

from .base_fortigate_action import BaseFortigateAction
import requests
import logging


class GetFirewallServiceAction(BaseFortigateAction):
    def run(self, conf_name, service_name):
        api_url = f"api/v2/cmdb/firewall.service/custom/{service_name}"
        results = self.get(conf_name, api_url)
        return results


class GetFirewallServicesAction(BaseFortigateAction):
    def run(self, conf_name):
        api_url = f"api/v2/cmdb/firewall.service/custom/"
        results = self.get(conf_name, api_url)
        return results


class UpdateFirewallServiceAction(BaseFortigateAction):
    def run(self, conf_name, service_name, data):
        if isinstance(data, str):
            data = json.loads(data)

        api_url = "api/v2/cmdb/firewall.service/custom/" + requests.utils.quote(
            service_name, safe=""
        )
        if not self.does_exist(conf_name, api_url):
            logging.error(
                f'Requested service "{service_name}" does not exist in Firewall config.'
            )
            raise Exception(f"{service_name} does not exist")
        result = self.put(conf_name, api_url, data)
        return result


class CreateFirewallServiceAction(BaseFortigateAction):
    def run(self, conf_name, service_name, data):
        if isinstance(data, str):
            data = json.loads(data)

        api_url = "api/v2/cmdb/firewall.service/custom/"
        if self.does_exist(conf_name, api_url + service_name):
            raise Exception(f"{service_name} already exists")
        result = self.post(conf_name, api_url, data)
        return result


class DeleteFirewallServiceAction(BaseFortigateAction):
    def run(self, conf_name, service_name):
        api_url = "api/v2/cmdb/firewall.service/custom/" + service_name
        result = self.delete(conf_name, api_url)
        return result
