from .base_fortigate_action import BaseFortigateAction
import requests
import logging


class GetInternetServiceAction(BaseFortigateAction):
    def run(self, conf_name, service_name):
        api_url = f"api/v2/cmdb/firewall/internet-service/{service_name}"
        results = self.get(conf_name, api_url)
        return results


class GetInternetServicesAction(BaseFortigateAction):
    def run(self, conf_name):
        api_url = f"api/v2/cmdb/firewall/internet-service/"
        results = self.get(conf_name, api_url)
        return results
