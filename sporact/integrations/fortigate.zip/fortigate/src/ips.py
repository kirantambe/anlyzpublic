from .base_fortigate_action import BaseFortigateAction
import requests
import logging


class BanIPAction(BaseFortigateAction):
    def run(self, ip):
        api_url = f"api/v2/monitor/user/banned/add_users/"
        payload = {
            'ip_addresses': [ip,],
            'expiry': 0
        }
        results = self.post(api_url, payload)
        return results


class UnbanIPAction(BaseFortigateAction):
    def run(self, ip):
        api_url = f"api/v2/monitor/user/banned/clear_users/"
        payload = {
            'ip_addresses': [ip, ]
        }
        results = self.post(api_url, payload)
        return results
