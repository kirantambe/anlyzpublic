import json

from .base_fortigate_action import BaseFortigateAction
import requests
import logging


class GetServiceCategoryAction(BaseFortigateAction):
    def run(self, conf_name, category):
        api_url = f"api/v2/cmdb/firewall.service/category/{category}"
        results = self.get(conf_name, api_url)
        return results


class GetServiceCategoriesAction(BaseFortigateAction):
    def run(self, conf_name):
        api_url = f"api/v2/cmdb/firewall.service/category/"
        results = self.get(conf_name, api_url)
        return results


class UpdateServiceCategoryAction(BaseFortigateAction):
    def run(self, conf_name, category, data):
        if isinstance(data, str):
            data = json.loads(data)

        api_url = "api/v2/cmdb/firewall.service/category/" + requests.utils.quote(
            category, safe=""
        )
        if not self.does_exist(conf_name, api_url):
            logging.error(
                f'Requested address "{category}" does not exist in Firewall config.'
            )
            raise Exception(f"{category} does not exist")
        result = self.put(conf_name, api_url, data)
        return result


class CreateServiceCategoryAction(BaseFortigateAction):
    def run(self, conf_name, category, data):
        if isinstance(data, str):
            data = json.loads(data)

        api_url = "api/v2/cmdb/firewall.service/category/"
        if self.does_exist(conf_name, api_url + category):
            raise Exception(f"{category} already exists")
        result = self.post(conf_name, api_url, data)
        return result


class DeleteServiceCategoryAction(BaseFortigateAction):
    def run(self, conf_name, category):
        api_url = "api/v2/cmdb/firewall.service/category/" + category
        result = self.delete(conf_name, api_url)
        return result
