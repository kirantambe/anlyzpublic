import json

from .base_fortigate_action import BaseFortigateAction
import requests
import logging


class GetServiceGroupAction(BaseFortigateAction):
    def run(self, conf_name, group_name):
        api_url = f"api/v2/cmdb/firewall.service/group/{group_name}"
        results = self.get(conf_name, api_url)
        return results


class GetServiceGroupsAction(BaseFortigateAction):
    def run(self, conf_name):
        api_url = f"api/v2/cmdb/firewall.service/group/"
        results = self.get(conf_name, api_url)
        return results


class UpdateServiceGroupAction(BaseFortigateAction):
    def run(self, conf_name, group_name, data):
        if isinstance(data, str):
            data = json.loads(data)

        api_url = "api/v2/cmdb/firewall.service/group/" + requests.utils.quote(
            group_name, safe=""
        )
        if not self.does_exist(conf_name, api_url):
            logging.error(
                f'Requested service group "{group_name}" does not exist in Firewall config.'
            )
            raise Exception(f"{group_name} does not exist")
        result = self.put(conf_name, api_url, data)
        return result


class CreateServiceGroupAction(BaseFortigateAction):
    def run(self, conf_name, group_name, data):
        if isinstance(data, str):
            data = json.loads(data)

        api_url = "api/v2/cmdb/firewall.service/group/"
        if self.does_exist(conf_name, api_url + group_name):
            raise Exception(f"{group_name} already exists")
        result = self.post(conf_name, api_url, data)
        return result


class DeleteServiceGroupAction(BaseFortigateAction):
    def run(self, conf_name, group_name):
        api_url = "api/v2/cmdb/firewall.service/group/" + group_name
        result = self.delete(conf_name, api_url)
        return result
