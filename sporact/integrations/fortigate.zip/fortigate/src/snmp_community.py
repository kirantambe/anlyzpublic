import json

from .base_fortigate_action import BaseFortigateAction
import requests
import logging


class GetSNMPCommunityAction(BaseFortigateAction):
    def run(self, conf_name, community_id):
        api_url = f"api/v2/cmdb/system.snmp/community/{community_id}"
        results = self.get(conf_name, api_url)
        return results


class GetSNMPCommunitiesAction(BaseFortigateAction):
    def run(self, conf_name):
        api_url = f"api/v2/cmdb/system.snmp/community/"
        results = self.get(conf_name, api_url)
        return results


class UpdateSNMPCommunityAction(BaseFortigateAction):
    def run(self, conf_name, community_id, data):
        if isinstance(data, str):
            data = json.loads(data)

        api_url = "api/v2/cmdb/system.snmp/community/" + requests.utils.quote(
            community_id, safe=""
        )
        if not self.does_exist(conf_name, api_url):
            logging.error(
                f'Requested community "{community_id}" does not exist in Firewall config.'
            )
            raise Exception(f"{community_id} does not exist")
        result = self.put(conf_name, api_url, data)
        return result


class CreateSNMPCommunityAction(BaseFortigateAction):
    def run(self, conf_name, community_id, data):
        if isinstance(data, str):
            data = json.loads(data)

        api_url = "api/v2/cmdb/system.snmp/community/"
        if self.does_exist(conf_name, api_url + community_id):
            raise Exception(f"{community_id} already exists")
        result = self.post(conf_name, api_url, data)
        return result


class DeleteSNMPCommunityAction(BaseFortigateAction):
    def run(self, conf_name, community_id):
        api_url = "api/v2/cmdb/system.snmp/community/" + community_id
        result = self.delete(conf_name, api_url)
        return result
