from src.firewall_address import (
    GetFirewallAddressesAction,
    GetFirewallAddressAction,
    DeleteFirewallAddressAction,
    CreateFirewallAddressAction,
    UpdateFirewallAddressAction,
)
import unittest


class TestGetFirewallAddressesAction(unittest.TestCase):
    test_config = {
        "conf": {
            "default": {
                "ipaddr": "10.10.10.253",
                "username": "admin",
                "password": "",
                "port": 443,
            }
        }
    }

    def test_get_addresses(self):
        action = GetFirewallAddressesAction(self.test_config)
        res = action.run("default")
        assert type(res) == list

    def test_get_address(self):
        action = GetFirewallAddressAction(
            {
                "conf": {
                    "default": {
                        "ipaddr": "10.10.10.253",
                        "username": "admin",
                        "password": "",
                        "port": 443,
                    }
                }
            }
        )
        res = action.run("default", "FIREWALL_AUTH_PORTAL_ADDRESS")
        print(res.keys())
        assert type(res) == dict

    def test_create_address(self):
        action = CreateFirewallAddressAction(
            {
                "conf": {
                    "default": {
                        "ipaddr": "10.10.10.253",
                        "username": "admin",
                        "password": "",
                        "port": 443,
                    }
                }
            }
        )
        data = {
            "name": "Test1",
            "type": "subnet",
            "subnet": "192.168.0.0 255.255.255.0",
        }
        result = action.run("default", "Test1", data)
        assert result.get("status", "") == "success"

    def test_update_address(self):
        action = UpdateFirewallAddressAction(
            {
                "conf": {
                    "default": {
                        "ipaddr": "10.10.10.253",
                        "username": "admin",
                        "password": "",
                        "port": 443,
                    }
                }
            }
        )
        result = action.run("default", "Test1", {"subnet": "192.168.0.0 255.255.255.0"})
        assert result.get("status", "") == "success"

    def test_delete_address(self):
        action = DeleteFirewallAddressAction(
            {
                "conf": {
                    "default": {
                        "ipaddr": "10.10.10.253",
                        "username": "admin",
                        "password": "",
                        "port": 443,
                    }
                }
            }
        )
        result = action.run("default", "Test1")
        assert result.get("status", "") == "success"
