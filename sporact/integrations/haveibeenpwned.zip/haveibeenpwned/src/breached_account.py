import requests
from sporact_base.sporact_base_action import SporactBaseAction


class BreachedAccountAction(SporactBaseAction):
    def run(self, email):
        url = "https://haveibeenpwned.com/api/v3/breachedaccount/{}?truncateResponse=false".format(
            email
        )
        headers = {"User-Agent": "anlyz", "hibp-aapi-key": self.conf.get("api_key")}
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            resp = response.json()
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
