import requests

from sporact_base.sporact_base_action import SporactBaseAction


class BreachedDomainAction(SporactBaseAction):
    def run(self, domain):
        # Note: domain should be just the name without .com
        url = "https://haveibeenpwned.com/api/v3/breach/{}".format(domain)
        headers = {"User-Agent": "anlyz", "hibp-api-key": self.conf.get("api_key")}
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            resp = response.json()
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
