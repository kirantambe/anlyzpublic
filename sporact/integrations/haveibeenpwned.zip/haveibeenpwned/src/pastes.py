import urllib
import requests

from sporact_base.sporact_base_action import SporactBaseAction


class PasteAction(SporactBaseAction):
    def run(self, email):
        account = urllib.parse.quote_plus(email)
        url = "https://haveibeenpwned.com/api/v3/pasteaccount/{}".format(account)
        headers = {"User-Agent": "anlyz", "hibp-api-key": self.conf.get("api_key")}
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            resp = response.json()
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
