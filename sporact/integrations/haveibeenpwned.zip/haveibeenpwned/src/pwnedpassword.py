import requests
import hashlib

from sporact_base.sporact_base_action import SporactBaseAction


class PwnedPasswordAction(SporactBaseAction):
    def run(self, password):
        hash_val = hashlib.sha1(password.encode()).hexdigest().upper()
        url = "https://api.pwnedpasswords.com/range/{}".format(hash_val[:5])
        headers = {"User-Agent": "anlyz", "hibp-api-key": self.conf.get("api_key")}
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            l = response.text.split("\r\n")
            resp_dict = {x.split(":")[0]: x.split(":")[1] for x in l}
            if hash_val in resp_dict:
                resp = {"occurences": int(resp_dict[hash_val]), "response_code": response.status_code}
            else:
                resp = {"occurences": 0, "response_code": response.status_code}
            return resp
        else:
            raise Exception(response.reason)
