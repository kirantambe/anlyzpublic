from src.breached_account import BreachedAccountAction
from .config import HAVEIBEENPWNED_API_KEY
import unittest


class TestBreachedAccountAction(unittest.TestCase):
    def test_breached_account(self):
        action = BreachedAccountAction({"api_key": HAVEIBEENPWNED_API_KEY})
        res = action.run("adithi@anlyz.io")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)