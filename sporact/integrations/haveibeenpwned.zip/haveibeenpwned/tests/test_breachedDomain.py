from src.breached_domain import BreachedDomainAction
from .config import HAVEIBEENPWNED_API_KEY
import unittest


class TestBreachedDomainAction(unittest.TestCase):
    def test_breached_domain(self):
        action = BreachedDomainAction({"api_key": HAVEIBEENPWNED_API_KEY})
        res = action.run("adobe")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)