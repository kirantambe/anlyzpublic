from src.pastes import PasteAction
from .config import HAVEIBEENPWNED_API_KEY
import unittest


class TestPasteAction(unittest.TestCase):
    def test_breached_domain(self):
        action = PasteAction({"api_key": HAVEIBEENPWNED_API_KEY})
        res = action.run("adithi@anlyz.io")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)