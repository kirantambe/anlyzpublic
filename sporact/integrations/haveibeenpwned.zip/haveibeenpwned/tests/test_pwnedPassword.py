from src.breached_domain import PwnedPasswordAction
from .config import HAVEIBEENPWNED_API_KEY
import unittest


class TestPwnedPasswordAction(unittest.TestCase):
    def test_breached_domain(self):
        action = PwnedPasswordAction({"api_key": HAVEIBEENPWNED_API_KEY})
        res = action.run("password123")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)