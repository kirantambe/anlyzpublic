import requests
from sporact_base.sporact_base_action import SporactBaseAction


class GetLocationInfoAction(SporactBaseAction):

    def run(self, ip):
        url = "https://api.ip2location.com/v2/?ip={}&key={}&package=WS7&addon=continent,country,region,city,country_groupings".format(
            ip, self.conf.get("api_key")
        )
        response = requests.get(url)
        if response.status_code == 200:
            resp = response.json()
            if "response" in resp and resp.get("response", "") == "Invalid IP address.":
                raise Exception("Invalid IP address")
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
