from src.get_location_info import GetLocationInfoAction
from .config import IP2LOCATION_API_KEY
import unittest


class TestGetLocationInfoAction(unittest.TestCase):
    def test_location_info(self):
        action = GetLocationInfoAction({"api_key": IP2LOCATION_API_KEY})
        res = action.run("2405:204:5400:545e:d8af:d8c0:55bc:f89")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
