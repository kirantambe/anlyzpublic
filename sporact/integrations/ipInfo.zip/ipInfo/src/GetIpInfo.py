import requests

from sporact_base.sporact_base_action import SporactBaseAction


class GetIPInfoAction(SporactBaseAction):
    def run(self, ip):
        url = f"https://ipinfo.is/{ip}"
        response = requests.get(url)
        if response.status_code == 200:
            resp = response.json()
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
