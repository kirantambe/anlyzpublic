from src.GetIpInfo import GetIPAction
import unittest


class TestIPInfo(unittest.TestCase):
    def test_ip_info(self):
        action = GetIPAction()
        res = action.run("103.228.62.104")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
