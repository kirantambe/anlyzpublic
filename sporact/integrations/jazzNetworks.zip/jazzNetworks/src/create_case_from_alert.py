from datetime import timedelta
from urllib.parse import urljoin
from html import escape

import requests
import json
import re

from sporact_base.sporact_base_action import SporactBaseAction
from dateutil.parser import parse as parse_date
import logging

log = logging.getLogger(__name__)


class CreateCaseFromAlert(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        self.SPORACT_URL = "http://api:8000/api/"
        self.reg = re.compile("\s(\w+)=([^=]+)(?=\s+\w+=)")

    def extract_fields(self, text):
        data = {}
        try:
            rows = re.sub(r' (\w+=)', r'  !@!  \1', text.split("|", 1)[1].strip().replace(' | ', ' ')).split('  !@!  ')
            for row in rows:
                key, value = row.split("=", 1)
                data[key] = value
            return data
        except:
            return data

    def get_impact_from_score(self, score):
        score = int(score)
        if score == 0:
            return "informational"

        if score >= 1 and score <= 39:
            return "low"

        if score >= 40 and score <= 69:
            return "medium"

        if score >= 70 and score <= 89:
            return "high"

        if score >= 90 and score <= 100:
            return "critical"

    def get_event_stream(self, event_stream, agent_uuid, from_time, to_time):
        api_base_url = self.conf.get("api_url")
        api_key = self.conf.get("api_key")

        if not api_base_url:
            raise Exception("api_url not configured")

        if not api_key:
            raise Exception("api_key not configured")

        if not api_base_url.endswith('/'):
            api_base_url = f"{api_base_url}/"

        url = urljoin(urljoin(api_base_url, "timeline/"), event_stream)

        headers = {
            "Authorization": f"Bearer {api_key}"
        }

        request_body = {
            "page_info": {
                "cursor": "",
                "limit": 2147483647 # max limit for int32 in Go (Jazz apis are built with Go)
            },
            "query": {
                "query": {
                    "key": "agent_uuid",
                    "op": "$eq",
                    "value": agent_uuid
                },
                "time_range": {
                    "from": from_time,
                    "to": to_time
                }
            }
        }
        response = requests.post(url, headers=headers, json=request_body)
        if response.status_code == 200:
            response_json = response.json()
            return response_json.get('events', {}).get(event_stream, [])

        return []

    def get_alerts(self, data):
        event_datetime = parse_date(data.get('timestamp'))
        from_date = event_datetime - timedelta(minutes=15)
        to_date = event_datetime + timedelta(minutes=15)
        agent_uuid = data.get('agent_uuid')
        alerts = []

        event_streams = [
            "files",
            "browser_events",
            "alarms",
            "sensors",
            "print_events",
            "automation_events",
            "application_reports",
            "wireless_connection_changes",
            "heartbeats",
            "logins",
            "usb",
            "dns",
            "processes",
            "connections",
            "user",
        ]

        for event_stream in event_streams:
            alerts = alerts + self.get_event_stream(event_stream, agent_uuid, from_date.isoformat(), to_date.isoformat())

        return alerts

    def run(self, data):
        access_token = self.sporact.get("api_key")
        headers = {"Content-Type": "application/json", "X-Api-Key": f"{access_token}"}
        case = {}
        log.info(data)
        case["title"] = data.pop("description")
        log.info(f"Got new alert from Jazz Networks: {case['title']}")
        tags = data.pop("tags")
        case["extra_data"] = {}
        try:
            case["events"] = self.get_alerts(data)
        except Exception as e:
            log.error(f"Failed to retrieve events from jazz due to {e}")
            case["events"] = []
        case["event_time"] = data.pop("timestamp")

        try:
            case["category"] = tags.pop(1)
            case["extra_data"]["tag_1"] = tags.pop(0)
            case["extra_data"]["tag_2"] = tags.pop(0)
        except:
            case["category"] = "Uncategorized"

        try:
            case["extra_data"]["policy_name"] = case["title"].split('+')[0].strip()
        except:
            pass

        try:
            case["extra_data"]["username"] = data.get("username")
        except:
            pass

        try:
            case["extra_data"]["hostname"] = data.get("agent_hostname")
        except:
            pass

        sensor = data.pop("sensors")
        case["description"] = ""
        for key, value in data.items():
            case["description"] += f"<b> {escape(str(key))} </b> {escape(str(value))} <br>"
        case["description"] += "<b> SENSORS </b> <br>"
        for s in sensor:
            fields = s.get("description")
            log.info(f"Sensor Description: {fields}")
            case["extra_data"].update(self.extract_fields(fields))
            for key, value in s.items():
                case["description"] += f"<b> {escape(str(key))} </b> {escape(str(value))} <br>"
            try:
                metadata = s.get("metadata", {})
                process_info = s.get("process_info", [])
                for field, fvalue in metadata.items():
                    if fvalue:
                        if type(fvalue) == list:
                            case["extra_data"][field] = ",".join(fvalue)
                        if type(fvalue) == str:
                            case["extra_data"][field] = fvalue
                for pinfo in process_info:
                    for field, fvalue in pinfo.items():
                        if fvalue:
                            case["extra_data"][field] = fvalue

            except Exception as e:
                log.info(f"{e} while parsing meta data")
        case["alert_source"] = "JazzNetworks"
        case["impact"] = self.get_impact_from_score(data.get("score", 1))

        log.info(f"Score: {data.get('score')} | Impact: {case['impact']}")

        response = requests.request(
            "POST",
            "{}cases/case/".format(self.SPORACT_URL),
            data=json.dumps(case),
            headers=headers,
        )
        if response.status_code == 201:
            resp = response.json()
            resp["response_code"] = 1
            return resp
        else:
            print(response.content)
            log.info(response.content)
            log.info(response.reason)
            return {"message": response.reason, "response_code": 0}