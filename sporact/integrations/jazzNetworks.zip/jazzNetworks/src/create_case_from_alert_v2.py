from datetime import timedelta
from urllib.parse import urljoin
from html import escape
import urllib

import requests
import json
import re

from sporact_base.sporact_base_action import SporactBaseAction
from dateutil.parser import parse as parse_date
import logging

log = logging.getLogger(__name__)


class CreateCaseFromAlertV2(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        self.SPORACT_URL = "http://api:8000/api/"
        self.reg = re.compile("\s(\w+)=([^=]+)(?=\s+\w+=)")

    def extract_fields(self, text):
        data = {}
        try:
            rows = re.sub(r' (\w+=)', r'  !@!  \1', text.split("|", 1)[1].strip().replace(' | ', ' ')).split('  !@!  ')
            for row in rows:
                key, value = row.split("=", 1)
                data[key] = value
            return data
        except:
            return data

    def get_impact_from_score(self, score):
        score = int(score)
        if score == 0:
            return "informational"

        if score >= 1 and score <= 39:
            return "low"

        if score >= 40 and score <= 69:
            return "medium"

        if score >= 70 and score <= 89:
            return "high"

        if score >= 90 and score <= 100:
            return "critical"

    def get_event_stream(self, event_stream, agent_uuid, from_time, to_time):
        api_base_url = self.conf.get("api_url")
        api_key = self.conf.get("api_key")

        if not api_base_url:
            raise Exception("api_url not configured")

        if not api_key:
            raise Exception("api_key not configured")

        if not api_base_url.endswith('/'):
            api_base_url = f"{api_base_url}/"

        url = urljoin(urljoin(api_base_url, "timeline/"), event_stream)

        headers = {
            "Authorization": f"Bearer {api_key}"
        }

        request_body = {
            "page_info": {
                "cursor": "",
                "limit": 2147483647  # max limit for int32 in Go (Jazz apis are built with Go)
            },
            "query": {
                "query": {
                    "key": "agent_uuid",
                    "op": "$eq",
                    "value": agent_uuid
                },
                "time_range": {
                    "from": from_time,
                    "to": to_time
                }
            }
        }
        response = requests.post(url, headers=headers, json=request_body)
        if response.status_code == 200:
            response_json = response.json()
            return response_json.get('events', {}).get(event_stream, [])

        return []

    def get_alerts(self, data):
        event_datetime = parse_date(data.get('timestamp'))
        from_date = event_datetime - timedelta(minutes=15)
        to_date = event_datetime + timedelta(minutes=15)
        agent_uuid = data.get('agent_uuid')
        alerts = []

        event_streams = [
            "files",
            "browser_events",
            "alarms",
            "sensors",
            "print_events",
            "automation_events",
            "application_reports",
            "wireless_connection_changes",
            "heartbeats",
            "logins",
            "usb",
            "dns",
            "processes",
            "connections",
            "user",
        ]

        for event_stream in event_streams:
            alerts = alerts + self.get_event_stream(event_stream, agent_uuid, from_date.isoformat(),
                                                    to_date.isoformat())

        return alerts

    def run(self, data):
        keys = [
            'created_by',
            'description',
            'anonymised_description',
            'score',
            'customer',
            'agent_uuid',
            'agent_hostname',
            'event_type',
            'timestamp',
            'sensor_type',
            'username',
            'tags',
            'metadata',
            'process_info',
            'type',
            'clustering_rule',
            'family',
            'generation',
            'status',
            'started',
            'last_updated',
            'sensor_count',
            'changed_status_at',
            'changed_status_by',
            'changed_status_reason',
            'first_detection',
            'last_detection',
            'new_entity',
            'cluster_data'
        ]
        log.info("Got new request for CreateCaseFromAlertV2")
        print("Got new request for CreateCaseFromAlertV2  with case creation")
        print(data)
        log.info(data)

        if data.get("event_type", "") != "sensor":
            print("Event not of type sensor")
            log.info("Event not of type sensor")
            return

        # New code starts here
        access_token = self.sporact.get("api_key")
        headers = {"Content-Type": "application/json", "X-Api-Key": f"{access_token}"}
        case = {}
        log.info(data)
        print("Preparing data for case")
        try:
            case["title"] = urllib.parse.parse_qs(urllib.parse.urlparse(data.get("created_by")).query).get("name")[0]
        except:
            try:
                case["title"] = data.get("description", "").split("|")[0]
            except:
                case["title"] = data.get("description", "Unknown Alert")

        log.info(f"Got new alert from Jazz Networks: {case['title']}")
        tags = data.pop("tags")
        case["extra_data"] = {}

        case["event_time"] = data.pop("timestamp")

        try:
            case["category"] = tags.pop(1)
            for tagidx, tag in enumerate(tags):
                case["extra_data"][f"tag_{tagidx}"] = tag
        except:
            case["category"] = "Uncategorized"

        try:
            case["extra_data"]["username"] = data.get("username")
        except:
            pass

        try:
            case["extra_data"]["hostname"] = data.get("agent_hostname")
        except:
            pass

        case["description"] = "<br><table>"

        for key in keys:
            if (key in data) and data[key]:
                case["description"] += f"<tr><td><strong>{key}</strong></td><td>{data[key]}</td></tr>"

        case["description"] += "</table>"

        for key, value in data.items():
            if key in ["customer", "tenant_origin", "tenant_id", "tenant_name", "event_type", "juid", "anonymised_description"]:
                continue
            cleaned_value = value
            if type(value) == list:
                if len(value) == 1:
                    cleaned_value = value[0]
                else:
                    cleaned_value = str(value)
                case["extra_data"][key] = cleaned_value
                continue

            if type(value) == dict:
                for inner_key, inner_value in value.items():
                    if inner_value:
                        case["extra_data"][inner_key] = inner_value

        case["alert_source"] = "JazzNetworks"
        case["impact"] = self.get_impact_from_score(data.get("score", 1))
        case["extra_data"]["policy_name"] = case["title"]

        log.info(f"Score: {data.get('score')} | Impact: {case['impact']}")
        print("Calling create case api")
        print(case)
        response = requests.request(
            "POST",
            "{}cases/case/".format(self.SPORACT_URL),
            data=json.dumps(case),
            headers=headers,
        )
        if response.status_code == 201:
            resp = response.json()
            resp["response_code"] = 1
            return resp
        else:
            log.info(response.reason)
            print(response.reason)
            return {"message": response.reason, "response_code": 0}

        return {"status": "success"}