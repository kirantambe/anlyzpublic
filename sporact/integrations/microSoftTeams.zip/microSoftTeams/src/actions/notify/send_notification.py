from sporact_base.sporact_base_action import SporactBaseAction
import requests


class SendNotification(SporactBaseAction):
    def run(self, message):
        headers = {
            'Content-Type': 'application/json;'
        }
        data = {"text": message}
        response = requests.post(self.conf.get("webhook_url"), headers=headers, json=data)
        if response.status_code == 200:
            resp = {"status": "success", "status_code": str(response.status_code)}
            return resp
        else:
            raise Exception(response.reason)