from sporact_base.sporact_base_action import SporactBaseAction
import requests


class TestIntegration(SporactBaseAction):
    def run(self, conf, inputs):
        headers = {
            'Content-Type': 'application/json;'
        }
        data = {"text": "Test message"}
        response = requests.post(conf.get("webhook_url"), headers=headers, json=data)
        if response.status_code == 200:
            response_dict = (("message", "Successfully tested the configuration!"), ("status", "success"))
        else:
            response_dict = (("message", "Invalid configuration!"), ("status", "failed"))
        return response_dict
