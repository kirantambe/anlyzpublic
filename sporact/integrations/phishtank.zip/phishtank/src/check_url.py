import requests
import base64

from sporact_base.sporact_base_action import SporactBaseAction


class CheckURLAction(SporactBaseAction):

    def run(self, url):
        api_url = "https://checkurl.phishtank.com/checkurl/"
        data = {
            "format": "json",
            "app_key": self.conf.get("api_key"),
            "url": base64.b64encode(url.encode())
        }

        response = requests.post(api_url, data=data)

        if response.status_code == 200:
            try:
                response_data = response.json()
                return response_data["results"]
            except:
                Exception("Phishtank api returned incorrect data")
        else:
            raise Exception("Api call to phishtank failed")