from sporact_base.sporact_base_action import SporactBaseAction
import requests


class SearchForAlert(SporactBaseAction):
    def run(self, integration_dict, conf):
        if "id" in integration_dict:
            url = "/v2/alert/"+str(integration_dict["id"])
        else:
            url = "/v2/alert/search"
        headers = {
            "X-RFToken": conf.get("api_key")
        }
        try:
            return requests.get("https://api.recordedfuture.com" + url, headers=headers)
        except Exception as e:
            return {
                "status": "error",
                "status_msg": str(e),
                "data": {}
            }
