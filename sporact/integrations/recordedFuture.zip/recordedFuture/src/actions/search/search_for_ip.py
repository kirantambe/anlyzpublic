from sporact_base.sporact_base_action import SporactBaseAction
import requests


class SearchForIP(SporactBaseAction):
    def run(self, ip, risk_score, limit):
        if risk_score is None:
            risk_score = 70
        if limit is None:
            limit = 10
        url = "/v2/ip/search?list=ip:"+str(ip)+"&limit="+str(limit)+"&riskScore=%5B"+str(risk_score)+"%2C%5D"
        headers = {
            "X-RFToken": self.conf.get("api_key")
        }
        response = requests.get("https://api.recordedfuture.com" + url, headers=headers)
        if response.status_code == 200:
            resp = response.json()
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
