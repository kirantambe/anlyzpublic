from sporact_base.sporact_base_action import SporactBaseAction
import requests


class SearchForRiskRules(SporactBaseAction):
    def run(self):
        url = "/v2/url/riskrules"
        headers = {
            "X-RFToken": self.conf.get("api_key")
        }
        response = requests.get("https://api.recordedfuture.com" + url, headers=headers)
        if response.status_code == 200:
            resp = response.json()
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
