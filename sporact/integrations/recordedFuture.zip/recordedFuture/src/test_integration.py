from sporact_base.sporact_base_action import SporactBaseAction
import requests


class TestIntegration(SporactBaseAction):
    def run(self, conf, inputs):
        url = "/v2/alert/search"
        headers = {
            "X-RFToken": conf.get("api_key")
        }
        response = requests.get("https://api.recordedfuture.com" + url, headers=headers)
        if response.status_code == 200:
            response_dict = (("message", "Successfully tested the configuration!"), ("status", "success"))
        else:
            response_dict = (("message", "Invalid configuration!"), ("status", "failed"))
        return response_dict