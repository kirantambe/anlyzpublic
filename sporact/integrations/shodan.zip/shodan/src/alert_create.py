import requests
from sporact_base.sporact_base_action import SporactBaseAction


class CreateAlert(SporactBaseAction):
    def run(self, name, filters, expires=None):
        url = "https://api.shodan.io/shodan/alert"
        api_key = self.conf.get("api_key")
        params = {"key": api_key}
        data = {'name': name, 'filters': filters}
        if expires:
            data['expires'] = expires
        response = requests.post(url, params=params, data=data)
        if response.status_code == 200:
            resp = response.json()
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
