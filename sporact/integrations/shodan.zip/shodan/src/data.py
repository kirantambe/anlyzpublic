import requests
from sporact_base.sporact_base_action import SporactBaseAction


class GetData(SporactBaseAction):
    def run(self):
        url = f"https://api.shodan.io/shodan/data"
        api_key = self.conf.get("api_key")
        params = {"key": api_key}
        response = requests.get(url, params=params)
        if response.status_code == 200:
            resp = {"data": response.json()}
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
