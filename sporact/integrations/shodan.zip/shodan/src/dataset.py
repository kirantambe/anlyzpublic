import requests
from sporact_base.sporact_base_action import SporactBaseAction


class GetDataSet(SporactBaseAction):

    def run(self, dataset):
        url = f"https://api.shodan.io/shodan/data/{dataset}"
        api_key = self.conf.get("api_key")
        params = {"key": api_key}
        response = requests.get(url, params=params)
        if response.status_code == 200:
            resp = {"dataset": response.json()}
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
