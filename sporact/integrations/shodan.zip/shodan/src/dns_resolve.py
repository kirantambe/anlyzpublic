import requests
from sporact_base.sporact_base_action import SporactBaseAction


class GetDnsResolve(SporactBaseAction):

    def run(self, hostnames):
        url = "https://api.shodan.io/dns/resolve"
        api_key = self.conf.get("api_key")
        params = {"key": api_key, 'hostnames': hostnames}
        response = requests.get(url, params=params)
        if response.status_code == 200:
            resp = {"dns": response.json()}
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
