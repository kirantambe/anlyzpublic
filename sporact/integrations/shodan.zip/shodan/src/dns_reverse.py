import requests
from sporact_base.sporact_base_action import SporactBaseAction


class GetDnsReverse(SporactBaseAction):

    def run(self, ips):
        url = "https://api.shodan.io/dns/reverse"
        api_key = self.conf.get("api_key")
        params = {"key": api_key, 'ips': ips}
        response = requests.get(url, params=params)
        if response.status_code == 200:
            resp = {"dns": response.json()}
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
