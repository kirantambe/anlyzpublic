import requests
from sporact_base.sporact_base_action import SporactBaseAction


class GetHostTokens(SporactBaseAction):

    def run(self, query):
        url = "https://api.shodan.io/shodan/host/search/tokens"
        api_key = self.conf.get("api_key")
        params = {"key": api_key, 'query': query}
        response = requests.get(url, params=params)
        if response.status_code == 200:
            resp = response.json()
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
