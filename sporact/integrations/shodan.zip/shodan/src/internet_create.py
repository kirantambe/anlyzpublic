import requests
from sporact_base.sporact_base_action import SporactBaseAction


class CreateInternet(SporactBaseAction):

    def run(self, port, protocol):
        url = "https://api.shodan.io/shodan/scan/internet"
        api_key = self.conf.get("api_key")
        params = {"key": api_key}
        data = {'port': port, 'protocol': protocol}
        response = requests.post(url, params=params, data=data)
        if response.status_code == 200:
            resp = response.json()
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
