import requests
from sporact_base.sporact_base_action import SporactBaseAction


class GetMyIp(SporactBaseAction):
    def run(self):
        url = "https://api.shodan.io/tools/myip"
        api_key = self.conf.get("api_key")
        params = {"key": api_key}
        response = requests.get(url, params=params)
        if response.status_code == 200:
            resp = {"ip": response.json()}
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
