import requests
from sporact_base.sporact_base_action import SporactBaseAction


class GetNotifierInfo(SporactBaseAction):
    def run(self, id):
        url = f"https://api.shodan.io/notifier/{id}"
        api_key = self.conf.get("api_key")
        params = {"key": api_key}
        response = requests.get(url, params=params)
        if response.status_code == 200:
            resp = response.json()
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
