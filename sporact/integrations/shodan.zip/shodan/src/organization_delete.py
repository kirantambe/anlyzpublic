import requests
from sporact_base.sporact_base_action import SporactBaseAction


class DeleteOrganization(SporactBaseAction):

    def run(self, user):
        url = f"https://api.shodan.io/org/member/{user}"
        api_key = self.conf.get("api_key")
        params = {"key": api_key}
        response = requests.delete(url, params=params)
        if response.status_code == 200:
            resp = response.json()
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
