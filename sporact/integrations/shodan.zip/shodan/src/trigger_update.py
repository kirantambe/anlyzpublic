import requests
from sporact_base.sporact_base_action import SporactBaseAction


class UpdateTriggerById(SporactBaseAction):
    def run(self, alert_id, trigger_names):
        url = f"https://api.shodan.io/shodan/alert/{alert_id}/trigger/{trigger_names}"
        api_key = self.conf.get("api_key")
        params = {"key": api_key}
        response = requests.put(url, params=params)
        if response.status_code == 200:
            resp = response.json()
            resp["response_code"] = response.status_code
            return resp
        else:
            raise Exception(response.reason)
