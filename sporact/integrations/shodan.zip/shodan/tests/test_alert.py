from .config import SHODAN_API_KEY
import unittest

from src.alert import GetAlertInfo


class TestGetAlertInfo(unittest.TestCase):
    def test(self):
        action = GetAlertInfo({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("67UQ4JM3NGJKROR9")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
