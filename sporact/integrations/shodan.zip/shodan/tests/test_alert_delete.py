from .config import SHODAN_API_KEY
import unittest

from src.alert_delete import DeleteAlert


class TestDeleteAlert(unittest.TestCase):
    def test(self):
        action = DeleteAlert({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("67UQ4JM3NGJKROR9")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
