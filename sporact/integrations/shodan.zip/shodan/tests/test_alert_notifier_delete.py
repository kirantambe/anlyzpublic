from .config import SHODAN_API_KEY
import unittest

from src.alert_notifier_delete import DeleteAlertNotifier


class TestDeleteAlertNotifier(unittest.TestCase):
    def test(self):
        action = DeleteAlertNotifier({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("OYPRB8IR9Z35AZPR", "default")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
