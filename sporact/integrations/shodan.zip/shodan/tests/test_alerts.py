from .config import SHODAN_API_KEY
import unittest

from src.alerts import GetInfo


class TestGetInfo(unittest.TestCase):
    def test(self):
        action = GetInfo({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run()
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
