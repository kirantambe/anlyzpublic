from .config import SHODAN_API_KEY
import unittest

from src.data import GetData


class TestGetData(unittest.TestCase):
    def test(self):
        action = GetData({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run()
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
