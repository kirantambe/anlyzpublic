from .config import SHODAN_API_KEY
import unittest

from src.dns_domains import GetDnsDomains


class TestGetDnsDomains(unittest.TestCase):
    def test(self):
        action = GetDnsDomains({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("google.com")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
