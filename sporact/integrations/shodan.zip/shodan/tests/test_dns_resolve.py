from .config import SHODAN_API_KEY
import unittest

from src.dns_resolve import GetDnsResolve


class TestGetDnsResolve(unittest.TestCase):
    def test(self):
        action = GetDnsResolve({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("google.com,facebook.com")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
