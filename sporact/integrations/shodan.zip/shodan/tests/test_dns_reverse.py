from .config import SHODAN_API_KEY
import unittest

from src.dns_reverse import GetDnsReverse


class TestGetDnsReverse(unittest.TestCase):
    def test(self):
        action = GetDnsReverse({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("8.8.8.8,1.1.1.1")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
