from .config import SHODAN_API_KEY
import unittest

from src.host_count import GetHostCount


class TestHostCount(unittest.TestCase):
    def test(self):
        action = GetHostCount({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("port:22")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
