from .config import SHODAN_API_KEY
import unittest

from src.host_info import GetHostInfo


class TestHostInfo(unittest.TestCase):
    def test(self):
        action = GetHostInfo({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("8.8.8.8")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
