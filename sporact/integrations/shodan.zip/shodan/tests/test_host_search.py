from .config import SHODAN_API_KEY
import unittest

from src.host_search import HostSearch


class TestHostSearch(unittest.TestCase):
    def test(self):
        action = HostSearch({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("product:nginx", "country")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
