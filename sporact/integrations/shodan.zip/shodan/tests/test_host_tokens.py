from .config import SHODAN_API_KEY
import unittest

from src.host_tokens import GetHostTokens


class TestHostTokens(unittest.TestCase):
    def test(self):
        action = GetHostTokens({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("Raspbian port:22")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
