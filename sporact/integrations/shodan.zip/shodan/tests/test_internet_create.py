from .config import SHODAN_API_KEY
import unittest

from src.internet_create import CreateInternet


class TestCreateInternet(unittest.TestCase):
    def test(self):
        action = CreateInternet({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("80", "http")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
