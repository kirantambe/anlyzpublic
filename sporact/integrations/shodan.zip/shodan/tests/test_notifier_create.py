from .config import SHODAN_API_KEY
import unittest

from src.notifier_create import CreateNotifier


class TestCreateNotifier(unittest.TestCase):
    def test(self):
        action = CreateNotifier({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("67UQ4JM3NGJKROR9")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
