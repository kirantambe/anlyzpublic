from .config import SHODAN_API_KEY
import unittest

from src.notifier_delete import DeleteNotifier


class TestCreateNotifier(unittest.TestCase):
    def test(self):
        action = DeleteNotifier({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("1VxiaJb93Gn8TUnM")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
