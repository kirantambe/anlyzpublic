from .config import SHODAN_API_KEY
import unittest

from src.notifier_update import UpdateNotifier


class TestUpdateNotifier(unittest.TestCase):
    def test(self):
        action = UpdateNotifier({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("1VxiaJb93Gn8TUnM")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
