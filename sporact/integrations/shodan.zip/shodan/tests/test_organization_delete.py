from .config import SHODAN_API_KEY
import unittest

from src.organization_delete import DeleteOrganization


class TestDeleteOrganization(unittest.TestCase):
    def test(self):
        action = DeleteOrganization({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("new-member@shodan.io")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
