from .config import SHODAN_API_KEY
import unittest

from src.ports import GetPorts


class TestPorts(unittest.TestCase):
    def test(self):
        action = GetPorts({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run()
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
