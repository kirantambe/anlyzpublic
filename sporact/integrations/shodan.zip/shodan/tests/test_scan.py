from .config import SHODAN_API_KEY
import unittest

from src.scan import GetSingleScan


class TestGetSingleScan(unittest.TestCase):
    def test(self):
        action = GetSingleScan({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("Mo8W7itcWumiy9Ay")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
