from .config import SHODAN_API_KEY
import unittest

from src.trigger_update import UpdateTriggerById


class TestUpdateTriggerById(unittest.TestCase):
    def test(self):
        action = UpdateTriggerById({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("OYPRB8IR9Z35AZPR", "new_service,vulnerable")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
