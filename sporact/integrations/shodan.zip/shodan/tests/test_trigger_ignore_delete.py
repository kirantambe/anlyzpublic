from .config import SHODAN_API_KEY
import unittest

from src.trigger_ignore_delete import DeleteTriggerIgnore


class TestDeleteTriggerIgnore(unittest.TestCase):
    def test(self):
        action = DeleteTriggerIgnore({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("OYPRB8IR9Z35AZPR", "new_service", "1.1.1.1:53")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
