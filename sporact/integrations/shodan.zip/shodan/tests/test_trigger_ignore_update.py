from .config import SHODAN_API_KEY
import unittest

from src.trigger_ignore_update import UpdateTriggerIgnore


class TestUpdateTriggerIgnore(unittest.TestCase):
    def test(self):
        action = UpdateTriggerIgnore({
            "conf": {"api_key": SHODAN_API_KEY}
        })
        res = action.run("OYPRB8IR9Z35AZPR", "new_service", "1.1.1.1:53")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
