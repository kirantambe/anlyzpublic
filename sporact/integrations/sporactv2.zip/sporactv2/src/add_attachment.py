import requests
import json
import os
from urllib.request import urlretrieve

from sporact_base.sporact_base_action import SporactBaseAction


class AddAttachment(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        self.SPORACT_URL = "http://api:8000/api/"

    def run(self, url):
        filename = os.path.basename(url)
        file_path = os.path.join("/tmp", filename)
        urlretrieve(url, file_path)
        files = {'file': open(file_path, 'rb')}
        response = requests.post(f"{self.SPORACT_URL}cases/attachment/", files=files)
        if response.status_code == 201:
            attachment_data = response.json()


        return {
            "status": "success",
            "message": "Attachment added"
        }