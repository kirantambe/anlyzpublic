import smtplib
from email.mime.text import MIMEText

import requests
import json

from sporact_base.sporact_base_action import SporactBaseAction


class SendEmail(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        self.SPORACT_URL = "http://api:8000/api/"

    def run(self, subject, recipients, message):
        recipients_new = recipients
        if type(recipients) == str:
            recipients_new = recipients.split(",")
        self.send_email(subject, recipients_new, message)
        return {
            "status": "success",
            "message": "Email Sent"
        }

    def send_email(self, subject, recipients, message):
        email_settings = self.sporact.get("email_settings")
        msg = MIMEText(message, "html")
        sender_addr = email_settings.get("sender_email", email_settings.get("email_host_user", ""))
        msg['From'] = sender_addr
        msg['To'] = ', '.join(recipients)
        msg['Subject'] = subject

        smtp = smtplib.SMTP(host=email_settings.get("email_host"), port=email_settings.get("email_port"))
        smtp.starttls()
        smtp.ehlo()
        #smtp.login("apikey", "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") # OG Key
        smtp.login(email_settings.get("email_host_user"), email_settings.get("email_host_password"))
        smtp.sendmail(sender_addr, recipients, msg.as_string())
        smtp.close()