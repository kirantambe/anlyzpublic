from src.update_case_field import UpdateCaseFieldAction
from .config import CONFIG
import unittest


class TestUpdateCaseField(unittest.TestCase):

    def test_update_case_field(self):
        action = UpdateCaseFieldAction(CONFIG)
        res = action.run('extra_data.sourceIP', '10.10.10.20')
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)