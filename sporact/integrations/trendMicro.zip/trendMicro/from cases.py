from cases.models import Case
from django.utils import timezone
from concurrent.futures import ThreadPoolExecutor

cases = Case.objects.filter(tenant__name__icontains="finance", created__gte="2022-12-31T18:30:00.000Z", created__lte="2023-03-30T18:30:00.000Z", status=5)

closure_code = ClosureCode.objects.get(tenant__name__icontains="finance", closure_code="False Positive")
user = User.objects.get(username="system")

total = cases.count()
done = 0

executor = ThreadPoolExecutor(10)


def close_case(case):
    case.status = 3
    case.closure_code = closure_code
    case.save()
    try:
        HistoryEntry.objects.create(case=case, diff={"status": [5, 3], "closure_code": [None, closure_code.id], "modified": [case.modified.isoformat() if case.modified else None, timezone.now().isoformat()]}, type=2, user=user)
    except:
        done = done + 1
        pass
    print(f"Finished {done} out of {total} cases")

for case in cases:
    print(f"Submitting case {case.uid}")
    executor.submit(close_case, case)
    
    

executor.shutdown(wait=True)