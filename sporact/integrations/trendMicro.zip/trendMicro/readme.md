# Trend Micro Integration

**Product Name**: Trend Micro

**Version**: V2

## Configuration

To use the integration, configure it with below mentioned key.

api_key: A string representing your API key for Trend Micro.

server_selection: It is expected a string of unique server selection within trend micro.

## Actions

### Action: trendMicro.add_to_block_list

#### Action Type: MISTRAL

#### Description: The "add_to_block_list" action used for add something to a blacklist on a platform trend micro.
#### Inputs

| Name | Type | Example | Description |
|------|------|------|-------------|
| valueType | string | "ip" | It is expected a string of specifies the type of value to be blacklist.
| targetValue | string | "10.0.0.1" | It is expected a string of actual value to be blacklisted.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | It is expected outcome of the API request.
| action_id | string | It is expected a string of unique id associated with response.

### Action: trendMicro.remove_from_block_list

#### Action Type: MISTRAL

#### Description: The "remove_from_block_list" action used for remove something from the blacklist on a platform trend micro.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| valueType | string | None | It is expected a string of specifies the type of value to be remove from blacklist.
| targetValue | string | None | It is expected a string of actual value to be remove from blacklisted.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | It is expected outcome of the API request.
| action_id | string | It is expected a string of unique id associated with response.

### Action: trendMicro.quarantine_email_message

#### Action Type: MISTRAL

#### Description: The "quarantine_email_message" action used for quarantine an email message on a platform trendmicro.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| messageId | string | None | It is expected a string unique id of the email message.
| mailBox | string | None | It is expected a string specifying the mailbox where the email message resides.The format might depend on the specific email system. 
| messageDeliveryTime | string | (YYYY-MM-DDTHH:MM:SSZ) | It is expected string of message delivery time.
| productId | string | None | It is expected a product id associated with quarantine action.
| description | string | None | It is expected a description for the quarantine action.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | It is expected outcome of the API request.
| action_id | string | It is expected a string of unique id associated with response.

### Action: trendMicro.delete_email_message

#### Action Type: MISTRAL

#### Description: The "delete_email_message" action used for delete an email message on a platform trendmicro.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| messageId | string | None | It is expected a string unique id of the email message.
| mailBox | string | None | It is expected a string specifying the mailbox where the email message resides.The format might depend on the specific email system.
| messageDeliveryTime | string | (YYYY-MM-DDTHH:MM:SSZ) | It is expected string of message delivery time.
| productId | string | None | It is expected a product id associated with delete email message action.
| description | string | None | It is expected a description for the delete email message action.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | It is expected outcome of the API request.
| action_id | string | It is expected a string of unique id associated with response.

### Action: trendMicro.isolate_endpoint

#### Action Type: MISTRAL

#### Description: The "isolate_endpoint" action used for programmatically isolate endpoints on remote computers through a security agent. It handles building the isolate request and sending it to the appropriate endpoint.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| computerId | string | "ip"    | It is expected unique id of the computer.
| productId | string | None    | It is expected string of product id.
| description | string | None    | It is expected a description of isolate endpoint.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | It is expected outcome of the API request.
| action_id | string | It is expected a string of unique id associated with response.

### Action: trendMicro.restore_isolated_endpoint

#### Action Type: MISTRAL

#### Description: The "restore_isolated_endpoint" action used for restore isolated endpoints.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| computerId | string | None | It is expected unique id of the computer.
| productId | string | None | It is expected string of product id.
| description | string | None | It is expected a description of restore isolate endpoint.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | It is expected outcome of the API request.
| action_id | string | It is expected a string of unique id associated with response.

### Action: trendMicro.terminate_process

#### Action Type: MISTRAL

#### Description: The "terminate_process" action used for interacts with a security system  to initiate an action, possibly  terminating or isolating a file.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| computerId | string | None | It is expected unique id of the computer.
| fileSha1 | string | None | It is expected string of SHA-1 hash unique id.
| productId | string | None | It is expected a string of product id.
| description | string | None | It is expected a description of terminate process.
| filename | string | None | It is expected the name of the file.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | It is expected outcome of the API request.
| action_id | string | It is expected a string of unique id associated with response.

### Action: trendMicro.collect_file

#### Action Type: MISTRAL

#### Description: The "collect_file" action used to collect a file from a remote computer.

pen_spark

#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| computerId | string | None | It is expected unique id of the computer.
| filePath | string | None | It is expected path of the file.
| productId | string | None | It is expected a string of product id.
| os | string | "windows" | It is expected to be a string representing a valid operating system name.
| description | string | None | It is expected a description of collect_file.

#### Outputs

| Name | Type | Description |  
|------|------|-------------|
| url | string | A url of the collected file.
| expires | string | The information of expires.
| password | string | The credentials of the file.
| filename | string | A name of the collected file.
| action_id | string | A unique identifier associated with the file collection request.

### Action: trendMicro.search_for_data

#### Action Type: MISTRAL

#### Description: The "search_for_data" action used to search for data within a specified time range, source, and query. 
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| from_timestamp | int | None    | It expect start time of data search.
| to_timestamp | int | None    | It expect a end time of data search.
| source | string | "logs"  | It expect source of data to be search.
| query | string | None    | Field expect a string of valid expression.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | This field indicates the overall status of the data search operation.
| status_msg | string | This field contains an informative message related to the search status. 
| data | object | This field contains the actual data retrieved from the search.

### Action: trendMicro.search_for_source

#### Action Type: MISTRAL

#### Description: 
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| from_timestamp | datetime | None | It expect start time of data search.
| to_timestamp | datetime | None | It expect a end time of data search.
| source | string | None | It expect source of data to be search.
| query | string | None | Field expect a string of valid expression.
| conf | object | None | It is expected a configuration dictionary likely containing settings relevant to the search for source.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | This field indicates the overall status of the data search operation.
| status_msg | string | This field contains an informative message related to the search status.
| data | object | This field contains the actual data retrieved from the search.

### Action: trendMicro.search_observed_attack_techniques

#### Action Type: MISTRAL

#### Description: The "search_observed_attack_techniques" action used to search for observed attack techniques within a time range and allows for optional filtering based on various criteria provided in the integration_dict. It interacts with a system potentially related to security events or attack detection.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| from_timestamp | datetime | None | It expect start time of data search.
| to_timestamp | datetime | None | It expect a end time of data search.
| integration_dict | object | None | It is expected a information relevant to the search observed attack techniques.
| conf | object | None | It is expected a configuration dictionary likely containing settings relevant to the search for observed attack techniques.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | This field indicates the overall status of the data search operation.
| status_msg | string | This field contains an informative message related to the search status.
| data | object | This field contains the actual data retrieved from the search.

### Action: trendMicro.query_agent_information

#### Action Type: MISTRAL

#### Description: The "query_agent_information" action query an agent information system using specific criteria. It allows for automation and simplifies retrieval of agent details.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| field | string | "hostname" | It expect specific field information to be query.
| value | string | None | It expect specific value to match within the chosen field.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | This field indicates the overall status of the data.
| errorCode | string | The field contains error code
| message | string | The field contains string of message.
| result | object | This field holds the actual data retrieved from the query agent information.
 
### Action: trendMicro.query_information_of_endpoint

#### Action Type: MISTRAL

#### Description: The "query_information_of_endpoint" action used to query information about a specific endpoint (device) identified by its computer ID. It likely interacts with a security system or endpoint management system through an API to retrieve the information.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| computerId | string | None | It is expected unique id of the computer.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | This field indicates the overall status of the data.
| errorCode | string | The field contains error code
| message | string | The field contains string of message.
| result | object | This field holds the actual data retrieved from the associated action.

### Action: trendMicro.query_os_information

#### Action Type: MISTRAL

#### Description: The "query_os_information" action used to retrieves information about the operating system, likely through an API call.
#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string |  This field indicates the overall status of the data.
| errorCode | string | The field contains error code if there is issue.
| message | string | The field contains string of message.
| result | object | This field holds the actual data retrieved from the associated action.

### Action: trendMicro.add_to_exception_list

#### Action Type: MISTRAL

#### Description: The "add_to_exception_list" action used to add exceptions to a Threat Mitigation System's rules, allowing specific data points to be ignored even if they might raise red flags.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| valueType | string | None | It expect specific type of value to add exception list.
| targetValue | string | None | It is expected a string of actual value add to exception list.
| description | string | None | The field expected a description of add to exception list.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| data | object | This field holds the actual data retrieved from the associated action.

### Action: trendMicro.remove_from_exception_list

#### Action Type: MISTRAL

#### Description: The "remove_from_exception_list" action used to remove exceptions from a Threat Mitigation System's rules.

#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| valueType | string | None | It expect specific type of value to remove from exception list.
| targetValue | string | None | It is expected a string of actual value to be remove from exception list.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| data | object | This field holds the actual data retrieved from the associated action.

### Action: trendMicro.analyze_file_in_sandbox

#### Action Type: MISTRAL

#### Description: The "analyze_file_in_sandbox" action used to uploading a file to a security sandbox and then analyzing the file for malicious content. Security sandboxes are isolated environments that allow analysts to examine files safely without risking harm to their own computers.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| file_url | string | None | The URL of the file to be processed.
| documentPassword | string | None | An optional password to access the contents of the file being processed.
| archivePassword | string | (e.g., ZIP file) | An optional password to access the contents of an archive file. This field is only necessary if the file being processed is an archive and it is password-protected.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| report_id | string | This is a unique identifier for the report.
| analysisCompletionTime | string | This field specifies the time the analysis was completed.
| riskLevel | string | This field indicates the severity of the findings in the report. The value is usually a string representing the risk level.
| description | string | This field provides a textual explanation of the findings in the report.
| detectionNameList | array | This field containing names of the specific detections made during the analysis.
| threatTypeList | array | This field containing the types of threats associated with the detections.
| trueFileType | string | This field specifies the actual file type of the analyzed file.

### Action: trendMicro.add_to_suspicious_list

#### Action Type: MISTRAL

#### Description: The "add_to_suspicious_list" action used to add suspicious objects (like malicious URLs or IP addresses) to a TMS watchlist, potentially triggering further actions based on the configuration.
#### Inputs

| Name | Type | Example | Description |
|------|------|------|-------------|
| valueType | string | None | It expect specific type of value add to suspicious list.
| targetValue | string | None | The actual value add to suspicious list.
| description | string | None | The field expected a description of add to suspicious list
| scanAction | string | None | The field expect string of scan action.
| riskLevel | string | "low","high" | It expect value string a risklevel.
| expiredDay | int | None | It expect a number 

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| data | object | This field holds the actual data retrieved from the associated action.

### Action: trendMicro.remove_from_suspicious_list

#### Action Type: MISTRAL

#### Description: The "remove_from_suspicious_list" action used to removes a specified value (based on type) from a suspicious list maintained by a system, likely through an API call.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| valueType | string | None | It expect specific type of value remove from suspicious list
| targetValue | string | None | The actual value remove from suspicious list

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| data | object | This field holds the actual data retrieved from the associated action.

### Action: trendMicro.add_note_to_workbench_alert

#### Action Type: MISTRAL

#### Description: The "add_note_to_workbench_alert" action used for add note to workbench alert.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| workbench_id | string | None | This field represents a unique identifier for the workbench.
| content | text | None |  This field holds the actual content of the workbench.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| result | object | This field holds the actual data retrieved from the associated action.

### Action: trendMicro.create_cases_from_workbench_alerts

#### Action Type: CRON

#### Description: The "create_cases_from_workbench_alerts" action used to create cases from workbench alerts.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| query | string | None | The field expect string of query.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| result | object | This field holds the actual data retrieved from the associated action.

### Action: trendMicro.create_cases_from_detection_models

#### Action Type: CRON

#### Description: The "create_cases_from_detection_models" action used to create cases from detection models.
#### Outputs

| Name | Type | Description |
|------|------|-------------|
| result | object | This field holds the actual data retrieved from the associated action.

### Action: trendMicro.search_detections

#### Action Type: MISTRAL

#### Description: The "search_detections" action used for search detections.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| startDateTime | string | None | It expect start date time of query search.
| endDateTime | string | None | It expect end date time of query search.
| query | string | None | The field expect string of query to be search.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | This field indicates the overall status.
| status_msg | string | This field contains an informative message related to the search status.
| data | object | This field contains the actual data retrieved from the search.

### Action: trendMicro.search_endpoint_activities

#### Action Type: MISTRAL

#### Description: The "search_endpoint_activities" action used for search endpoint activities.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| startDateTime | string | None | It expect start datetime of query search.
| endDateTime | string | None | It expect end datetime of query search.
| query | string | None | The field expect string of query to be search.
| conf | object | None | It is expected a configuration dictionary likely containing settings relevant to the search for endpoint activities.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | This field indicates the overall status search data.
| status_msg | string | This field contains an informative message related to the search status.
| data | object | This field contains the actual data retrieved from the search.

### Action: trendMicro.query_intelligence_reports

#### Action Type: MISTRAL

#### Description: The "query_intelligence_reports" action used to automates the process of querying a threat intelligence system for specific threat data based on user-defined criteria.
#### Inputs

| Name | Type | Example | Description |
|------|------|---------|-------------|
| startDateTime | string | None | It expect start datetime of query.
| endDateTime | string | None | It expect end datetime of query.
| integration_dict | object | None | It is expected a information relevant to the query intelligence reports.
| conf | object | None | It is expected a configuration dictionary likely containing settings relevant to the query intelligence reports.

#### Outputs

| Name | Type | Description |
|------|------|-------------|
| status | string | This field indicates the overall status search data.
| status_msg | string | This field contains an informative message related to the search status.
| data | object | This field contains the actual data retrieved from the query intelligence reports.

