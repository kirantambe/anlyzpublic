from ..base_tm_action import BaseTMAction
import logging
import datetime
import json
import requests

LOG = logging.getLogger(__name__)


class CreateCasesFromDetectionModels(BaseTMAction):

    def get_description(self, detection_models):
        description = ""

        for model in detection_models:
            description += f"<br><strong>Model ID</strong>: {model.get('modelId')}" \
                           f"<br><strong>Name</strong>: {model.get('name')}" \
                           f"<br><strong>Enabled?</strong>: {model.get('enabled')}" \
                           f"<br/>______________________________________________________________________<br/>"

        return description

    def create_case_from_detection_models(self, detection_models):
        access_token = self.sporact.get("api_key")
        headers = {"Content-Type": "application/json", "X-Api-Key": f"{access_token}"}
        case = {
            'alert_source': "Trend Micro",
            'category': "Detection Models",
            'description': self.get_description(detection_models),
            'event_time': str(datetime.datetime.now()),
            'events': [],
            'extra_data': {},
            'impact': "low",
            'title': f"Detection Models enabled as of {datetime.datetime.now()}"
        }
        LOG.info(f"Creating case from detection models")
        LOG.info(case)
        response = requests.request(
            "POST",
            "{}api/cases/case/".format(self.SPORACT_URL),
            data=json.dumps(case),
            headers=headers,
        )
        LOG.info(f"Finished create case")
        if response.status_code == 201:
            resp = response.json()
            resp["response_code"] = 1
            return resp
        else:
            return {"message": response.reason, "response_code": 0}

    def run(self):
        detection_models = self.get_detection_models()
        self.create_case_from_detection_models(detection_models)
        return {"status": "success"}

    def get_detection_models(self):
        url = "/v2.0/xdr/dmm/models"
        response = self.tm.get(url)
        return response.get("data", [])
        