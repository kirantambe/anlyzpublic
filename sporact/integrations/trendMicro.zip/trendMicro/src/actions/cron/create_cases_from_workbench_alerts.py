from ..base_tm_action import BaseTMAction
import logging
import datetime
import json
import requests

LOG = logging.getLogger(__name__)


class CreateCasesFromWorkbenchAlerts(BaseTMAction):

    def get_extra_data(self, alert):
        extra_data = {
            "workbenchId": alert['workbenchId']
        }
        for indicator in alert.get("indicators", []):
            final_value = indicator["objectValue"]
            if final_value:
                extra_data[indicator["objectType"]] = final_value
        
        for scope_item in alert.get("impactScope", []):
            prefix = scope_item.get("entityType", "")
            
            entity_value = scope_item.get("entityValue", {})
            if type(entity_value) == dict:
                for key in entity_value.keys():
                    final_value = entity_value[key]
                    if final_value:
                        extra_data[f"{prefix}_{key}"] = final_value
            if type(entity_value) == str:
                if entity_value:
                    extra_data[prefix] = entity_value

        for (key, value) in extra_data.items():
            if type(value) == dict:
                if "name" in value:
                    extra_data[key] = value["name"]

        return extra_data

    def update_workbench(self, workbench_id, status):
        return self.tm.put(
            f'/v2.0/xdr/workbench/workbenches/{workbench_id}',
            json={'investigationStatus': status})

    def get_description(self, alert):
        description = f"{alert.get('description')} <br/><a href=\"{alert.get('workbenchLink')}\" target=\"_blank\">{alert['workbenchId']}</a>"
        indicators = ""
        indicator_list = alert.get("indicators", [])
        for indicator in indicator_list:
            final_value = indicator["objectValue"]
            if final_value:
                indicators = indicators + f"<p><strong>{indicator['objectType']}</strong> <br> {final_value}</p>"
        description = description + indicators
        return description

    def create_case_from_alert(self, alert):
        import json
        LOG.info("Got the following alert")
        LOG.info(json.dumps(alert))
        access_token = self.sporact.get("api_key")
        headers = {"Content-Type": "application/json", "X-Api-Key": f"{access_token}"}
        case = {
            'alert_source': alert.get("alertProvider", "Trend Micro"),
            'category': alert.get("model", "Uncategorized"),
            'description': self.get_description(alert),
            'event_time': alert["alertTriggerTimestamp"],
            'events': [],
            'extra_data': self.get_extra_data(alert),
            'impact': alert.get("modelSeverity", "medium") or "medium",
            'title': f"[{alert['workbenchId']}] {alert['model']}"
        }
        LOG.info(f"Sending create case request for {alert['workbenchId']}")
        LOG.info(case)
        case_json = json.dumps(case)
        case_json = case_json.replace("\\x00", "").replace("\\u0000", "")
        response = requests.request(
            "POST",
            "{}api/cases/case/".format(self.SPORACT_URL),
            data=case_json,
            headers=headers,
        )
        LOG.info(f"Finished create case request for {alert['workbenchId']}")
        if response.status_code == 201:

            # Update workbench status to in progress
            self.update_workbench(alert['workbenchId'], 1)
            resp = response.json()
            resp["response_code"] = 1
            return resp
        else:
            LOG.info(f"Create case request failed with the following errors: [{response.status_code}] {response.reason} {response.content}")
            return {"message": response.reason, "response_code": 0}

    def run(self):
        end = datetime.datetime.now(datetime.timezone.utc)
        start = end - datetime.timedelta(hours=96)
        LOG.info("Getting workbench for the last 96 hours")
        alerts = self.fetch_workbench_alerts(start, end)
        LOG.info(f"Creating Cases for {len(alerts)} alerts")
        for alert in alerts:
            self.create_case_from_alert(alert)
    

    def fetch_workbench_alerts(self, start, end):
        """
        This function do the loop to get all workbench alerts by changing
        the parameters of both 'offset' and 'size'.
        """
        offset = 0
        size = 100
        alerts = []
        while True:
            gotten = self.tm.get_siem(start, end, offset, size)
            if not gotten:
                break
            print(f'Workbench alerts ({offset} {offset+size}): {len(gotten)}')
            alerts.extend(gotten)
            offset = len(alerts)

        records_list = []
        i = 0
        for alert in alerts:
            LOG.info(f"Processing alert #{i}")
            print(f"Processing alert #{i}")
            LOG.info(alert)
            if alert.get("investigationStatus", 0) == 0:
                wb_id = alert['workbenchId']
                records_list.append(self.tm.get_workbench(wb_id))
            i = i + 1
        return records_list
        