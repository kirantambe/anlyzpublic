import requests
from ..base_tm_action import BaseTMAction
import time


class BaseResponseAction(BaseTMAction):

    def send_request(self, url, body):
        result = self.tm.post(url, json=body)
        action_id = result.get("actionId")

        # Wait for result retry 20 times until task
        retry_count = 0
        while True:
            wait_status = ["pending", "ongoing"]
            status_response = self.tm.get(f"/v2.0/xdr/response/getTask?actionId={action_id}")
            status = status_response.get("data", {}).get("taskStatus")
            if status in wait_status:
                time.sleep(3)
                retry_count += 1
            else:
                return {"status": status, "action_id": action_id}

            if retry_count == 20:
                return {"status": status, "action_id": action_id}

    def run(self, *args, **kwargs):
        self.send_request("", {})



