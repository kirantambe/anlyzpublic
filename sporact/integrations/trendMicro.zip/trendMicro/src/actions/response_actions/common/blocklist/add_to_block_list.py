from ...base_response_action import BaseResponseAction


class AddToBlacklist(BaseResponseAction):
    def run(self, valueType, targetValue):
        url = "/v2.0/xdr/response/block"
        body = {
            "valueType": valueType,
            "targetValue": targetValue,
        }
        return self.send_request(url, body)
