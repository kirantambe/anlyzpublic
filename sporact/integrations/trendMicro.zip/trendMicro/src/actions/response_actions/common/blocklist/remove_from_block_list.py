from ...base_response_action import BaseResponseAction


class RemoveFromBlockList(BaseResponseAction):
    def run(self, valueType, targetValue):
        url = "/v2.0/xdr/response/restoreBlock"
        body = {
            "valueType": valueType,
            "targetValue": targetValue,
        }
        return self.send_request(url, body)
