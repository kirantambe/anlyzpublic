from ..base_response_action import BaseResponseAction


class DeleteEmailMessage(BaseResponseAction):
    def run(self, messageId, mailBox, messageDeliveryTime, productId="sca", description=""):
        url = "/v2.0/xdr/response/deleteMessage"
        body = {
            "messageId": messageId,
            "mailBox": mailBox,
            "messageDeliveryTime": messageDeliveryTime,
            "productId": productId,
            "description": description
        }
        return self.send_request(url, body)