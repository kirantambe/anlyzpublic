from ..base_response_action import BaseResponseAction


class QuarantineEmailMessage(BaseResponseAction):
    def run(self, messageId, mailBox, messageDeliveryTime, productId="sca", description=""):
        url = "/v2.0/xdr/response/quarantineMessage"
        
        if productId in ["", None, "None"]:
            productId="sca"
        body = {
            "messageId": messageId,
            "mailBox": mailBox,
            "messageDeliveryTime": messageDeliveryTime,
            "productId": productId,
            "description": description
        }
        return self.send_request(url, body)