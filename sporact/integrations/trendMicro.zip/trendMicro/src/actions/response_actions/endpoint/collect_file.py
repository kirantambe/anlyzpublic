import time
from ..base_response_action import BaseResponseAction


class CollectFile(BaseResponseAction):
    def run(self, computerId, productId, filePath, os, description=""):
        url = "/v2.0/xdr/response/collectFile"
        body = {
            "computerId": computerId,
            "filePath": filePath,
            "productId": productId,
            "description": description,
            "os": os
        }
        response = self.send_request(url, body)
        action_id = response.get("action_id")

        if response.get("status")=="ongoing":
            retry_count = 0
            while True:
                status_response = self.tm.get(f"/v2.0/xdr/response/getTask?actionId={action_id}")
                status = status_response.get("data", {}).get("taskStatus")
                if status=="success":
                    break
                else:
                    time.sleep(10)
                retry_count += 1
                if retry_count == 60:
                    raise Exception(f"Process is taking too long to complete")

        downloadInfo = self.tm.get(f"/v2.0/xdr/response/downloadInfo?actionId={action_id}")
        
        return {
            "action_id": action_id,
            **downloadInfo.get("data", {})
        }