from ..base_response_action import BaseResponseAction


class IsolateEndpoint(BaseResponseAction):
    def run(self, computerId, productId, description=""):
        url = "/v2.0/xdr/response/isolate"
        """
        {'data': {'executedTime': 1633516234, 'createdTime': 1633516233, 'finishedTime': 1633516236, 'taskStatus': 'failed', 'error': {'code': 'AgentNotFound', 'message': 'The target Security Agent has been moved or uninstalled.'}}}
        """
        body = {
            "computerId": computerId,
            "productId": productId,
            "description": description
        }
        return self.send_request(url, body)