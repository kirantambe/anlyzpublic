from ..base_response_action import BaseResponseAction


class RestoreIsolatedEndpoint(BaseResponseAction):
    def run(self, computerId, productId, description=""):
        url = "/v2.0/xdr/response/restoreIsolate"
        
        if productId in ["None", "", None]:
            body = {
                "computerId": computerId,
                "description": description
                }
        else:
            body = {
                "computerId": computerId,
                "productId": productId,
                "description": description
                }
        return self.send_request(url, body)