from ..base_response_action import BaseResponseAction


class TerminateProcess(BaseResponseAction):
    def run(self, computerId, fileSha1, productId, description="", filename=""):
        url = "/v2.0/xdr/response/restoreIsolate"
        body = {
            "computerId": computerId,
            "fileSha1": fileSha1,
            "productId": productId,
            "description": description,
            "filename": filename
        }
        if productId in ["None", "", None]:
            del body["productId"]
        if filename in ["None", "", None]:
            del body["filename"]

        return self.send_request(url, body)