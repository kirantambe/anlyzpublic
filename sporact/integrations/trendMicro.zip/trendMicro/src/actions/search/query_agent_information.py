from ..base_tm_action import BaseTMAction


class QueryAgentInformation(BaseTMAction):
    def run(self, field, value):
        url = "/v2.0/xdr/eiqs/query/agentInfo"
        body = {
            "criteria": {
                "field": field,
                "value": value
            },
        }

        return self.tm.post(url, json=body)