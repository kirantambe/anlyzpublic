from ..base_tm_action import BaseTMAction


class QueryInformationOfEndpoint(BaseTMAction):
    def run(self, computerId):
        url = "/v2.0/xdr/eiqs/query/endpointInfo"
        body = {
            "computerId": computerId,
        }

        return self.tm.post(url, json=body)