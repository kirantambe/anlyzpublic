from sporact_base.sporact_base_action import SporactBaseAction
from datetime import datetime, timedelta
import requests


class QueryIntelligenceReports(SporactBaseAction):
    def run(self, from_timestamp, to_timestamp, integration_dict, conf):
        if not from_timestamp:
            from_timestamp = datetime.now() - timedelta(days=7)
            from_timestamp = from_timestamp.replace(microsecond=0).isoformat()
        if not to_timestamp:
            to_timestamp = datetime.now()
            to_timestamp = to_timestamp.replace(microsecond=0).isoformat()

        url = "/v3.0/threatintel/tasks"
        is_hit = integration_dict["isHit"]
        if is_hit == "any":
            query = "sweepType eq 'manual'"
        else:
            query = "sweepType eq 'manual' AND isHit eq " + str(is_hit).lower()
        query_params = {"filter": query, "startDateTime": from_timestamp,
                        "endDateTime": to_timestamp}
        headers = {
            "Authorization": "Bearer " + conf.get("api_key")
        }
        try:
            return requests.get(conf.get("server_selection") + url, headers=headers, params=query_params)
        except Exception as e:
            return {
                "status": "error",
                "status_msg": str(e),
                "data": {}
            }
