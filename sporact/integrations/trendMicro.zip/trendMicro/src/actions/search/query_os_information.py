from ..base_tm_action import BaseTMAction


class QueryOsInformation(BaseTMAction):
    def run(self):
        url = "/v2.0/xdr/eiqs/query/osSummary"
        return self.tm.get(url)