from ..base_tm_action import BaseTMAction
from datetime import datetime, timedelta
import time
from dateutil.parser import parse as parse_date


class SearchForData(BaseTMAction):
    def run(self, from_timestamp, to_timestamp, source, query):
        if from_timestamp in [None, "", "None"]:
            from_timestamp = int(time.mktime((datetime.now() - timedelta(days=730)).timetuple()))
        if to_timestamp in [None, "", "None"]:
            to_timestamp = int(time.mktime(datetime.now().timetuple()))

        url = "/v2.0/xdr/search/data"
        body = {
            "from": from_timestamp,
            "to": to_timestamp,
            "source": source,
            "query": query
        }
        try:
            return self.tm.post(url, json=body)
        except Exception as e:
            return {
                "status": "error",
                "status_msg": str(e),
                "data": {}
            }