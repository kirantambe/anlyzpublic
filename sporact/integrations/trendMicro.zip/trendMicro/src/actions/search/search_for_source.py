
from sporact_base.sporact_base_action import SporactBaseAction
from datetime import datetime, timedelta
import time
import requests


class SearchForData(SporactBaseAction):
    def run(self, from_timestamp, to_timestamp, source, query, conf):
        if from_timestamp in ["None", "", None]:
            from_timestamp = int(time.mktime((datetime.now() - timedelta(days=7)).timetuple()))
        else:
            from_timestamp = int(time.mktime(from_timestamp.timetuple()))
        if to_timestamp in ["None", "", None]:
            to_timestamp = int(time.mktime(datetime.now().timetuple()))
        else:
            to_timestamp = int(time.mktime(to_timestamp.timetuple()))

        url = "/v2.0/xdr/search/data"
        body = {
            "from": from_timestamp,
            "to": to_timestamp,
            "source": source,
            "query": query
        }
        headers = {
            "Authorization": "Bearer " + conf.get("api_key"),
            "Content-Type": "application/json;charset=utf-8",
        }
        try:
            return requests.post(conf.get("server_selection") + url, headers=headers, json=body)
        except Exception as e:
            return {
                "status": "error",
                "status_msg": str(e),
                "data": {}
            }
