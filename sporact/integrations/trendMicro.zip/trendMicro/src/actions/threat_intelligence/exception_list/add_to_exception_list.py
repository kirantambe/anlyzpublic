from ...base_tm_action import BaseTMAction


class AddToExceptionList(BaseTMAction):
    def run(self, valueType, targetValue, description):
        url = "/v2.0/xdr/threatintel/suspiciousObjects/exceptions"
        body = {
            "data": [
                {
                    "type": valueType,
                    "value": targetValue,
                    "description": description
                }
            ]
        }
        return self.tm.post(url, json=body)
