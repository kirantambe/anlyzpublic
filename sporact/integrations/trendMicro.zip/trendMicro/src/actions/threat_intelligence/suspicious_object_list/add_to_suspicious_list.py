from ...base_tm_action import BaseTMAction


class AddToSuspiciousList(BaseTMAction):
    def run(self, valueType, targetValue, description, scanAction, riskLevel, expiredDay):
        url = "/v2.0/xdr/threatintel/suspiciousObjects"
        body = {
            "data": [
                {
                    "type": valueType,
                    "value": targetValue,
                    "description": description,
                    "scanAction": scanAction,
                    "riskLevel": riskLevel,
                    "expiredDay": 0
                }
            ]
        }
        return self.tm.post(url, json=body)
