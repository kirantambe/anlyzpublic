from ...base_tm_action import BaseTMAction


class AddToSuspiciousList(BaseTMAction):
    def run(self, valueType, targetValue, description, scanAction, riskLevel, expiredDay):
        url = "/v2.0/xdr/threatintel/suspiciousObjects"
        body = {"data": [
            {
                "type": valueType,
                "value": targetValue,
                "expiredDay": 0,
                "description": description
            }
            ]}
        
        if scanAction not in [None, "", "None"]:
            body["data"][0]["scanAction"] = scanAction
        if riskLevel not in [None, "", "None"]:
            body["data"][0]["riskLevel"] = riskLevel

        return self.tm.post(url, json=body)
