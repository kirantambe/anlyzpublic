from ...base_tm_action import BaseTMAction


class RemoveFromSuspiciousList(BaseTMAction):
    def run(self, valueType, targetValue):
        url = "/v2.0/xdr/threatintel/suspiciousObjects/delete"
        body = {
            "data": [
                {
                    "type": valueType,
                    "value": targetValue,
                }
            ]
        }
        return self.tm.post(url, json=body)
