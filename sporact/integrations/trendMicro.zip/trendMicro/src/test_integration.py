from sporact_base.sporact_base_action import SporactBaseAction
import requests


class TestIntegration(SporactBaseAction):
    def run(self, conf, inputs):
        url = "/v2.0/siem/events"
        headers = {
            "Authorization": "Bearer " + conf.get("api_key"),
            "Content-Type": "application/json;charset=utf-8",
        }
        response = requests.get(conf.get("server_selection") + url, headers=headers)
        if response.status_code == 200:
            response_dict = (("message", "Successfully tested the configuration!"), ("status", "success"))
        else:
            response_dict = (("message", "Invalid configuration!"), ("status", "failed"))
        return response_dict