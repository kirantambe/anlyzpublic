from src.add_domain_to_block_list import AddDomainToBlockList
import unittest


class TestAddDomainToBlockList(unittest.TestCase):
    def test(self):
        action = AddDomainToBlockList({"conf": {"api_key": "<api_key>"}})
        result = action.run("anlyz.io")
        assert result["status"] == "success"
        
