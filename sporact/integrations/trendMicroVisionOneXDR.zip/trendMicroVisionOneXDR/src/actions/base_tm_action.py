import datetime
import re

import requests
import logging
from sporact_base.sporact_base_action import SporactBaseAction

LOG = logging.getLogger(__name__)
# default settings
V1_URL = "https://api.xdr.trendmicro.com"


def check_datetime_aware(d):
    return (d.tzinfo is not None) and (d.tzinfo.utcoffset(d) is not None)


class TmV1Client:
    base_url_default = V1_URL
    WB_STATUS_IN_PROGRESS = 1

    def __init__(self, token, base_url=None):
        if not token:
            raise ValueError("Authentication token missing")
        self.token = token
        self.base_url = base_url or TmV1Client.base_url_default

    def make_headers(self):
        return {
            "Authorization": "Bearer " + self.token,
            "Content-Type": "application/json;charset=utf-8",
        }


    def get(self, path, **kwargs):
        kwargs.setdefault("headers", {}).update(self.make_headers())
        url = path if path.startswith("http") else (self.base_url + path)
        r = requests.get(url, **kwargs)
        if 200 <= r.status_code < 300:
            try:
                return r.json()
            except:
                return r.content
        try:
            rjson = r.json()
            message = rjson["error"]["message"]
            raise RuntimeError(message)
        except:
            raise RuntimeError(
                f"Request unsuccessful (GET {path}):" f" {r.status_code} {r.text}"
            )

    def patch(self, path, **kwargs):
        kwargs.setdefault("headers", {}).update(self.make_headers())
        r = requests.patch(self.base_url + path, **kwargs)
        if 200 <= r.status_code < 300:
            try:
                return r.json()
            except:
                return r.content

        if 204 == r.status_code:
            return r.content

        try:
            rjson = r.json()
            message = rjson["error"]["message"]
            raise RuntimeError(message)
        except:
            raise RuntimeError(
                f"Request unsuccessful (PUT {path}):" f" {r.status_code} {r.text}"
            )

    def post(self, path, **kwargs):

        LOG.info(f"Making post request to {path} with parameters: {kwargs}")
        kwargs.setdefault("headers", {}).update(self.make_headers())
        r = requests.post(self.base_url + path, **kwargs)
        if 200 <= r.status_code < 300:
            try:
                return r.json()
            except:
                return r.content
        try:
            rjson = r.json()
            message = rjson["error"]["message"]
            raise RuntimeError(message)
        except:
            raise RuntimeError(
                f"Request unsuccessful (POST {path}):" f" {r.status_code} {r.text}"
            )

    def get_siem(self, start, end):
        if not check_datetime_aware(start):
            start = start.astimezone()
        if not check_datetime_aware(end):
            end = end.astimezone()
        start = start.astimezone(datetime.timezone.utc)
        end = end.astimezone(datetime.timezone.utc)
        start = start.isoformat(timespec="milliseconds").split(".")[0]+ "Z"
        end = end.isoformat(timespec="milliseconds").split(".")[0]+ "Z"
        headers = {"TMV1-Filter": "status eq 'Open'"}
        alerts = []

        response = self.get(
            "/v3.0/workbench/alerts",
            params=dict(
               (("startDateTime", start), ("endDateTime", end))
            ),
            headers=headers
        )
        total_items = response.get("totalCount", 0)
        LOG.info(f"Total {total_items} workbenches")
        next_link = response.get("nextLink")
        alerts = response.get("items", [])
        while next_link:
            response = self.get(next_link, headers=headers)
            next_link = response.get("nextLink")
            alerts = alerts + response.get("items", [])
        return alerts

    def get_workbench(self, workbench_id):
        return self.get(f"/v3.0/workbench/alerts/{workbench_id}")


class BaseTMAction(SporactBaseAction):

    def get_value_type(self, value):
        """
        "file_sha1",
            "ip",
            "domain",
            "url",
            "mailbox"
        """
        if re.match(r'\b[0-9a-f]{40}\b', value):
            return "sha1"

        if re.match("^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", value):
            return "ip"

        if re.match(r'^([a-zA-Z0-9][-a-zA-Z0-9]*[a-zA-Z0-9]\.)+([a-zA-Z0-9]{2,5})$', value):
            return "domain"

        if re.match(r'^((mailto\:|(news|(ht|f)tp(s?))\://){1}\S+)$', value):
            return "url"

        if re.match("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$", value):
            return "mailbox"


    def __init__(self, extracontent):
        super().__init__(extracontent)
        if "server_selection" in self.conf:
            server_selection = self.conf.get("server_selection")
        else:
            server_selection = None
        self.tm = TmV1Client(self.conf.get("api_key"), server_selection)
