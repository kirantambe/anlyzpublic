from ..base_tm_action import BaseTMAction
import logging
import datetime
import json
import requests

LOG = logging.getLogger(__name__)


def convert_to_html_table(data):
    def process_data(data):
        if isinstance(data, dict):
            rows = []
            for key, value in data.items():
                value = process_data(value)
                rows.append(f"<tr><td rowspan=1 colspan=1><p>{key}</p></td>{value}</tr>")
            table_data = "\n".join(rows)
            return table_data
        elif isinstance(data, list):
            table_data = ""
            for item in data:
                value = process_data(item)
                table_data += value
            return table_data
        else:
            return f"<td rowspan=1 colspan=1><p>{data}</p></td>"

    table_data = process_data(data)

    html_table = f"""
    <table>
        <tbody>
            {table_data}
        </tbody>
    </table>
    """

    return html_table

class CreateCasesFromWorkbenchAlerts(BaseTMAction):

    def get_extra_data(self, alert):
        extra_data = {
            "workbenchId": alert['id'],
            "source_id": alert['id']
        }
        for idx, indicator in enumerate(alert.get("indicators", [])):
            final_value = indicator["value"]
            if final_value:
                field_name = indicator.get("field") or indicator.get("type", f"unknown_field{idx}")
                extra_data[field_name] = final_value
        for scope_item in alert.get("impactScope", {}).get("entities",[]):
            prefix = scope_item.get("entityType", "")
            
            entity_value = scope_item.get("entityValue", {})
            if type(entity_value) == dict:
                for key in entity_value.keys():
                    final_value = entity_value[key]
                    if final_value:
                        extra_data[f"{prefix}_{key}"] = final_value
            if type(entity_value) == str:
                if entity_value:
                    extra_data[prefix] = entity_value

        for (key, value) in extra_data.items():
            if type(value) == dict:
                if "name" in value:
                    extra_data[key] = value["name"]

        return extra_data

    def update_workbench(self, workbench_id, status):
        return self.tm.patch(
            f'/v3.0/workbench/alerts/{workbench_id}',
            json={'status': status})

    def get_description(self, alert):
        description = f"{alert.get('description')} <br/><a href=\"{alert.get('workbenchLink')}\" target=\"_blank\">{alert['id']}</a><br/>"
        description = description + "<h5>Indicators</h5>" + convert_to_html_table(alert.get("indicators", [])) + "<br/>"
        description = description + "<h5>Impact Scope</h5>" + convert_to_html_table(alert.get("impactScope", {})) + "<br/>"
        description = description + "<h5>Matched Rules</h5>" + convert_to_html_table(alert.get("matchedRules", [])) + "<br/>"
        return description

    def create_case_from_alert(self, alert):
        import json
        LOG.info("Got the following alert")
        LOG.info(json.dumps(alert))
        access_token = self.sporact.get("api_key")
        headers = {"Content-Type": "application/json", "X-Api-Key": f"{access_token}"}
        case = {
            'alert_source': alert.get("alertProvider", "Trend Micro Vision One XDR"),
            'category': alert.get("model", "Uncategorized"),
            'description': self.get_description(alert),
            'event_time': alert["createdDateTime"],
            'events': [],
            'extra_data': self.get_extra_data(alert),
            'impact': alert.get("severity", "medium") or "medium",
            'title': f"[{alert['id']}] {alert['model']}"
        }
        LOG.info(f"Sending create case request for {alert['id']}")
        LOG.info(case)
        case_json = json.dumps(case)
        case_json = case_json.replace("\\x00", "").replace("\\u0000", "")
        response = requests.request(
            "POST",
            "{}api/cases/case/".format(self.SPORACT_URL),
            data=case_json,
            headers=headers,
        )
        LOG.info(f"Finished create case request for {alert['id']}")
        if response.status_code == 201 or response.status_code == 409:

            # Update workbench status to in progress
            self.update_workbench(alert['id'], "In Progress")
            resp = response.json()
            resp["response_code"] = 1
            return resp
        else:
            LOG.info(f"Create case request failed with the following errors: [{response.status_code}] {response.reason} {response.content}")
            return {"message": response.reason, "response_code": 0}

    def run(self):
        end = datetime.datetime.now(datetime.timezone.utc)
        start = end - datetime.timedelta(hours=96)
        LOG.info("Getting workbench for the last 96 hours")
        alerts = self.fetch_workbench_alerts(start, end)
        LOG.info(f"Creating Cases for {len(alerts)} alerts")
        for alert in alerts:
            self.create_case_from_alert(alert)

    def fetch_workbench_alerts(self, start, end):
        """
        {
        "schemaVersion":"1.14",
        "id":"WB-10188-20230528-00000",
        "investigationStatus":"New",
        "workbenchLink":"https://portal.xdr.trendmicro.com/index.html#/workbench/alerts/WB-10188-20230528-00000?ref=0c12e642ca5b7ed4436e5f23f568ae10066608d3",
        "alertProvider":"SAE",
        "modelId":"0fafceaa-55df-4aef-811a-c83f50604e72",
        "model":"AWS IAM Policy Attached To User Or Role Or Group",
        "score":23,
        "severity":"low",
        "createdDateTime":"2023-05-28T06:47:19Z",
        "updatedDateTime":"2023-05-28T19:00:30Z",
        "impactScope":{
            "desktopCount":0,
            "serverCount":0,
            "accountCount":1,
            "emailAddressCount":0,
            "entities":[
                {
                    "entityType":"account",
                    "entityValue":"arn:aws:iam::650143975734:user/sunreaver",
                    "entityId":"arn:aws:iam::650143975734:user/sunreaver",
                    "relatedEntities":[

                    ],
                    "relatedIndicatorIds":[
                    1,
                    2,
                    3,
                    4
                    ],
                    "provenance":[
                    "Alert"
                    ]
                }
            ]
        },
        "description":"An attachment of an AWS IAM policy to user or group or role was detected.",
        "matchedRules":[
            {
                "id":"d1e20ab8-9bc7-11ec-b909-0242ac120002",
                "name":"AWS IAM Policy Attached To User Or Role Or Group",
                "matchedFilters":[
                    {
                    "id":"504c87a3-7be6-41d3-8a1a-5a3d0ea31b4b",
                    "name":"AWS IAM Policy Attached To A Role",
                    "matchedDateTime":"2023-05-28T06:44:18.000Z",
                    "mitreTechniqueIds":[
                        "T1078"
                    ],
                    "matchedEvents":[
                        {
                            "uuid":"eb6a1eac-0631-40cf-9b80-e7755215928b",
                            "matchedDateTime":"2023-05-28T06:44:18.000Z",
                            "type":"iam.amazonaws.com"
                        }
                    ]
                    }
                ]
            }
        ],
        "indicators":[
            {
                "id":1,
                "type":"cloud_identity",
                "field":"userIdentity.arn",
                "value":"arn:aws:iam::650143975734:user/sunreaver",
                "relatedEntities":[
                    "arn:aws:iam::650143975734:user/sunreaver"
                ],
                "filterIds":[
                    "504c87a3-7be6-41d3-8a1a-5a3d0ea31b4b"
                ],
                "provenance":[
                    "Alert"
                ]
            },
            {
                "id":2,
                "type":"cloud_permission",
                "field":"requestParameters.policyArn",
                "value":"arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole",
                "relatedEntities":[
                    "arn:aws:iam::650143975734:user/sunreaver"
                ],
                "filterIds":[
                    "504c87a3-7be6-41d3-8a1a-5a3d0ea31b4b"
                ],
                "provenance":[
                    "Alert"
                ]
            },
            {
                "id":3,
                "type":"ip",
                "field":"sourceIPAddress",
                "value":"cloudformation.amazonaws.com",
                "relatedEntities":[
                    "arn:aws:iam::650143975734:user/sunreaver"
                ],
                "filterIds":[
                    "504c87a3-7be6-41d3-8a1a-5a3d0ea31b4b"
                ],
                "provenance":[
                    "Alert"
                ]
            },
            {
                "id":4,
                "type":"text",
                "field":"eventName",
                "value":"AttachRolePolicy",
                "relatedEntities":[
                    "arn:aws:iam::650143975734:user/sunreaver"
                ],
                "filterIds":[
                    "504c87a3-7be6-41d3-8a1a-5a3d0ea31b4b"
                ],
                "provenance":[
                    "Alert"
                ]
            }
        ]
        }

        """
        alerts = self.tm.get_siem(start, end)
        records_list = []
        i = 0
        for alert in alerts:
            LOG.info(f"Processing alert #{i}")
            LOG.info(alert)
            if alert.get("status", "") == "Open":
                wb_id = alert['id']
                records_list.append(self.tm.get_workbench(wb_id))
            i = i + 1
        return records_list