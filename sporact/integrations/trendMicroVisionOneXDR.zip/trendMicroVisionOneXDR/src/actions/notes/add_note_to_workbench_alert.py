import logging

import requests
from ..base_tm_action import BaseTMAction


class AddNoteToWorkbenchAlert(BaseTMAction):
    def run(self, content):
        workbench_id = self.case.get("extra_data", {}).get("workbenchId")
        self.tm.post(f"/v3.0/workbench/alerts/{workbench_id}/notes", json={"content": content})
        return {"result": {"status": "success"}}

