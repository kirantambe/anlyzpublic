import requests

from ..base_tm_action import BaseTMAction
import time


class BaseResponseAction(BaseTMAction):

    def send_request(self, url, body):
        result = self.tm.post(url, json=body)

        if result and len(result):
            if result[0].get("status") == 202:
                headers = result[0].get("headers", [])
                if len(headers):
                    result_url = result[0].get("headers")[0].get("value")
                    if result_url:
                        result_url = result_url.replace(self.conf['server_selection'], "")
                        # Wait for result retry 20 times until task
                        retry_count = 0
                        while True:
                            wait_status = ["pending", "ongoing", "running"]
                            status_response = self.tm.get(result_url)
                            status = status_response.get("status", None)
                            if status in wait_status:
                                time.sleep(3)
                                retry_count += 1
                            else:
                                return {"status": status}

                            if retry_count == 20:
                                return {"status": status}
            else:
                try:
                    msg = result[0]['body']['error']['message']
                    return {"status": msg}
                except:
                    pass
        return {"status": "failed"}

    def run(self, *args, **kwargs):
        self.send_request("", {})



