from ....base_tm_action import BaseTMAction
from ...base_response_action import BaseResponseAction


class BaseAddToBlockList(BaseResponseAction):
    VALUE_TYPE = ""

    def run(self, target_value):
        if not self.VALUE_TYPE:
            raise Exception("Incorrect targetValue. Only values of type "
                            "file_sha1, ip, domain, url, mailbox are supported")

        url = "/v3.0/response/suspiciousObjects"

        return self.send_request(url, [{
            self.VALUE_TYPE: target_value,
        }])


class AddURLToBlockList(BaseAddToBlockList):
    VALUE_TYPE = "url"


class AddDomainToBlockList(BaseAddToBlockList):
    VALUE_TYPE = "domain"


class AddFileHashToBlockList(BaseAddToBlockList):
    VALUE_TYPE = "fileSha1"


class AddSenderMailAddressToBlockList(BaseAddToBlockList):
    VALUE_TYPE = "senderMailAddress"


class AddIPToBlockList(BaseAddToBlockList):
    VALUE_TYPE = "ip"
