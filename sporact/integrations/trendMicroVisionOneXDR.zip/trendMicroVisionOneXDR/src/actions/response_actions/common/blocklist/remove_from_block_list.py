from ...base_response_action import BaseResponseAction


class BaseRemoveFromBlockList(BaseResponseAction):
    VALUE_TYPE = ""

    def run(self, target_value):
        url = "/v3.0/response/suspiciousObjects/delete"

        return self.send_request(url, [{
            self.VALUE_TYPE: target_value,
        }])


class RemoveURLFromBlockList(BaseRemoveFromBlockList):
    VALUE_TYPE = "url"


class RemoveDomainFromBlockList(BaseRemoveFromBlockList):
    VALUE_TYPE = "domain"


class RemoveFileHashFromBlockList(BaseRemoveFromBlockList):
    VALUE_TYPE = "fileSha1"


class RemoveSenderMailAddressFromBlockList(BaseRemoveFromBlockList):
    VALUE_TYPE = "senderMailAddress"


class RemoveIPFromBlockList(BaseRemoveFromBlockList):
    VALUE_TYPE = "ip"
