from ...base_response_action import BaseResponseAction


class CancelResponseTask(BaseResponseAction):
    def run(self, response_action_id):
        if response_action_id in [None, "", "None"]:
            raise Exception("Please provide a valid Response Action Id")

        url = "/v3.0/response/tasks/cancel"
        body = [{
            'id': response_action_id
        }]
        response= self.tm.post(url, json=body)
        if response[0].get("status")==204:    
            return {"status": "success"}
        else:
            return {"status": response}