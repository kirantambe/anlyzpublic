from ....base_tm_action import BaseTMAction


class GetActionList(BaseTMAction):
    def run(self, task_id, top=10, orderBy="lastActionDateTime desc", query=""):
        if not task_id:
            raise Exception("Please provide a valid Task ID")

        url = f"/v3.0/securityPlaybooks/tasks/{task_id}/actions"
        if top in [None, "", "None"]:
            top = 10
        if orderBy in [None, "", "None"]:
            orderBy="lastActionDateTime desc"
        if query in [None, "", "None"]:
            query=""

        params = {
            'top':  int(top),
            'orderBy': orderBy
        }
        headers = {
            "TMV1-Query": query
        }

        response = self.tm.get(url, headers=headers, params=params)

        return {"results": response}