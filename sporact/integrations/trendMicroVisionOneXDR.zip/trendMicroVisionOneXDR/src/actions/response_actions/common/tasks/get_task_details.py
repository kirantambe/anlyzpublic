from ....base_tm_action import BaseTMAction


class GetTaskDetails(BaseTMAction):
    def run(self, task_id):
        if task_id in [None, "", "None"]:
            raise Exception("Please provide a valid Task ID")

        url = f"/v3.0/securityPlaybooks/tasks/{task_id}"
        response = self.tm.get(url)
        return {"task_details": response}