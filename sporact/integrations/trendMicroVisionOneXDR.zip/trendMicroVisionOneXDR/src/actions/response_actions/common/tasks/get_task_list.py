from ....base_tm_action import BaseTMAction

from datetime import datetime, timedelta


class GetTaskList(BaseTMAction):
    def run(self, from_timestamp, to_timestamp, dateTimeTarget="createdDateTime", top=10, orderBy="lastActionDateTime desc"):
        if from_timestamp in [None, "", "None"]:
            from_timestamp = datetime.strftime((datetime.utcnow()-timedelta(7)), "%Y-%m-%dT%H:%M:%SZ")
        else:
            from_timestamp = from_timestamp.rstrip('z')+'z'
        if to_timestamp in [None, "", "None"]:
            to_timestamp = datetime.strftime(datetime.utcnow(), "%Y-%m-%dT%H:%M:%SZ")
        else:
            to_timestamp = to_timestamp.rstrip('z')+'z'
        if top in [None, "", "None"]:
            top = 10
        if dateTimeTarget in [None, "", "None"]:
            dateTimeTarget="createdDateTime"
        if orderBy in [None, "", "None"]:
            orderBy="lastActionDateTime desc"

        query_params= {
            'startDateTime': from_timestamp,
            'endDateTime': to_timestamp,
            'dateTimeTarget': dateTimeTarget,
            'top': int(top),
            'orderBy': orderBy  
            }
        url = "/v3.0/securityPlaybooks/tasks"
        response = self.tm.get(url, params=query_params)
        return {"results": response}