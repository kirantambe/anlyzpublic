from ...base_tm_action import BaseTMAction


class GetCvesDetetctedInADevice(BaseTMAction):
    def run(self, query="", top=10, orderBy="deviceName asc"):
        if top in [None, "", "None"]:
            top= 10
        if orderBy in [None, "", "None"]:
            orderBy= "deviceName asc"

        url = '/v3.0/asrm/vulnerableDevices'
        query_params = {
            'top': int(top),
            'orderBy': orderBy
        }
        headers= {}
        if query not in ["", None, "None"]:
            headers = {"TMV1-Filter": query}
        
        response = self.tm.get(url, params = query_params, headers=headers)
        if response.get("items"):
            return {'results': response['items']}
        else:
            return {'results': response}