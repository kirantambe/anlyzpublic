from ..base_response_action import BaseResponseAction


class DisableUserAccount(BaseResponseAction):
    def run(self, accountName):
        url = "/v3.0/response/domainAccounts/disable"
        return self.send_request(url, [{
            "accountName": accountName
        }])