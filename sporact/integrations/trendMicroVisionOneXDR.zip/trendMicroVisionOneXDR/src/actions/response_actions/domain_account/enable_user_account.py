from ..base_response_action import BaseResponseAction


class EnableUserAccount(BaseResponseAction):
    def run(self, accountName):
        url = "/v3.0/response/domainAccounts/enable"
        return self.send_request(url, [{
            "accountName": accountName
        }])