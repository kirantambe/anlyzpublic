from ..base_response_action import BaseResponseAction


class ForcePasswordReset(BaseResponseAction):
    def run(self, accountName):
        url = "/v3.0/response/domainAccounts/resetPassword"
        return self.send_request(url, [{
            "accountName": accountName
        }])