from ..base_response_action import BaseResponseAction


class ForceSignout(BaseResponseAction):
    def run(self, accountName):
        url = "/v3.0/response/domainAccounts/signOut"
        return self.send_request(url, [{
            "accountName": accountName
        }])