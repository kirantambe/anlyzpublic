from ..base_response_action import BaseResponseAction


class QuarantineEmailMessage(BaseResponseAction):
    def run(self, messageId):
        url = "/v3.0/response/emails/quarantine"
        if messageId in [None, "", "None"]:
            messageId = self.case.get("extra_data", {}).get("email_message_id")
        return self.send_request(url, [{
            "messageId": messageId
        }])