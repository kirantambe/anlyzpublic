from ..base_response_action import BaseResponseAction


class CollectFile(BaseResponseAction):
    def run(self, agentGuid, filePath):
        url = "/v3.0/response/endpoints/collectFile"
        return self.send_request(url, [{
            "agentGuid": agentGuid,
            "filePath": filePath
        }])
