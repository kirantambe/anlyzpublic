from ..base_response_action import BaseResponseAction


class IsolateEndpoint(BaseResponseAction):
    def run(self, agentGuid, description=""):
        url = "/v3.0/response/endpoints/isolate"
        body = [{
            "agentGuid": agentGuid,
        }]
        return self.send_request(url, body)