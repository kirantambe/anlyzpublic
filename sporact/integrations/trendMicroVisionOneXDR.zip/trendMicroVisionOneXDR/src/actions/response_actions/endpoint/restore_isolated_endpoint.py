from ..base_response_action import BaseResponseAction


class RestoreIsolatedEndpoint(BaseResponseAction):
    def run(self, agentGuid):
        url = "/v3.0/response/endpoints/restore"
        body = [{
            "agentGuid": agentGuid
        }]
        return self.send_request(url, body)