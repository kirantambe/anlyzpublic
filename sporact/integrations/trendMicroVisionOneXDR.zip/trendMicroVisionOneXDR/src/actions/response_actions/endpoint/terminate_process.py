from ..base_response_action import BaseResponseAction


class TerminateProcess(BaseResponseAction):
    def run(self, agentGuid, fileSha1):
        url = "/v3.0/response/endpoints/terminateProcess"
        body = [{
            "agentGuid": agentGuid,
            "fileSha1": fileSha1
        }]
        return self.send_request(url, body)