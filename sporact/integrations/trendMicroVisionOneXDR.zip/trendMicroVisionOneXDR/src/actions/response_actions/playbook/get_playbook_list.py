from ...base_tm_action import BaseTMAction


class GetPlaybookList(BaseTMAction):
    def run(self, top=10, orderBy="updatedDateTime desc"):
        if top in [None, "", "None"]:
            top= 10
        if orderBy in [None, "", "None"]:
            orderBy= "updatedDateTime desc"

        url = "/v3.0/securityPlaybooks/playbooks"
        query_params = {
            'top': int(top),
            'orderBy': orderBy
        }
        response = self.tm.get(url, params = query_params)
        return {"results": response}