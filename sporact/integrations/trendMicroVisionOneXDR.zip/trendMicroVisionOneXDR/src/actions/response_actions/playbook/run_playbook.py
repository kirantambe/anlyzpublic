from ..base_response_action import BaseResponseAction


class RunPlaybook(BaseResponseAction):

    def run(self, playbook_ids, target_type="", alert_id=""):
        if playbook_ids in [None, "", "None"]:
            raise Exception("Please provide a valid Playbook Id")

        url = '/v3.0/securityPlaybooks/playbooks/run'
        body=[]
        for id in playbook_ids.split(","):
            if target_type in [None, "", "None"] or alert_id in [None, "", "None"]:
                id_object= {"id": id}
                body.append(id_object)
            else:
                id_object = {"id": id, "parameter": {}}
                id_object["parameter"]["type"] = target_type
                id_object["parameter"]["id"] = alert_id
                body.append(id_object)
        return self.send_request(url, body)