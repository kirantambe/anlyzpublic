from sporact_base.sporact_base_action import SporactBaseAction
from datetime import datetime, timedelta
import requests


class SearchDetections(SporactBaseAction):
    def run(self, from_timestamp, to_timestamp, query, conf):
        if not from_timestamp:
            from_timestamp = datetime.now() - timedelta(days=7)
            from_timestamp = from_timestamp.replace(microsecond=0).isoformat()
        if not to_timestamp:
            to_timestamp = datetime.now()
            to_timestamp = to_timestamp.replace(microsecond=0).isoformat()

        url = "/v3.0/search/detections"
        params = {
            "startDateTime": from_timestamp,
            "endDateTime": to_timestamp
        }
        headers = {
            "Authorization": "Bearer " + conf.get("api_key"),
            "TMV1-Query": query,
            "Content-Type": "application/json;charset=utf-8",
        }
        try:
            return requests.get(conf.get("server_selection") + url, headers=headers, params=params)
        except Exception as e:
            return {
                "status": "error",
                "status_msg": str(e),
                "data": {}
            }
