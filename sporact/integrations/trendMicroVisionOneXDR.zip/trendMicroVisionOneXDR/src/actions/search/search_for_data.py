import logging
import re

from ..base_tm_action import BaseTMAction
from datetime import datetime, timedelta
import time
from dateutil.parser import parse as parse_date

LOG = logging.getLogger(__name__)


class BaseSearchAction(BaseTMAction):

    SEARCH_URL = "/v3.0/search/endpointActivities"
    def run(self, from_timestamp, to_timestamp, query):
        if from_timestamp in [None, "", "None"]:
            from_timestamp = int(time.mktime((datetime.now() - timedelta(days=7)).timetuple()))
        else:
            from_timestamp = int(time.mktime(parse_date(from_timestamp, fuzzy=True)))
        if to_timestamp in [None, "", "None"]:
            to_timestamp = int(time.mktime(datetime.now().timetuple()))
        else:
            to_timestamp = int(time.mktime(parse_date(to_timestamp, fuzzy=True)))

        if "path" in query.lower():
            query = re.escape(query)

        next_link = f"{self.SEARCH_URL}?startTime={from_timestamp}&endTime={to_timestamp}&top=50"
        results = []

        try:
            while next_link:
                LOG.info(f"Searching using the following params {next_link}  {query}")
                print(f"Searching using the following params {next_link}  {query}")
                response = self.tm.get(next_link, headers={"TMV1-Query": query})
                results = results + response.get("items", [])
                next_link = response.get("nextLink")
                if len(results) >= 50:
                    break
                if next_link:
                    next_link = next_link.replace(self.conf["server_selection"], "")
            return {
                "results": results
            }
        except Exception as e:
            return {
                "results": []
            }


class SearchEndpointActivityData(BaseSearchAction):
    SEARCH_URL = "/v3.0/search/endpointActivities"


class SearchDetectionData(BaseSearchAction):
    SEARCH_URL = "/v3.0/search/detections"

class SearchEmailActivityData(BaseSearchAction):
    SEARCH_URL = "/v3.0/search/emailActivities"

class SearchNetworkActivityData(BaseSearchAction):
    SEARCH_URL = "/v3.0/search/networkActivities"

