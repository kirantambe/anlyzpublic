from sporact_base.sporact_base_action import SporactBaseAction
from datetime import datetime, timedelta
import requests


class SearchForSource(SporactBaseAction):

    def run(self, from_timestamp, to_timestamp, source, query, conf):
        if not from_timestamp:
            from_timestamp = datetime.now() - timedelta(days=7)
            from_timestamp = from_timestamp.replace(microsecond=0).isoformat()
        if not to_timestamp:
            to_timestamp = datetime.now()
            to_timestamp = to_timestamp.replace(microsecond=0).isoformat()
        if source == "endpointActivityData":
            SEARCH_URL = "/v3.0/search/endpointActivities"
        elif source == "detections":
            SEARCH_URL = "/v3.0/search/detections"
        elif source == "cloudActivityData":
            SEARCH_URL = "/v3.0/search/cloudActivities"
        elif source == "emailActivityData":
            SEARCH_URL = "/v3.0/search/emailActivities"
        elif source == "mobileActivityData":
            SEARCH_URL = "/v3.0/search/mobileActivities"
        elif source == "containerActivityData":
            SEARCH_URL = "/v3.0/search/containerActivities"
        elif source == "identityAndAccessActivityData":
            SEARCH_URL = "/v3.0/search/identityActivities"
        elif source == "networkActivityData":
            SEARCH_URL = "/v3.0/search/networkActivities"
        else:
            return {
                "status": "error",
                "status_msg": str("Invalid Search Type"),
                "data": {}
            }
        params = {
            "startDateTime": from_timestamp,
            "endDateTime": to_timestamp
        }
        headers = {
            "Authorization": "Bearer " + conf.get("api_key"),
            "TMV1-Query": query,
            "Content-Type": "application/json;charset=utf-8",
        }
        try:
            return requests.get(conf.get("server_selection") + SEARCH_URL, headers=headers, params=params)
        except Exception as e:
            return {
                "status": "error",
                "status_msg": str(e),
                "data": {}
            }
