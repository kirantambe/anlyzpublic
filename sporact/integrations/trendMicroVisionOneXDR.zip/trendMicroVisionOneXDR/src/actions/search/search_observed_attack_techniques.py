from sporact_base.sporact_base_action import SporactBaseAction
from datetime import datetime, timedelta
import time
import requests
import json  # Import json to convert dict to string


class SearchObservedAttackTechniques(SporactBaseAction):
    def run(self, from_timestamp, to_timestamp, integration_dict, conf):
        if not from_timestamp:
            from_timestamp = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%dT%H:%M:%SZ')
        else:
            from_timestamp = from_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ')
        if not to_timestamp:
            to_timestamp = datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')
        else:
            to_timestamp = to_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ')

        query_params = {
            "detectedStartDateTime": from_timestamp,
            "detectedEndDateTime": to_timestamp,
            "top": 200
        }

        # Generate the dynamic TMV1-Filter based on integration_dict
        filter_conditions = []

        if integration_dict.get("riskLevels"):
            risk_levels = integration_dict["riskLevels"]
            risk_filter = " or ".join([f"riskLevel eq '{risk}'" for risk in risk_levels])
            filter_conditions.append(f"({risk_filter})")

        if integration_dict.get("endpointName"):
            filter_conditions.append(f"endpointName eq '{integration_dict['endpointName']}'")

        if "techniqueIds" in integration_dict and integration_dict["techniqueIds"]:
            filter_conditions.append(f"filterMitreTechniqueId eq '{integration_dict['techniqueIds']}'")

        if "tacticIds" in integration_dict and integration_dict["tacticIds"]:
            filter_conditions.append(f"filterMitreTacticId eq '{integration_dict['tacticIds']}'")

        # Join the filter conditions with ' and ' to form the final TMV1-Filter string
        tmv1_filter_str = " and ".join(filter_conditions) if filter_conditions else ""

        url = "/v3.0/oat/detections"
        headers = {
            "Authorization": "Bearer " + conf.get("api_key"),
            "TMV1-Filter": tmv1_filter_str  # Use the dynamically generated filter string
        }

        try:
            response = requests.get(conf.get("server_selection") + url, headers=headers, params=query_params)
            response.raise_for_status()  # Raise an HTTPError if the status code is 4xx or 5xx
            return response.json()
        except requests.exceptions.HTTPError as http_err:
            return {
                "status": "error",
                "status_msg": f"HTTP error occurred: {str(http_err)}",
                "data": {}
            }
        except Exception as e:
            return {
                "status": "error",
                "status_msg": str(e),
                "data": {}
            }
