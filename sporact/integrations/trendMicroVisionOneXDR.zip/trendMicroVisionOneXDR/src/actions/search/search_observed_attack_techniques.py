from sporact_base.sporact_base_action import SporactBaseAction
from datetime import datetime, timedelta
import time
import requests


class SearchObservedAttackTechniques(SporactBaseAction):
    def run(self, from_timestamp, to_timestamp, integration_dict, conf):
        if not from_timestamp:
            from_timestamp = int(time.mktime((datetime.now() - timedelta(days=7)).timetuple()))
        else:
            from_timestamp = int(time.mktime(from_timestamp.timetuple()))
        if not to_timestamp:
            to_timestamp = int(time.mktime(datetime.now().timetuple()))
        else:
            to_timestamp = int(time.mktime(to_timestamp.timetuple()))
        query_params = {"start": from_timestamp, "end": to_timestamp, "size": 200}
        if integration_dict["riskLevels"]:
            query_params["riskLevels"] = integration_dict["riskLevels"]
        if integration_dict["endpointName"] != "":
            query_params["endpointName"] = integration_dict["endpointName"]
        if "filterNames" in integration_dict:
            if integration_dict["filterNames"] != "":
                query_params["filterNames"] = integration_dict["filterNames"]
        if "techniqueIds" in integration_dict:
            if integration_dict["techniqueIds"] != "":
                query_params["techniqueIds"] = integration_dict["techniqueIds"]
        if "tacticIds" in integration_dict:
            if integration_dict["tacticIds"] != "":
                query_params["tacticIds"] = integration_dict["tacticIds"]

        url = "/v2.0/xdr/oat/detections"
        headers = {
            "Authorization": "Bearer " + conf.get("api_key")
        }
        try:
            return requests.get(conf.get("server_selection") + url, headers=headers, params=query_params)
        except Exception as e:
            return {
                "status": "error",
                "status_msg": str(e),
                "data": {}
            }
