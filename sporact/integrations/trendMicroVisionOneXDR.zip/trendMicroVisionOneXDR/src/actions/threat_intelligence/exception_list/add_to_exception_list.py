from ...base_tm_action import BaseTMAction

class BaseAddToSuspiciousObjectExceptionsList(BaseTMAction):
    VALUE_TYPE = ""

    def run(self, target_value):
        if not self.VALUE_TYPE:
            raise Exception("Incorrect targetValue. Only values of type "
                            "file_sha1, ip, domain, url, mailbox are supported")

        url = "/v3.0/threatintel/suspiciousObjectExceptions"

        response = self.tm.post(url, json= [{
            self.VALUE_TYPE: target_value,
        }])
        try:
            if response[0]["status"] == 201:
                return {"status":"succeeded"}
        except:
            pass
        return {"status":"failed"} 


class AddURLToSuspiciousObjectExceptionsList(BaseAddToSuspiciousObjectExceptionsList):
    VALUE_TYPE = "url"


class AddDomainToSuspiciousObjectExceptionsList(BaseAddToSuspiciousObjectExceptionsList):
    VALUE_TYPE = "domain"


class AddFileHashToSuspiciousObjectExceptionsList(BaseAddToSuspiciousObjectExceptionsList):
    VALUE_TYPE = "fileSha1"


class AddSenderMailAddressToSuspiciousObjectExceptionsList(BaseAddToSuspiciousObjectExceptionsList):
    VALUE_TYPE = "senderMailAddress"


class AddIPToSuspiciousObjectExceptionsList(BaseAddToSuspiciousObjectExceptionsList):
    VALUE_TYPE = "ip"