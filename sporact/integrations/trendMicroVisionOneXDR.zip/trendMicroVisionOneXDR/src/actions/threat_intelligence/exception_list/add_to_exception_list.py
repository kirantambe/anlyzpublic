from ...base_tm_action import BaseTMAction
from ...response_actions.base_response_action import BaseResponseAction


class BaseAddToSuspiciousObjectExceptionsList(BaseResponseAction):
    VALUE_TYPE = ""

    def run(self, target_value):
        if not self.VALUE_TYPE:
            raise Exception("Incorrect targetValue. Only values of type "
                            "file_sha1, ip, domain, url, mailbox are supported")

        url = "/v3.0/threatintel/suspiciousObjectExceptions"

        return self.send_request(url, [{
            self.VALUE_TYPE: target_value,
        }])


class AddURLToSuspiciousObjectExceptionsList(BaseAddToSuspiciousObjectExceptionsList):
    VALUE_TYPE = "url"


class AddDomainToSuspiciousObjectExceptionsList(BaseAddToSuspiciousObjectExceptionsList):
    VALUE_TYPE = "domain"


class AddFileHashToSuspiciousObjectExceptionsList(BaseAddToSuspiciousObjectExceptionsList):
    VALUE_TYPE = "fileSha1"


class AddSenderMailAddressToSuspiciousObjectExceptionsList(BaseAddToSuspiciousObjectExceptionsList):
    VALUE_TYPE = "senderMailAddress"


class AddIPToSuspiciousObjectExceptionsList(BaseAddToSuspiciousObjectExceptionsList):
    VALUE_TYPE = "ip"