from ...response_actions.base_response_action import BaseResponseAction

class BaseRemoveFromSuspiciousObjectExceptionsList(BaseResponseAction):
    VALUE_TYPE = ""

    def run(self, target_value):
        if not self.VALUE_TYPE:
            raise Exception("Incorrect targetValue. Only values of type "
                            "file_sha1, ip, domain, url, mailbox are supported")

        url = "/v3.0/threatintel/suspiciousObjectExceptions/delete"

        return self.send_request(url, [{
            self.VALUE_TYPE: target_value,
        }])


class RemoveURLFromSuspiciousObjectExceptionsList(BaseRemoveFromSuspiciousObjectExceptionsList):
    VALUE_TYPE = "url"


class RemoveDomainFromSuspiciousObjectExceptionsList(BaseRemoveFromSuspiciousObjectExceptionsList):
    VALUE_TYPE = "domain"


class RemoveFileHashFromSuspiciousObjectExceptionsList(BaseRemoveFromSuspiciousObjectExceptionsList):
    VALUE_TYPE = "fileSha1"


class RemoveSenderMailAddressFromSuspiciousObjectExceptionsList(BaseRemoveFromSuspiciousObjectExceptionsList):
    VALUE_TYPE = "senderMailAddress"


class RemoveIPFromSuspiciousObjectExceptionsList(BaseRemoveFromSuspiciousObjectExceptionsList):
    VALUE_TYPE = "ip"