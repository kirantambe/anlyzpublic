from ...base_tm_action import BaseTMAction

class BaseRemoveFromSuspiciousObjectExceptionsList(BaseTMAction):
    VALUE_TYPE = ""

    def run(self, target_value):
        if not self.VALUE_TYPE:
            raise Exception("Incorrect targetValue. Only values of type "
                            "file_sha1, ip, domain, url, mailbox are supported")

        url = "/v3.0/threatintel/suspiciousObjectExceptions/delete"

        response = self.tm.post(url, json= [{
            self.VALUE_TYPE: target_value,
        }])
        try:
            if response[0]["status"] == 204:
                return {"status":"succeeded"}
        except:
            pass
        return {"status":"failed"} 

class RemoveURLFromSuspiciousObjectExceptionsList(BaseRemoveFromSuspiciousObjectExceptionsList):
    VALUE_TYPE = "url"


class RemoveDomainFromSuspiciousObjectExceptionsList(BaseRemoveFromSuspiciousObjectExceptionsList):
    VALUE_TYPE = "domain"


class RemoveFileHashFromSuspiciousObjectExceptionsList(BaseRemoveFromSuspiciousObjectExceptionsList):
    VALUE_TYPE = "fileSha1"


class RemoveSenderMailAddressFromSuspiciousObjectExceptionsList(BaseRemoveFromSuspiciousObjectExceptionsList):
    VALUE_TYPE = "senderMailAddress"


class RemoveIPFromSuspiciousObjectExceptionsList(BaseRemoveFromSuspiciousObjectExceptionsList):
    VALUE_TYPE = "ip"