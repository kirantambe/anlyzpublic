import requests
import io
import time

from urllib.parse import urljoin

from ...base_tm_action import BaseTMAction


class AnalyzeFileInSandbox(BaseTMAction):
    def run(self, file_url, documentPassword, archivePassword):
        url = "/v2.0/xdr/sandbox/file"

        if not file_url.startswith("http"):
            file_url = urljoin(self.SPORACT_URL, file_url)

        response = requests.get(file_url)
        attachment = io.BytesIO(response.content)

        upload_file_response = self.tm.post(url, files={"file": attachment},
                                            data={
                                                "documentPassword": documentPassword,
                                                "archivePassword": archivePassword
                                            })
        task_id = upload_file_response.get("data", {}).get("taskId")

        if not task_id:
            raise Exception(f"Couldnt submit file to sandbox due to: {upload_file_response.get('message', 'error')}")

        # Wait until analysis completed
        retry_count = 0
        while True:
            status_response = self.tm.get(f"/v2.0/xdr/sandbox/tasks/{task_id}")
            task_status = status_response.get("data", {}).get("taskStatus")
            analysis_summary = status_response.get("data", {}).get("analysisSummary")
            if not task_status:
                raise Exception(f"Got empty task status from server")
            if task_status == "finished":
                return {
                    "report_id": status_response.get("data", {}).get("reportId"),
                    **analysis_summary
                }
            else:
                time.sleep(5)
            retry_count += 1
            if retry_count == 60:
                raise Exception(f"Analysis is taking too long to complete")

        raise Exception(f"Couldnt analyze file with sandbox, Reason: Result timed out")

