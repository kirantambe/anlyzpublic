import requests
import io
import time

from urllib.parse import urljoin

from ...base_tm_action import BaseTMAction


class AnalyzeFileInSandbox(BaseTMAction):
    def run(self, file_url, documentPassword, archivePassword):
        url = self.tm.base_url+"/v3.0/sandbox/files/analyze"

        if not file_url.startswith("http"):
            file_url = urljoin(self.SPORACT_URL, file_url)

        # Getting data from url
        response = requests.get(file_url)
        attachment = io.BytesIO(response.content)
        file = {'file': (file_url, attachment, 'application/octet-stream')}
        
        data = {
            "documentPassword": documentPassword,
            "archivePassword": archivePassword
        }
        if documentPassword in ["None", None, ""]:
            del data["documentPassword"]
        if archivePassword in ["None", None, ""]:
            del data["archivePassword"]
        headers = {
            "Authorization": "Bearer " + self.tm.token
        }
        
        #Submitting file for sandbox analysis
        upload_file_response = requests.post(url, headers=headers, files=file, data=data).json()
        task_id = upload_file_response.get("id","")

        if not task_id:
            raise Exception(f"Couldnt submit file to sandbox due to: {upload_file_response.get('error', 'error')}")

        # Wait until analysis completed
        retry_count = 0
        while True:
            # Getting analysis task status and returning the output once analysis is completed
            status_response = self.tm.get(f"/v3.0/sandbox/tasks/{task_id}")
            task_status = status_response.get("status")
            if not task_status:
                raise Exception(f"Got empty task status from server")
            if task_status == "succeeded":
                results = self.tm.get(f"/v3.0/sandbox/analysisResults/{task_id}")
                return {
                    "report_id": results.get("id"), "analysisCompletionTime": res.get("analysisCompletionDateTime"),
                    "riskLevel": results.get("riskLevel"), "description": "", "detectionNameList": results.get("detectionNames"),
                    "threatTypeList": results.get("threatTypeList"), "trueFileType": results.get("trueFileType")
                    
                }
            else:
                time.sleep(5)
            retry_count += 1
            if retry_count == 60:
                raise Exception(f"Analysis is taking too long to complete")
