from ....base_tm_action import BaseTMAction
from ...base_response_action import BaseResponseAction


class BaseAddToSuspiciousList(BaseResponseAction):
    VALUE_TYPE = ""

    def run(self, target_value):

        url = "/v3.0/threatintel/suspiciousObjects"

        return self.send_request(url, [{
            self.VALUE_TYPE: target_value,
        }])


class AddURLToSuspiciousList(BaseAddToSuspiciousList):
    VALUE_TYPE = "url"


class AddDomainToSuspiciousList(BaseAddToSuspiciousList):
    VALUE_TYPE = "domain"


class AddFileHashToSuspiciousList(BaseAddToSuspiciousList):
    VALUE_TYPE = "fileSha1"


class AddSenderMailAddressToSuspiciousList(BaseAddToSuspiciousList):
    VALUE_TYPE = "senderMailAddress"


class AddIPToSuspiciousList(BaseAddToSuspiciousList):
    VALUE_TYPE = "ip"