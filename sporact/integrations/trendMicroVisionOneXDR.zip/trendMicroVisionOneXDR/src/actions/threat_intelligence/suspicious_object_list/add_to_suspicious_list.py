from ...base_tm_action import BaseTMAction

class BaseAddToSuspiciousList(BaseTMAction):
    VALUE_TYPE = ""

    def run(self, target_value):

        url = "/v3.0/threatintel/suspiciousObjects"

        response = self.tm.post(url, json= [{
            self.VALUE_TYPE: target_value,
        }])
        try:
            if response[0]["status"] == 201:
                return {"status":"succeeded"}
        except:
            pass
        return {"status":"failed"} 


class AddURLToSuspiciousList(BaseAddToSuspiciousList):
    VALUE_TYPE = "url"


class AddDomainToSuspiciousList(BaseAddToSuspiciousList):
    VALUE_TYPE = "domain"


class AddFileHashToSuspiciousList(BaseAddToSuspiciousList):
    VALUE_TYPE = "fileSha1"


class AddSenderMailAddressToSuspiciousList(BaseAddToSuspiciousList):
    VALUE_TYPE = "senderMailAddress"


class AddIPToSuspiciousList(BaseAddToSuspiciousList):
    VALUE_TYPE = "ip"