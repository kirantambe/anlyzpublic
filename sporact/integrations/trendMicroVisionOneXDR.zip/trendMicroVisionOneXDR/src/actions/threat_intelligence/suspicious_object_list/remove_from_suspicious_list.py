from ...base_tm_action import BaseTMAction


class BaseRemoveFromSuspiciousList(BaseTMAction):
    VALUE_TYPE = ""

    def run(self, target_value):

        url = "/v3.0/threatintel/suspiciousObjects/delete"

        response = self.tm.post(url, json= [{
            self.VALUE_TYPE: target_value,
        }])
        try:
            if response[0]["status"] == 204:
                return {"status":"succeeded"}
        except:
            pass
        return {"status":"failed"}  


class RemoveURLFromSuspiciousList(BaseRemoveFromSuspiciousList):
    VALUE_TYPE = "url"


class RemoveDomainFromSuspiciousList(BaseRemoveFromSuspiciousList):
    VALUE_TYPE = "domain"


class RemoveFileHashFromSuspiciousList(BaseRemoveFromSuspiciousList):
    VALUE_TYPE = "fileSha1"


class RemoveSenderMailAddressFromSuspiciousList(BaseRemoveFromSuspiciousList):
    VALUE_TYPE = "senderMailAddress"


class RemoveIPFromSuspiciousList(BaseRemoveFromSuspiciousList):
    VALUE_TYPE = "ip"