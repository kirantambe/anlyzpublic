from ....base_tm_action import BaseTMAction
from ...base_response_action import BaseResponseAction


class BaseRemoveFromSuspiciousList(BaseResponseAction):
    VALUE_TYPE = ""

    def run(self, target_value):

        url = "/v3.0/threatintel/suspiciousObjects/delete"

        return self.send_request(url, [{
            self.VALUE_TYPE: target_value,
        }])


class RemoveURLFromSuspiciousList(BaseRemoveFromSuspiciousList):
    VALUE_TYPE = "url"


class RemoveDomainFromSuspiciousList(BaseRemoveFromSuspiciousList):
    VALUE_TYPE = "domain"


class RemoveFileHashFromSuspiciousList(BaseRemoveFromSuspiciousList):
    VALUE_TYPE = "fileSha1"


class RemoveSenderMailAddressFromSuspiciousList(BaseRemoveFromSuspiciousList):
    VALUE_TYPE = "senderMailAddress"


class RemoveIPFromSuspiciousList(BaseRemoveFromSuspiciousList):
    VALUE_TYPE = "ip"