import io
import random
import string
import time
from datetime import datetime
import requests
import urllib.parse

from ..base_tm_action import BaseTMAction



class Sweep(BaseTMAction):
    def run(self, type, object, description=""):
        results = {}
        file_content = f"Type,Object,Description,ValidFrom\n{type},{object},{description},{datetime.utcnow().isoformat()}\n".encode()

        url = urllib.parse.urljoin(self.conf.get("server_selection"), "/v3.0/threatintel/intelligenceReports")

        headers = {
            "Authorization": "Bearer " + self.conf.get("api_key"),
        }

        attachment = io.BytesIO(file_content)
        report_name = 'soar_' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
        files = {
            'file': (
                f'{report_name}.csv', attachment, 'text/csv')
        }
        upload_file_response = requests.post(url, files=files, data={"reportName": report_name}, headers=headers)

        if upload_file_response.status_code == 207:
            response_json = upload_file_response.json()
            report_id = None
            for item in response_json:
                if item.get("status") == 201:
                    for header in item.get("headers", []):
                        if header.get("name") == "Location":
                            report_url = header.get("value")
                            report_id = report_url.split("/")[-1]

            if report_id:
                # Sweep
                sweep_url = "/v3.0/threatintel/intelligenceReports/sweep"
                body = [
                    {
                        'id': report_id,
                        'sweepType': 'manual',
                    }
                ]
                sweep_response = self.tm.post(sweep_url, json=body)
                sweep_id = None
                for item in sweep_response:
                    if item.get("status") == 202:
                        for header in item.get("headers", []):
                            if header.get("name") == "Operation-Location":
                                sweep_operation_url = header.get("value")
                                sweep_id = sweep_operation_url.split("/")[-1]
                if sweep_id:
                    task_result = None
                    task_result_url = f"/v3.0/threatintel/tasks/{sweep_id}"
                    while not task_result:
                        task_result_json = self.tm.get(task_result_url)
                        print("")
                        if task_result_json.get("status") in ["succeeded", "failed"]:
                            task_result = task_result_json

                        else:
                            time.sleep(3)
                    results = {
                        "status": "success",
                        "data": task_result
                    }
                else:
                    results = {
                        "status": "failed",
                        "data": sweep_response or "Unable to get Sweep ID"
                    }
                # Delete Report
                delete_url = '/v3.0/threatintel/intelligenceReports/delete'
                self.tm.post(delete_url, json=[{"id": report_id}])
                pass
            else:
                results = {
                    "status": "failed",
                    "data": response_json or "Unable to get Report ID"
                }
        else:
            results = {
                "status": "failed",
                "data": upload_file_response.json()
            }
        return results