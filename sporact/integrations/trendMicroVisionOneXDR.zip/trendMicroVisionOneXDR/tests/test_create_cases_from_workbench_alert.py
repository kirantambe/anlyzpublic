from src.actions.case_creation_actions.create_cases_from_workbench_alerts import CreateCasesFromWorkbenchAlerts
import unittest


class TestCreateCasesFromWorkbenchAlerts(unittest.TestCase):
    def test(self):
        action = CreateCasesFromWorkbenchAlerts({"conf": {"api_key": "<api_key>"}})
        result = action.run()
        print(result)
        
