import requests
import json

from sporact_base.sporact_base_action import SporactBaseAction


class AddAttachment(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        self.SPORACT_URL = "http://api:8000/api/"

    def run(self, url):
        return {
            "status": "success",
            "message": "Attachment added"
        }