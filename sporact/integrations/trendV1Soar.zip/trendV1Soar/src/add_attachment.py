import requests
import json
import os

from sporact_base.sporact_base_action import SporactBaseAction


class AddAttachment(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        API_HOST = os.environ.get("API_PROXY_NAME", "api")
        API_PORT = os.environ.get("API_PROXY_PORT", "8000")
        self.SPORACT_URL = f"http://{API_HOST}:{API_PORT}/api/"

    def run(self, url):
        return {
            "status": "success",
            "message": "Attachment added"
        }