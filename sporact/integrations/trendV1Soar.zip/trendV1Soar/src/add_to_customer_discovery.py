import requests
import json

from sporact_base.sporact_base_action import SporactBaseAction


class AddToCustomerDiscovery(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        self.SPORACT_URL = "http://api:8000/api/"

    def run(self, asset_type, value, description, category):
        access_token = self.sporact.get("api_key")
        headers = {
            "Content-Type": "application/json",
            "X-Api-Key": f"{access_token}",
        }
        payload = json.dumps(
            {
                "asset_type": asset_type,
                "value": value,
                "description": description,
                "extra_data": {
                    "category": category
                }
            }
        )
        response = requests.request(
            'POST',
            f'{self.SPORACT_URL}customer_discovery/assets/',
            headers=headers,
            data=payload
        )
        if response.status_code == 201:
            return {
                "status": "success",
                "message": "Added to customer discovery"
            }
        return {
            "status": "error",
            "message": f"Failed to add to customer discovery due to {response.content}"
        }
