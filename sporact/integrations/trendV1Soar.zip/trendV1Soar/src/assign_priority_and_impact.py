import requests
import json

from sporact_base.sporact_base_action import SporactBaseAction


class AssignPriorityAndImpact(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        self.SPORACT_URL = "http://api:8000/api/"

    def run(self, priority, impact):
        access_token = self.sporact.get("api_key")
        headers = {
            "Content-Type": "application/json",
            "X-Api-Key": f"{access_token}",
        }
        payload = json.dumps(
            {"impact": impact, "priority": priority, "added_by_playbook": True}
        )
        response = requests.request(
            'PATCH',
            '{}cases/case/{}/'.format(self.SPORACT_URL, self.case.get('uid')),
            headers=headers,
            data=payload
        )
        if response.status_code == 200:
            return response.json()