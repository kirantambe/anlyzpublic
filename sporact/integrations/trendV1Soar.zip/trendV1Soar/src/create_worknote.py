import json
from copy import deepcopy

import requests
from jinja2 import Environment
from jinja2.ext import Extension
from jinja2.lexer import Token
from json2html import *
from sporact_base.sporact_base_action import SporactBaseAction


def _is_uniform(data):
    """
    Given a list of lists, check if the length of each row is same
    :param data: list of lists
    :return:
    """
    base_len = len(data[0])
    return all([len(row) == base_len for row in data])


def _list_to_dict(l):
    """
    converts a list into a dict
    eg:
    ['123', 'john', '12 buckingham palace road']
    will be converted to
    {'label_0': 123, 'label_1': 'john', label_2: '12 buckingham palace road'}
    :param l:
    :return:
    """
    return dict([(f"label_{i}", val) for i, val in enumerate(l)])


def list_dict_to_table_filter(input):
    """Custom filter"""
    table_attributes = "class='info-table'"
    if isinstance(input, list):
        first = input[0]
        if isinstance(first, dict):
            data = json2html.convert(
                json=input, encode=False, table_attributes=table_attributes
            )
            data = f"<div class='info-table-container'>{data}</div>"
        elif isinstance(first, list):
            if _is_uniform(input):
                try:
                    data = json2html.convert(
                        json=[_list_to_dict(row) for row in input],
                        encode=False,
                        table_attributes=table_attributes,
                    )
                    data = f"<div class='info-table-container'>{data}</div>"
                except:
                    data = input
            else:
                data = input
        else:
            data = input
    else:
        data = input
    return data


class ListDictTable(Extension):

    tags = set(["listdicttable"])

    def filter_stream(self, stream):
        variable_done = False
        in_trans = False
        in_variable = False
        for token in stream:
            # Check if we are inside a trans block - we cannot use filters there!
            if token.type == "block_begin":
                block_name = stream.current.value
                if block_name == "trans":
                    in_trans = True
                elif block_name == "endtrans":
                    in_trans = False
            elif token.type == "variable_begin":
                in_variable = True

            if not in_trans and in_variable:
                if token.type == "pipe":
                    # Inject our filter call before the first filter
                    yield Token(token.lineno, "pipe", "|")
                    yield Token(token.lineno, "name", "list_dict_to_table_filter")
                    variable_done = True
                elif token.type == "variable_end" or (
                    token.type == "name" and token.value == "if"
                ):
                    if not variable_done:
                        # Inject our filter call if we haven't injected it right after the variable
                        yield Token(token.lineno, "pipe", "|")
                        yield Token(token.lineno, "name", "list_dict_to_table_filter")
                    variable_done = False

            if token.type == "variable_end":
                in_variable = False

            # Original token
            yield token


class CreateWorknoteAction(SporactBaseAction):
    def __init__(self, extracontent):

        super().__init__(extracontent)
        self.init_jinja()
        self.SPORACT_URL = "http://api:8000/api/"

    def init_jinja(self):
        self.jinja_env = Environment(extensions=[ListDictTable])
        self.jinja_env.filters["list_dict_to_table_filter"] = list_dict_to_table_filter

    def run(self, note, context):
        template = note
        note_template = self.jinja_env.from_string(template)
        new_context = deepcopy(context)
        new_context.pop("conf")
        new_context.pop("has_worknote")
        new_context.pop("__execution")
        new_context.pop("__env")
        new_context.pop("worknote")
        new_context.pop("note")
        new_context.pop("context")
        note = note_template.render({"context": new_context})
        payload = json.dumps(
            {"case": self.case.get("id"), "note": note, "is_first_response": False}
        )
        access_token = self.sporact.get("api_key")
        headers = {
            "Content-Type": "application/json",
            "X-Api-Key": f"{access_token}",
        }
        response = requests.request(
            "POST",
            f"{self.SPORACT_URL}cases/{self.case.get('uid')}/worknote/",
            headers=headers,
            data=payload,
        )
        if not response.status_code == 201:
            raise Exception(f"Failed to add worknote to case {self.case.get('uid')}")
