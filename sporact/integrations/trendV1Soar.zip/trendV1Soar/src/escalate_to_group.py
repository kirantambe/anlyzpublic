import requests
import json

from sporact_base.sporact_base_action import SporactBaseAction


class EscalateToGroupAction(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        self.SPORACT_URL = "http://api:8000/api/"

    def run(self, group):
        access_token = self.sporact.get("api_key")
        headers = {
            "Content-Type": "application/json",
            "X-Api-Key": f"{access_token}",
        }
        payload = json.dumps(
            {"assigned_to_group": group}
        )
        response = requests.request(
            'PATCH',
            '{}cases/case/{}/'.format(self.SPORACT_URL, self.case.get('uid')),
            headers=headers,
            data=payload
        )
        if response.status_code == 200:
            return response.json()
        self.LOG.error(b"%%%% Could not escalate due to {response.status_code} {response.content}")
        raise Exception(response.content)
        