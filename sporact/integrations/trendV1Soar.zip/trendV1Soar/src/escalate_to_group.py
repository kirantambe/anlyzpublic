import requests
import json
import os

from sporact_base.sporact_base_action import SporactBaseAction


class EscalateToGroupAction(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        API_HOST = os.environ.get("API_PROXY_NAME", "api")
        API_PORT = os.environ.get("API_PROXY_PORT", "8000")
        self.SPORACT_URL = f"http://{API_HOST}:{API_PORT}/api/"

    def run(self, group):
        access_token = self.sporact.get("api_key")
        headers = {
            "Content-Type": "application/json",
            "X-Api-Key": f"{access_token}",
        }
        payload = json.dumps(
            {"assigned_to_group": group}
        )
        response = requests.request(
            'PATCH',
            '{}cases/case/{}/'.format(self.SPORACT_URL, self.case.get('uid')),
            headers=headers,
            data=payload
        )
        if response.status_code == 200:
            return response.json()
        self.LOG.error(b"%%%% Could not escalate due to {response.status_code} {response.content}")
        raise Exception(response.content)
        