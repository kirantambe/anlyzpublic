from sporact_base.sporact_base_action import SporactBaseAction
import urllib.request
import hashlib


class GetHashFromFile(SporactBaseAction):

    def run(self, url):
        ext = url.split('.')
        with urllib.request.urlopen(url) as response, open('file.'+ext.pop(), 'wb'):
            data = response.read()
        md5Hash = hashlib.md5(data).hexdigest()
        sha1Hash = hashlib.sha1(data).hexdigest()
        sha256Hash = hashlib.sha256(data).hexdigest()
        sha512Hash = hashlib.sha512(data).hexdigest()
        return {
            "md5Hash": md5Hash,
            "sha1Hash": sha1Hash,
            "sha256Hash": sha256Hash,
            "sha512Hash": sha512Hash
        }
