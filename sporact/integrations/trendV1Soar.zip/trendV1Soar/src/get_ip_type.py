import ipaddress

from sporact_base.sporact_base_action import SporactBaseAction


class GetIPTypeAction(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)

    def run(self, ip):
        return {
            "ip_type": 'PRIVATE' if ipaddress.ip_address(ip).is_private else 'PUBLIC',
            "ip": ip
        }