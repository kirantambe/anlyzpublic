import re
from sporact_base.sporact_base_action import SporactBaseAction


class MatchTextToRegex(SporactBaseAction):
    """
            Match the given regex pattern with the input text.

            Args:
                regex (str): The regular expression pattern.
                text (str): The text to match against the regex.

            Returns:
                bool: True if the text matches the regex, False otherwise.
            """

    def run(self, regex, text):
        pattern = re.compile(regex)
        matches = pattern.findall(text)
        return {"matches": bool(matches)}
