import requests
import os

from sporact_base.sporact_base_action import SporactBaseAction


class QueryCustomerDiscoveryAction(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        API_HOST = os.environ.get("API_PROXY_NAME", "api")
        API_PORT = os.environ.get("API_PROXY_PORT", "8000")
        self.SPORACT_URL = f"http://{API_HOST}:{API_PORT}/api/"

    def run(self, query):
        access_token = self.sporact.get("api_key")
        headers = {
            "Content-Type": "application/json",
            "X-Api-Key": f"{access_token}",
        }
        response = requests.request(
            'GET',
            '{}customer_discovery/assets/search/?query={}&exact=true'.format(self.SPORACT_URL, query),
            headers=headers
        )
        if response.status_code == 200:
            response_json = response.json()

            if len(response_json):
                response_json = response_json[0]
            else:
                return {
                    "asset_type": "",
                    "value": "",
                    "description": "",
                    "extra_data": "",
                }

            return {
                "asset_type": response_json.get("asset_type_display"),
                "value": response_json.get("value"),
                "description": response_json.get("description"),
                "extra_data": response_json.get("extra_data", {}),
            }
