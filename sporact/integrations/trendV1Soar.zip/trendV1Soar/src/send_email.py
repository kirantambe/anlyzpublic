import os
import ast
import smtplib
from email.mime.text import MIMEText
import string
import pathlib
import logging
import json
from json2html import *
from sporact_base.sporact_base_action import SporactBaseAction

log = logging.getLogger(__name__)


def _is_uniform(data):
    """
    Given a list of lists, check if the length of each row is same
    :param data: list of lists
    :return:
    """
    if not data:
        return True
    base_len = len(data[0])
    return all([len(row) == base_len for row in data])


def _list_to_dict(l):
    """
    Converts a list into a dict
    :param l: List to be converted
    :return: Dict representation of list
    """
    return dict([(f"label_{i}", val) for i, val in enumerate(l)])


def _dict_to_list_of_dicts(d):
    """
    Converts a dictionary into a list of dictionaries, each with a single key-value pair
    :param d: Dictionary to be converted
    :return: List of dictionaries
    """
    return [{key: value} for key, value in d.items()]


def find_json_end(input_str, start_index):
    """
    Finds the end index of a JSON object or array in a string.
    """
    brace_count = 0
    square_bracket_count = 0
    in_string = False

    for i in range(start_index, len(input_str)):
        if input_str[i] == '{' and not in_string:
            brace_count += 1
        elif input_str[i] == '}' and not in_string:
            brace_count -= 1
            if brace_count == 0:
                return i
        elif input_str[i] == '[' and not in_string:
            square_bracket_count += 1
        elif input_str[i] == ']' and not in_string:
            square_bracket_count -= 1
            if square_bracket_count == 0:
                return i
        elif input_str[i] == '"' and input_str[i - 1] != '\\':
            in_string = not in_string

    return -1  # Indicates no valid end found


def process_mixed_content(input_str):
    """
    Processes a string with mixed JSON and non-JSON content.
    Converts JSON parts to HTML tables and keeps non-JSON parts as they are.
    """
    output = ""
    i = 0
    while i < len(input_str):
        if input_str[i] in '{[':
            json_end = find_json_end(input_str, i)
            if json_end != -1:
                try:
                    json_obj = json.loads(input_str[i:json_end + 1].replace("'", "\""))
                    if isinstance(json_obj, list):
                        if all(isinstance(elem, list) for elem in json_obj) and _is_uniform(json_obj):
                            json_obj = [_list_to_dict(row) for row in json_obj]
                    output += json2html.convert(json=json_obj, table_attributes="class='info-table'")
                    i = json_end + 1
                    continue
                except json.JSONDecodeError:
                    pass  # If JSON parsing fails, treat as normal text

        output += input_str[i]
        i += 1

    return output


def list_dict_to_table_filter(input):
    """
    Custom filter for converting mixed JSON and non-JSON content to HTML.
    """
    if isinstance(input, str):
        data = process_mixed_content(input)
    elif isinstance(input, dict):
        data = json2html.convert(json=input, table_attributes="class='info-table'")
    elif isinstance(input, list) and all(isinstance(elem, list) for elem in input) and _is_uniform(input):
        data = json2html.convert(json=[_list_to_dict(row) for row in input], table_attributes="class='info-table'")
    else:
        data = input
    return f"<div class='info-table-container'>{data}</div>"


class SendEmail(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        self.SPORACT_URL = "http://api:8000/api/"

    def run(self, subject, recipients, message):
        if isinstance(recipients, str):
            try:
                recipients_new = ast.literal_eval(recipients)
                if not isinstance(recipients_new, list):
                    raise ValueError("Recipients should be a list.")
            except:
                recipients_new = recipients.split(",")
        else:
            recipients_new = recipients
        self.send_email(subject, recipients_new, message)
        return {
            "status": "success",
            "message": "Email Sent"
        }

    def get_base_template_context(self,
                                  subject="",
                                  logo_base64="",
                                  company_name="",
                                  main_message=""
                                  ):
        return {
            "logo": logo_base64,
            "subject": subject,
            "companyName": company_name,
            "mainMessage": main_message,
        }

    def send_email(self, subject, recipients, message):
        email_settings = self.sporact.get("email_settings")
        white_labelling_settings = self.sporact.get("white_labelling_settings")
        message = message.replace("\n", "<br>")
        try:
            message = list_dict_to_table_filter(input=message)
        except:
            pass
        context = self.get_base_template_context(subject=subject,
                                                 main_message=message,
                                                 logo_base64=white_labelling_settings.get("logo"),
                                                 company_name=white_labelling_settings.get("company_name"))
        # Read the HTML template file
        cur_dir = pathlib.Path(__file__).parent.resolve()
        template_path = os.path.join(cur_dir, "templates/base_email.html")
        with open(template_path, "r") as file:
            template_content = file.read()

        # Create a Template and substitute the context
        template = string.Template(template_content)
        email_html_message = template.safe_substitute(context)
        msg = MIMEText(email_html_message, "html")
        msg['From'] = email_settings.get("sender_email") or email_settings.get('email_host_user')
        msg['To'] = ', '.join(recipients)
        msg['Subject'] = subject

        try:
            if email_settings.get("email_use_ssl", False):
                smtp = smtplib.SMTP_SSL(host=email_settings.get("email_host"), port=email_settings.get("email_port"))
            else:
                smtp = smtplib.SMTP(host=email_settings.get("email_host"), port=email_settings.get("email_port"))
                if email_settings.get("email_use_tls"):
                    smtp.starttls()

            smtp.ehlo()
            if email_settings.get("email_host_user") and email_settings.get("email_host_password"):
                smtp.login(email_settings.get("email_host_user"), email_settings.get("email_host_password"))

            smtp.sendmail(msg['From'], recipients, msg.as_string())
            smtp.quit()
        except Exception as e:
            print(f"An error occurred: {e}")
