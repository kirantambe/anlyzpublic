CONFIG = {
    "sporact": {
        "api_key": "API key here",
    },
    "case": {
      "uid": "DCP627"
    }
}