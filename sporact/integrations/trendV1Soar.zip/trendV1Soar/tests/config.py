CONFIG = {
    "sporact": {
        "api_key": "<API-key>",
    },
    "case": {
        "uid": "<uid>"
    }
}
