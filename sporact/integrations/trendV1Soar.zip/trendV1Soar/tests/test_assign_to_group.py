from src.assign_to_group import AssignToGroup
from .config import CONFIG
import unittest


class TestAssignToGroup(unittest.TestCase):

    def test_assign_to_group(self):
        action = AssignToGroup(CONFIG)
        res = action.run('testGroup')
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)