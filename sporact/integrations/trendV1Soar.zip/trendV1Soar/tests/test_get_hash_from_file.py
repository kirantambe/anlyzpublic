from src.get_hash_from_file import GetHashFromFile
from .config import CONFIG
import unittest


class TestGetHashFromFile(unittest.TestCase):

    def test_update_case_field(self):
        action = GetHashFromFile(CONFIG)
        result = action.run('https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf')
        assert "md5Hash" in result and "sha1Hash" in result and "sha256Hash" in result and "sha512Hash" in result