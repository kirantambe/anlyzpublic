from src.match_text_to_regex import MatchTextToRegex
import unittest
# from .config import CONFIG

class TestCreateCaseFromIncidentsAction(unittest.TestCase):

    def test_create_case_from_incidents_action(self):

        regex = "^[a-zA-Z0-9_]*$"
        text = "example_text123"

        action = MatchTextToRegex({"conf": {"api_key": ""}})
        result = action.run(regex,text)
        print(result)