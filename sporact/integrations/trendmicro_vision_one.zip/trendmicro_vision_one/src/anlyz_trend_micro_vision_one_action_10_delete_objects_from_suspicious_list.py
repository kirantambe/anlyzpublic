from sporact_base.sporact_base_action import SporactBaseAction
import requests
import json
class Anlyz_TrendMicroVisionOneAction_DeleteObjectsFromSuspiciousList(SporactBaseAction):
	def run(self,anlyz_trend_micro_vision_one_type,anlyz_trend_micro_vision_one_value):
		api_key = self.conf.get('api_key')
		base_url = self.conf.get('base_url')
		url_suffix = '/v2.0/xdr/threatintel/suspiciousObjects/delete'
		final_url = base_url + url_suffix
		query_params = {}
		proxies = {
            "http": None  # No Proxy configuration
        }
		headers = {
			'Authorization': 'Bearer ' + api_key,
			'Content-Type': 'application/json;charset=utf-8'
			}
		body = {'data': [{'type': anlyz_trend_micro_vision_one_type, 'value': anlyz_trend_micro_vision_one_value}]}
		try:
			req_delete_objects_from_suspicious_list = requests.post(url=final_url, params=query_params, verify=False, proxies=proxies, json=body, headers=headers)
			if 'application/json' in req_delete_objects_from_suspicious_list.headers.get('Content-Type', '') and len(req_delete_objects_from_suspicious_list.content):
				json_output = req_delete_objects_from_suspicious_list.json()
		except Exception as e: 
			json_output = {"output":str(e)}
		return {
			"anlyz_trend_micro_vision_one_action_10_delete_objects_from_suspicious_list_output": json_output
			}
    