from sporact_base.sporact_base_action import SporactBaseAction
import requests
import json
class Anlyz_TrendMicroVisionOneAction_CollectForensicFile(SporactBaseAction):
	def run(self,anlyz_trend_micro_vision_one_end_point_id,anlyz_trend_micro_vision_one_product_id,anlyz_trend_micro_vision_one_file_path,anlyz_trend_micro_vision_os,anlyz_trend_micro_vision_one_description):
		api_key = self.conf.get('api_key')
		base_url = self.conf.get('base_url')
		url_suffix = '/v2.0/xdr/response/collectFile'
		final_url = base_url + url_suffix
		query_params = {}
		proxies = {
            "http": None  # No Proxy configuration
        }
		headers = {
			'Authorization': 'Bearer ' + api_key,
			'Content-Type': 'application/json;charset=utf-8'
			}
		body = {'description': anlyz_trend_micro_vision_one_description,
				'productId': anlyz_trend_micro_vision_one_product_id,
				'computerId': anlyz_trend_micro_vision_one_end_point_id,
				'filePath': anlyz_trend_micro_vision_one_file_path,
				'os': anlyz_trend_micro_vision_os
				}
		try:
			req_collect_forensic_file = requests.post(url=final_url, params=query_params, verify=False, proxies=proxies, json=body, headers=headers)
			if 'application/json' in req_collect_forensic_file.headers.get('Content-Type', '') and len(req_collect_forensic_file.content):
				json_output = req_collect_forensic_file.json()
		except Exception as e: 
			json_output = {"output":str(e)}
		return {
			"anlyz_trend_micro_vision_one_action_15_collect_forensic_file_output": json_output
			}
    