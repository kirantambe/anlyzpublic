from sporact_base.sporact_base_action import SporactBaseAction
import requests
import json
class Anlyz_TrendMicroVisionOneAction_SubmitFileToSandbox(SporactBaseAction):
	def run(self,anlyz_trend_micro_vision_one_file_url,anlyz_trend_micro_vision_one_file_name,anlyz_trend_micro_vision_one_document_password,anlyz_trend_micro_vision_one_archive_password):
		api_key = self.conf.get('api_key')
		base_url = self.conf.get('base_url')
		url_suffix = '/v2.0/xdr/sandbox/file'
		final_url = base_url + url_suffix
		query_params = {}
		proxies = {
            "http": None  # No Proxy configuration
        }
		headers = {
			'Authorization': 'Bearer' + api_key,
			'Content-Type': 'application/json;charset=utf-8'
			}
		data = {
				'documentPassword': anlyz_trend_micro_vision_one_document_password,
    			'archivePassword': anlyz_trend_micro_vision_one_archive_password
				}
		files = {'file': (anlyz_trend_micro_vision_one_file_name, open(anlyz_trend_micro_vision_one_file_url, 'rb'), 'application/octet-stream')}
		try:
			req_submit_file_to_sandbox = requests.post(url=final_url, params=query_params, verify=False, proxies=proxies, json=data,files=files, headers=headers)
			if 'application/json' in req_submit_file_to_sandbox.headers.get('Content-Type', '') and len(req_submit_file_to_sandbox.content):
				json_output = req_submit_file_to_sandbox.json()
		except Exception as e: 
			json_output = {"output":str(e)}
		return {
			"anlyz_trend_micro_vision_one_action_17_submit_file_to_sandbox_output": json_output
		}
    