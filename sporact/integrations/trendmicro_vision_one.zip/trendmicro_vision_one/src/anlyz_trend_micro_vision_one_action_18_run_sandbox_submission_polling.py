from sporact_base.sporact_base_action import SporactBaseAction
import requests
import json
class Anlyz_TrendMicroVisionOneAction_RunSandboxSubmissionPolling(SporactBaseAction):
	def run(self,anlyz_trend_micro_vision_one_task_id):
		api_key = self.conf.get('api_key')
		base_url = self.conf.get('base_url')
		url_suffix = '/v2.0/xdr/sandbox/tasks/{}'.format(anlyz_trend_micro_vision_one_task_id)
		final_url = base_url + url_suffix
		query_params = {}
		proxies = {
            "http": None  # No Proxy configuration
        }
		headers = {
			'Authorization': 'Bearer ' + api_key,
			'Content-Type': 'application/json;charset=utf-8'
			}
		try:
			req_run_sandbox_submission_polling = requests.get(url=final_url, params=query_params, verify=False, proxies=proxies,headers=headers)
			if 'application/json' in req_run_sandbox_submission_polling.headers.get('Content-Type', '') and len(req_run_sandbox_submission_polling.content):
				json_output = req_run_sandbox_submission_polling.json()
		except Exception as e: 
			json_output = {"output":str(e)}
		return {
			"anlyz_trend_micro_vision_one_action_18_run_sandbox_submission_polling_output": json_output
			}
    