from sporact_base.sporact_base_action import SporactBaseAction
import requests
import json
class Anlyz_TrendMicroVisionOneAction_AddNote(SporactBaseAction):
	def run(self,anlyz_trend_micro_vision_one_work_bench_id,anlyz_trend_micro_vision_one_content):
		api_key = self.conf.get('api_key')
		base_url = self.conf.get('base_url')
		url_suffix = '/v2.0/xdr/workbench/workbenches/{}/notes'.format(anlyz_trend_micro_vision_one_work_bench_id)
		final_url = base_url + url_suffix
		query_params = {}
		proxies = {
            "http": None  # No Proxy configuration
        }
		headers = {
			'Authorization': 'Bearer ' + api_key,
			'Content-Type': 'application/json;charset=utf-8'
			}
		
		body = {'content': anlyz_trend_micro_vision_one_content}

		try:
			req_add_note = requests.post(url=final_url, params=query_params, verify=False, proxies=proxies, json=body,headers=headers)
			if 'application/json' in req_add_note.headers.get('Content-Type', '') and len(req_add_note.content):
				json_output = req_add_note.json()
		except Exception as e: 
			json_output = {"output":str(e)}
		return {
			"anlyz_trend_micro_vision_one_action_20_add_note_output": json_output
			}
    