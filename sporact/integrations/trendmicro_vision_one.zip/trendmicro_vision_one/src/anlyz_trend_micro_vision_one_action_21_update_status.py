from sporact_base.sporact_base_action import SporactBaseAction
import requests
import json
class Anlyz_TrendMicroVisionOneAction_UpdateStatus(SporactBaseAction):
	def run(self,anlyz_trend_micro_vision_one_work_bench_id,anlyz_trend_micro_vision_one_status):
		api_key = self.conf.get('api_key')
		base_url = self.conf.get('base_url')
		url_suffix = '/v2.0/xdr/workbench/workbenches/{}'.format(anlyz_trend_micro_vision_one_work_bench_id)
		final_url = base_url + url_suffix
		query_params = {}
		proxies = {
            "http": None  # No Proxy configuration
        }
		headers = {
			'Authorization': 'Bearer ' + api_key,
			'Content-Type': 'application/json;charset=utf-8'
			}
		body = {'investigationStatus': anlyz_trend_micro_vision_one_status}
		try:
			req_update_status = requests.put(url=final_url, params=query_params, verify=False, proxies=proxies, json=body,headers=headers)
			if 'application/json' in req_update_status.headers.get('Content-Type', '') and len(req_update_status.content):
				json_output = req_update_status.json()
		except Exception as e: 
			json_output = {"output":str(e)}
		return {
			"anlyz_trend_micro_vision_one_action_21_update_status_output": json_output
			}
    