from sporact_base.sporact_base_action import SporactBaseAction
import requests
import json
class Anlyz_TrendMicroVisionOneAction_RemoveFromBlockList(SporactBaseAction):
	def run(self,anlyz_trend_micro_vision_one_value_type,anlyz_trend_micro_vision_one_target_value,anlyz_trend_micro_vision_one_product_id,anlyz_trend_micro_vision_one_description):
		api_key = self.conf.get('api_key')
		base_url = self.conf.get('base_url')
		url_suffix = '/v2.0/xdr/response/restoreBlock'
		final_url = base_url + url_suffix 
		query_params = {}
		proxies = {
            "http": None  # No Proxy configuration
		}
		headers = {'Authorization': 'Bearer '+api_key,'Content-Type': 'application/json;charset=utf-8'}
		body = {
			'valueType': anlyz_trend_micro_vision_one_value_type,
			'targetValue': anlyz_trend_micro_vision_one_target_value,
			'productId': anlyz_trend_micro_vision_one_product_id,
			'description': anlyz_trend_micro_vision_one_description
		}
		try:
			req_remove_from_block_list = requests.post(url=final_url,params=query_params,verify=False,proxies=proxies,json=body,headers=headers)
			if 'application/json' in req_remove_from_block_list.headers.get('Content-Type', '') and len(req_remove_from_block_list.content):
				json_output = req_remove_from_block_list.json()
		except Exception as e: 
			json_output = {"output":str(e)}
		return {
			"anlyz_trend_micro_vision_one_action_2_remove_from_block_list_output": json_output
			}
    