from sporact_base.sporact_base_action import SporactBaseAction
import requests
import json
class Anlyz_TrendMicroVisionOneAction_DeleteEmailMessage(SporactBaseAction):
	def run(self,anlyz_trend_micro_vision_one_message_id,anlyz_trend_micro_vision_one_mailbox,anlyz_trend_micro_vision_one_message_delivery_time,anlyz_trend_micro_vision_one_product_id,anlyz_trend_micro_vision_one_description):
		api_key = self.conf.get('api_key')
		base_url = self.conf.get('base_url')
		url_suffix = 'v2.0/xdr/response/deleteMessage'
		final_url = base_url + url_suffix 
		query_params = {}
		proxies = {
            "http": None  # No Proxy configuration
		}
		headers = {'Authorization': 'Bearer '+ api_key,'Content-Type': 'application/json;charset=utf-8'}
		body = {'messageId': anlyz_trend_micro_vision_one_message_id,
				'mailBox': anlyz_trend_micro_vision_one_mailbox,
				'messageDeliveryTime': anlyz_trend_micro_vision_one_message_delivery_time,
				'productId': anlyz_trend_micro_vision_one_product_id,
				'description': anlyz_trend_micro_vision_one_description
				}
		try:
			req_delete_email_message = requests.post(url=final_url,params=query_params,verify=False,proxies=proxies,json=body,headers=headers)
			if 'application/json' in req_delete_email_message.headers.get('Content-Type', '') and len(req_delete_email_message.content):
				json_output = req_delete_email_message.json()
		except Exception as e: 
			json_output = {"output":str(e)}
		return {
			"anlyz_trend_micro_vision_one_action_4_delete_email_message_output": json_output
			}
    