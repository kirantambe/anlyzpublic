from sporact_base.sporact_base_action import SporactBaseAction
import requests
import json
class Anlyz_TrendMicroVisionOneAction_RestoreEndPointConnection(SporactBaseAction):
	def run(self,anlyz_trend_micro_vision_one_end_point_id,anlyz_trend_micro_vision_one_product_id,anlyz_trend_micro_vision_one_description):
		api_key = self.conf.get('api_key')
		base_url = self.conf.get('base_url')
		url_suffix = 'v2.0/xdr/response/restoreIsolate'
		final_url = base_url + url_suffix 
		query_params = {}
		proxies = {
            "http": None  # No Proxy configuration
		}
		headers = {'Authorization': 'Bearer '+ api_key,'Content-Type': 'application/json;charset=utf-8'}
		body = {'computerId': anlyz_trend_micro_vision_one_end_point_id,
				'productId': anlyz_trend_micro_vision_one_product_id,
				'description': anlyz_trend_micro_vision_one_description
				}		
		try:
			req_restore_endpoint_connection = requests.post(url=final_url,params=query_params,verify=False,proxies=proxies,json=body,headers=headers)
			if 'application/json' in req_restore_endpoint_connection.headers.get('Content-Type', '') and len(req_restore_endpoint_connection.content):
				json_output = req_restore_endpoint_connection.json()
		except Exception as e: 
			json_output = {"output":str(e)}
		return {
			"anlyz_trend_micro_vision_one_action_6_restore_endpoint_connection_output": json_output
			}
    