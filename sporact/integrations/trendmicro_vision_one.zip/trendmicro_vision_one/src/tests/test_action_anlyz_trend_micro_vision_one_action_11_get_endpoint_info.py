from src.anlyz_trend_micro_vision_one_action_11_get_endpoint_info import Anlyz_TrendMicroVisionOneAction_GetEndPointInfo
import unittest

class Test_Anlyz_TrendMicroVisionOneAction_GetEndPointInfo(unittest.TestCase):
	def test_anlyz_trend_micro_vision_one_action_11_get_endpoint_info(self):
		api_key = ""
		base_url = 'https://api.xdr.trendmicro.com'
		anlyz_trend_micro_vision_one_end_point_id = ""
		action = Anlyz_TrendMicroVisionOneAction_GetEndPointInfo({'conf': {'api_key': api_key, 'base_url': base_url}})
		result = action.run(anlyz_trend_micro_vision_one_end_point_id)
		self.assertTrue(result)
    