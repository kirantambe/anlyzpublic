from src.anlyz_trend_micro_vision_one_action_12_terminate_process import Anlyz_TrendMicroVisionOneAction_TerminateProcess
import unittest

class Test_Anlyz_TrendMicroVisionOneAction_TerminateProcess(unittest.TestCase):
	def test_anlyz_trend_micro_vision_one_action_12_terminate_process(self):
		api_key = ""
		base_url = 'https://api.xdr.trendmicro.com'
		anlyz_trend_micro_vision_one_end_point_id = "" 
		anlyz_trend_micro_vision_one_file_sha1 = "" 
		anlyz_trend_micro_vision_one_product_id = "" 
		anlyz_trend_micro_vision_one_description = "" 
		anlyz_trend_micro_vision_one_file_name = ""
		action = Anlyz_TrendMicroVisionOneAction_TerminateProcess({'conf': {'api_key': api_key, 'base_url': base_url}})
		result = action.run(anlyz_trend_micro_vision_one_end_point_id,anlyz_trend_micro_vision_one_file_sha1,anlyz_trend_micro_vision_one_product_id,anlyz_trend_micro_vision_one_description,anlyz_trend_micro_vision_one_file_name)
		self.assertTrue(result)
    