from src.anlyz_trend_micro_vision_one_action_14_get_file_analysis_report import Anlyz_TrendMicroVisionOneAction_GetFileAnalysisReport
import unittest

class Test_Anlyz_TrendMicroVisionOneAction_GetFileAnalysisReport(unittest.TestCase):
	def test_anlyz_trend_micro_vision_one_action_14_get_file_analysis_report(self):
		api_key = ""
		base_url = 'https://api.xdr.trendmicro.com'
		anlyz_trend_micro_vision_one_report_id = "" 
		anlyz_trend_micro_vision_one_type = ""
		action = Anlyz_TrendMicroVisionOneAction_GetFileAnalysisReport({'conf': {'api_key': api_key, 'base_url': base_url}})
		result = action.run(anlyz_trend_micro_vision_one_report_id,anlyz_trend_micro_vision_one_type)
		self.assertTrue(result)
    