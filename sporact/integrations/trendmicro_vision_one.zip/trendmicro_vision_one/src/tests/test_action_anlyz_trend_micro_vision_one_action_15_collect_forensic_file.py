from src.anlyz_trend_micro_vision_one_action_15_collect_forensic_file import Anlyz_TrendMicroVisionOneAction_CollectForensicFile
import unittest

class Test_Anlyz_TrendMicroVisionOneAction_CollectForensicFile(unittest.TestCase):
	def test_anlyz_trend_micro_vision_one_action_15_collect_forensic_file(self):
		api_key = ""
		base_url = 'https://api.xdr.trendmicro.com'
		anlyz_trend_micro_vision_one_end_point_id = "" 
		anlyz_trend_micro_vision_one_product_id = "" 
		anlyz_trend_micro_vision_one_file_path = "" 
		anlyz_trend_micro_vision_os = "" 
		anlyz_trend_micro_vision_one_description = ""
		action = Anlyz_TrendMicroVisionOneAction_CollectForensicFile({'conf': {'api_key': api_key, 'base_url': base_url}})
		result = action.run(anlyz_trend_micro_vision_one_end_point_id,anlyz_trend_micro_vision_one_product_id,anlyz_trend_micro_vision_one_file_path,anlyz_trend_micro_vision_os,anlyz_trend_micro_vision_one_description)
		self.assertTrue(result)
    