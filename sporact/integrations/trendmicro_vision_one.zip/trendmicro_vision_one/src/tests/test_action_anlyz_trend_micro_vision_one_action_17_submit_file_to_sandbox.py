from src.anlyz_trend_micro_vision_one_action_17_submit_file_to_sandbox import Anlyz_TrendMicroVisionOneAction_SubmitFileToSandbox
import unittest

class Test_Anlyz_TrendMicroVisionOneAction_SubmitFileToSandbox(unittest.TestCase):
	def test_anlyz_trend_micro_vision_one_action_17_submit_file_to_sandbox(self):
		api_key = ""
		base_url = 'https://api.xdr.trendmicro.com'
		anlyz_trend_micro_vision_one_file_url = "/Users/sandhyaguntuku//Downloads/xampprunfile.txt" 
		anlyz_trend_micro_vision_one_file_name = "xampprunfile.txt" 
		anlyz_trend_micro_vision_one_document_password = "" 
		anlyz_trend_micro_vision_one_archive_password = ""
		action = Anlyz_TrendMicroVisionOneAction_SubmitFileToSandbox({'conf': {'api_key': api_key, 'base_url': base_url}})
		result = action.run(anlyz_trend_micro_vision_one_file_url,anlyz_trend_micro_vision_one_file_name,anlyz_trend_micro_vision_one_document_password,anlyz_trend_micro_vision_one_archive_password)
		self.assertTrue(result)
    