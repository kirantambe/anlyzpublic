from src.anlyz_trend_micro_vision_one_action_18_run_sandbox_submission_polling import Anlyz_TrendMicroVisionOneAction_RunSandboxSubmissionPolling
import unittest

class Test_Anlyz_TrendMicroVisionOneAction_RunSandboxSubmissionPolling(unittest.TestCase):
	def test_anlyz_trend_micro_vision_one_action_18_run_sandbox_submission_polling(self):
		api_key = ""
		base_url = 'https://api.xdr.trendmicro.com'
		anlyz_trend_micro_vision_one_task_id = ""
		action = Anlyz_TrendMicroVisionOneAction_RunSandboxSubmissionPolling({'conf': {'api_key': api_key, 'base_url': base_url}})
		result = action.run(anlyz_trend_micro_vision_one_task_id)
		self.assertTrue(result)
    