from src.anlyz_trend_micro_vision_one_action_19_check_task_status import Anlyz_TrendMicroVisionOneAction_CheckTaskStatus
import unittest

class Test_Anlyz_TrendMicroVisionOneAction_CheckTaskStatus(unittest.TestCase):
	def test_anlyz_trend_micro_vision_one_action_19_check_task_status(self):
		api_key = ""
		base_url = 'https://api.xdr.trendmicro.com'
		anlyz_trend_micro_vision_one_action_id = ""
		action = Anlyz_TrendMicroVisionOneAction_CheckTaskStatus({'conf': {'api_key': api_key, 'base_url': base_url}})
		result = action.run(anlyz_trend_micro_vision_one_action_id)
		self.assertTrue(result)
    