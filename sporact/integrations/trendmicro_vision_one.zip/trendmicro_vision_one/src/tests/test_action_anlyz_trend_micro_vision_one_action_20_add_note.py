from src.anlyz_trend_micro_vision_one_action_20_add_note import Anlyz_TrendMicroVisionOneAction_AddNote
import unittest

class Test_Anlyz_TrendMicroVisionOneAction_AddNote(unittest.TestCase):
	def test_anlyz_trend_micro_vision_one_action_20_add_note(self):
		api_key = ""
		base_url = 'https://api.xdr.trendmicro.com'
		anlyz_trend_micro_vision_one_work_bench_id = "" 
		anlyz_trend_micro_vision_one_content = ""
		action = Anlyz_TrendMicroVisionOneAction_AddNote({'conf': {'api_key': api_key, 'base_url': base_url}})
		result = action.run(anlyz_trend_micro_vision_one_work_bench_id,anlyz_trend_micro_vision_one_content)
		self.assertTrue(result)
    