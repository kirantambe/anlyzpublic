from src.anlyz_trend_micro_vision_one_action_2_remove_from_block_list import Anlyz_TrendMicroVisionOneAction_RemoveFromBlockList
import unittest

class Test_Anlyz_TrendMicroVisionOneAction_RemoveFromBlockList(unittest.TestCase):
	def test_anlyz_trend_micro_vision_one_action_2_remove_from_block_list(self):
		api_key = ""
		base_url = 'https://api.xdr.trendmicro.com'
		anlyz_trend_micro_vision_one_value_type = "" 
		anlyz_trend_micro_vision_one_target_value = ""  
		anlyz_trend_micro_vision_one_product_id = "" 
		anlyz_trend_micro_vision_one_description = ""
		action = Anlyz_TrendMicroVisionOneAction_RemoveFromBlockList({'conf': {'api_key': api_key, 'base_url': base_url}})
		result = action.run(anlyz_trend_micro_vision_one_value_type,anlyz_trend_micro_vision_one_target_value,anlyz_trend_micro_vision_one_product_id,anlyz_trend_micro_vision_one_description)
		self.assertTrue(result)
    