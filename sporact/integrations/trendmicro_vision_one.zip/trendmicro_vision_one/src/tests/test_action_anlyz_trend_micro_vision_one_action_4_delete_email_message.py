from src.anlyz_trend_micro_vision_one_action_4_delete_email_message import Anlyz_TrendMicroVisionOneAction_DeleteEmailMessage
import unittest

class Test_Anlyz_TrendMicroVisionOneAction_DeleteEmailMessage(unittest.TestCase):
	def test_anlyz_trend_micro_vision_one_action_4_delete_email_message(self):
		api_key = ""
		base_url = 'https://api.xdr.trendmicro.com'
		anlyz_trend_micro_vision_one_message_id = "" 
		anlyz_trend_micro_vision_one_mailbox = "" 
		anlyz_trend_micro_vision_one_message_delivery_time = "" 
		anlyz_trend_micro_vision_one_product_id = "" 
		anlyz_trend_micro_vision_one_description = ""
		action = Anlyz_TrendMicroVisionOneAction_DeleteEmailMessage({'conf': {'api_key': api_key, 'base_url': base_url}})
		result = action.run(anlyz_trend_micro_vision_one_message_id,anlyz_trend_micro_vision_one_mailbox,anlyz_trend_micro_vision_one_message_delivery_time,anlyz_trend_micro_vision_one_product_id,anlyz_trend_micro_vision_one_description)
		self.assertTrue(result)
    