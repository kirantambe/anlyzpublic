from src.anlyz_trend_micro_vision_one_action_6_restore_endpoint_connection import Anlyz_TrendMicroVisionOneAction_RestoreEndPointConnection
import unittest

class Test_Anlyz_TrendMicroVisionOneAction_RestoreEndPointConnection(unittest.TestCase):
	def test_anlyz_trend_micro_vision_one_action_6_restore_endpoint_connection(self):
		api_key = ""
		base_url = 'https://api.xdr.trendmicro.com'
		anlyz_trend_micro_vision_one_end_point_id = "" 
		anlyz_trend_micro_vision_one_product_id = "" 
		anlyz_trend_micro_vision_one_description = ""
		action = Anlyz_TrendMicroVisionOneAction_RestoreEndPointConnection({'conf': {'api_key': api_key, 'base_url': base_url}})
		result = action.run(anlyz_trend_micro_vision_one_end_point_id,anlyz_trend_micro_vision_one_product_id,anlyz_trend_micro_vision_one_description)
		self.assertTrue(result)
    