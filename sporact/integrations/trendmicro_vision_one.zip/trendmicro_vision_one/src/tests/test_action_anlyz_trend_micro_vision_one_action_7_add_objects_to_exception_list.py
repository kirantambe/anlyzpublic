from src.anlyz_trend_micro_vision_one_action_7_add_objects_to_exception_list import Anlyz_TrendMicroVisionOneAction_AddObjectsToExceptionList
import unittest

class Test_Anlyz_TrendMicroVisionOneAction_AddObjectsToExceptionList(unittest.TestCase):
	def test_anlyz_trend_micro_vision_one_action_7_add_objects_to_exception_list(self):
		api_key = ""
		base_url = 'https://api.xdr.trendmicro.com'
		anlyz_trend_micro_vision_one_type = "" 
		anlyz_trend_micro_vision_one_value = 0 
		anlyz_trend_micro_vision_one_description = ""
		action = Anlyz_TrendMicroVisionOneAction_AddObjectsToExceptionList({'conf': {'api_key': api_key, 'base_url': base_url}})
		result = action.run(anlyz_trend_micro_vision_one_type,anlyz_trend_micro_vision_one_value,anlyz_trend_micro_vision_one_description)
		self.assertTrue(result)
    