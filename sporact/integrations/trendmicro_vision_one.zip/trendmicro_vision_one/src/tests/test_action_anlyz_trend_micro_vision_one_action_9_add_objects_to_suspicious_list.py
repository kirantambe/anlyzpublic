from src.anlyz_trend_micro_vision_one_action_9_add_objects_to_suspicious_list import Anlyz_TrendMicroVisionOneAction_AddObjectsToSuspiciousList
import unittest

class Test_Anlyz_TrendMicroVisionOneAction_AddObjectsToSuspiciousList(unittest.TestCase):
	def test_anlyz_trend_micro_vision_one_action_9_add_objects_to_suspicious_list(self):
		api_key = ""
		base_url = 'https://api.xdr.trendmicro.com'
		anlyz_trend_micro_vision_one_type = ""  
		anlyz_trend_micro_vision_one_value = 0 
		anlyz_trend_micro_vision_one_description = "" 
		anlyz_trend_micro_vision_scan_action = "" 
		anlyz_trend_micro_vision_risk_level = 0 
		anlyz_trend_micro_vision_expiry_days = 0
		action = Anlyz_TrendMicroVisionOneAction_AddObjectsToSuspiciousList({'conf': {'api_key': api_key, 'base_url': base_url}})
		result = action.run(anlyz_trend_micro_vision_one_type,anlyz_trend_micro_vision_one_value,anlyz_trend_micro_vision_one_description,anlyz_trend_micro_vision_scan_action,anlyz_trend_micro_vision_risk_level,anlyz_trend_micro_vision_expiry_days)
		self.assertTrue(result)
    