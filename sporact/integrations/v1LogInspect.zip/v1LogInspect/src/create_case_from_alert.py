import requests
import json
import re
from sporact_base.sporact_base_action import SporactBaseAction
from dateutil.parser import parse as parse_date
import logging
from copy import deepcopy

log = logging.getLogger(__name__)


class CreateCaseFromAlert(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        self.SPORACT_URL = "http://api:8000/api/"

    def process_case_data(self, case):
        case_dict = deepcopy(case)
        extra_field_names = case_dict.pop("fields")
        case_dict["extra_data"] = {}
        for alert in case.get("events", []):
            for field_name in extra_field_names:
                field_value = alert.get(field_name)
                if field_value:
                    if field_name in case_dict["extra_data"]:
                        case_dict["extra_data"][field_name] = case_dict["extra_data"][field_name] + ", " + field_value
                    else:
                        case_dict["extra_data"][field_name] = field_value
        try:
            case_dict["extra_data"]["policy_name"] = re.sub("\[.+\] ", "", case_dict.get("title", "")).strip()
        except Exception as e:
            log.info("Failed to set policy name")

        return case_dict

    def run(self, data):
        access_token = self.sporact.get("api_key")
        headers = {"Content-Type": "application/json", "X-Api-Key": f"{access_token}"}
        case = self.process_case_data(data)
        log.info(f"Got new alert from Cyberal: {case['title']}")

        response = requests.request(
            "POST",
            "{}cases/case/".format(self.SPORACT_URL),
            data=json.dumps(case),
            headers=headers,
        )
        if response.status_code == 201:
            resp = response.json()
            resp["response_code"] = 1
            return resp
        else:
            return {"message": response.reason, "response_code": 0}
