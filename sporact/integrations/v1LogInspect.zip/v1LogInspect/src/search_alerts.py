import json
import requests
from datetime import datetime, timedelta
from sporact_base.sporact_base_action import SporactBaseAction


class SearchAlerts(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
    

    def run(self, days_before, keyword, number_of_results):
        instance_api_key, instance_url, tenant_api_key = self.conf.get(
            "instance_api_key"), self.conf.get("instance_url"), self.conf.get("tenant_api_key")
                    
        if number_of_results=="None" or number_of_results=="":
            number_of_results = 5
                
        from_date = self.get_from_date(days_before)
        to_date = self.get_to_date()
        payload = self.get_payload(tenant_api_key, from_date, to_date, keyword, int(number_of_results))
        
        # Constructing the URL for the API endpoint that will be used to perform an external search for events.
        url = f"{instance_url.rstrip('/')}/api/alerts/external_search/"

        headers = {
            'X-EXTERNAL-API-KEY': instance_api_key,
            'Content-Type': 'application/json'
            }
        
        # Making a POST request to the specified `url` with the provided `headers` and `payload` data.
        response = requests.request("POST", url, headers=headers, data=payload)
        if response.status_code== 200:
            try:    
                response_data = response.json()['search_results'][0][tenant_api_key]['data']
                alerts = {i+1: data for i, data in enumerate(response_data)}
                
                return {"alerts": alerts}
            except Exception as e:

                return {"message": "Error in getting Alerts"}
    
    
    def get_to_date(self):    
        parsed_date = datetime.strftime(datetime.utcnow(), "%Y-%m-%dT%H:%M:%S.000Z")        
        
        return parsed_date


    def get_from_date(self, days_before):
        if days_before=="None" or days_before=="":
            parsed_date = datetime.strftime((datetime.utcnow()-timedelta(1)), "%Y-%m-%dT%H:%M:%S.000Z")
        else:
            parsed_date = datetime.strftime(datetime.utcnow()-timedelta(float(days_before)), "%Y-%m-%dT%H:%M:%S.000Z")
        
        return parsed_date


    def get_payload(self, tenant_api_key, from_date, to_date, keyword, number_of_results):
        if keyword=="None" or keyword=="":
            query = []
            search_type = "multi_search"
        else:
            query = [{"value": keyword}]
            search_type = "sql"

        payload = json.dumps({
            "tenants": [tenant_api_key
                        ],
            "from_datetime": from_date,
            "to_datetime": to_date,
            "query": query,
            "search_type": search_type,
            "page": 0,
            "page_size": number_of_results,
            "search_before": {
                tenant_api_key: [],
                },
            "search_after": {
                tenant_api_key: [],
                },
            "last": {
                tenant_api_key: False,
                }
            })
        
        return payload