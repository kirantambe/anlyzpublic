import requests
from sporact_base.sporact_base_action import SporactBaseAction


class TestIntegration(SporactBaseAction):
    def run(self, conf, inputs):
        # Domain format should be google.com. Just google will not work
        response_dict = (("message", "Successfully tested the configuration!"), ("status", "success"))
        return response_dict
