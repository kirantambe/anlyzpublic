import requests
from sporact_base.sporact_base_action import SporactBaseAction


class GetFileReportAction(SporactBaseAction):

    def run(self, resource):
        headers = {'x-apikey': self.conf.get("api_key")}
        url = "https://www.virustotal.com/api/v3/files/{}".format(resource)
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            attributes = response.json().get('data', {}).get('attributes', {})
            last_analysis_stats = attributes.get("last_analysis_stats", {})
            last_analysis_stats['total'] = sum(last_analysis_stats.values())
            attributes["last_analysis_stats"] = last_analysis_stats
            attributes['response_code'] = response.status_code
            return attributes
        return {
            "response_code": 0,
            "reputation": 0,
            "tags": [],
            "total_votes": {},
            "last_analysis_date": 0,
            "last_analysis_results": {"msg": response.reason},
            "last_analysis_stats": {},
            "first_submission_date": 0,
            "last_modification_date": 0,
            "last_submission_date": 0,
            "magic": "",
            "md5": "",
            "meaningful_name": 0,
            "names": [],
            "nsrl_info": {},
            "sha1": "",
            "sha256": "",
            "size": 0,
            "ssdeep": "",
            "times_submitted": 0,
            "trid": [],
            "trusted_verdict": {},
            "type_description": "",
            "unique_sources": 0,
            "wireshark": {}
        }
