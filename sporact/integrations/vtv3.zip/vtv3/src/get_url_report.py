import base64

import requests
from sporact_base.sporact_base_action import SporactBaseAction


class GetUrlReportAction(SporactBaseAction):
    def run(self, resource):
        headers = {"x-apikey": self.conf.get("api_key")}
        url = "https://www.virustotal.com/api/v3/urls/{}".format(
            base64.urlsafe_b64encode(resource.encode("ascii"))
            .strip(b"=")
            .decode("ascii")
        )
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            attributes = response.json().get("data", {}).get("attributes", {})
            last_analysis_stats = attributes.get("last_analysis_stats", {})
            last_analysis_stats["total"] = sum(last_analysis_stats.values())
            attributes["last_analysis_stats"] = last_analysis_stats
            attributes["response_code"] = response.status_code
            return attributes

        return {
            "response_code": 0,
            "reputation": 0,
            "tags": [],
            "total_votes": {},
            "last_analysis_date": 0,
            "last_analysis_results": {"msg": response.reason},
            "last_analysis_stats": {},
            "categories": {},
            "first_submission_date": 0,
            "html_meta": {},
            "last_final_url": "",
            "last_modification_date": "",
            "last_submission_date": 0,
            "targeted_brand": {},
            "times_submitted": 0,
            "trackers": {},
            "url": ""
        }
