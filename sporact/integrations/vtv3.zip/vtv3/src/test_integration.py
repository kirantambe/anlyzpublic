import requests
from sporact_base.sporact_base_action import SporactBaseAction


class TestIntegration(SporactBaseAction):
    def run(self, conf, inputs):
        # Domain format should be google.com. Just google will not work
        domain = inputs[0]["value"]
        headers = {"x-apikey": conf.get("api_key")}
        url = "https://virustotal.com/api/v3/domains/{}".format(domain)
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            response_dict = (("message", "Successfully tested the configuration!"), ("status", "success"))
        else:
            response_dict = (("message", "Invalid configuration!"), ("status", "failed"))
        return response_dict
