from src.get_domain_report import GetDomainReportAction
from .config import VT_API_KEY
import unittest


class TestGetDomainReportAction(unittest.TestCase):
    def test_get_domain_report(self):
        action = GetDomainReportAction({"api_key": VTV3_API_KEY})
        res = action.run("google")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
