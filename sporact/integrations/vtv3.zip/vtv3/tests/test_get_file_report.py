from src.get_file_report import GetFileReportAction
from .config import VT_API_KEY
import unittest


class TestGetIPReportAction(unittest.TestCase):
    def test_get_file_report(self):
        action = GetFileReportAction({"api_key": VTV3_API_KEY})
        res = action.run("fdb4b4520034be269a65cfaee555c52e")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
