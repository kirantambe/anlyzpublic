from src.get_ip_report import GetIPReportAction
from .config import VT_API_KEY
import unittest


class TestGetIPReportAction(unittest.TestCase):
    def test_get_ip_report(self):
        action = GetIPReportAction({
            'api_key': VTV3_API_KEY
        })
        res = action.run('104.27.163.228')
        self.assertTrue('response_code' in res)
        self.assertEqual(res.get('response_code'), 200)