from src.get_url_report import GetUrlReportAction
from .config import VT_API_KEY
import unittest


class TestGetIPReportAction(unittest.TestCase):
    def test_get_url_report(self):
        action = GetUrlReportAction({"api_key": VTV3_API_KEY})
        res = action.run("http://alegroup.info/ntnrrhst")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
