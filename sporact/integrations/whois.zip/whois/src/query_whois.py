import requests
from sporact_base.sporact_base_action import SporactBaseAction


class QueryWhoIsAction(SporactBaseAction):

    def run(self, domain):
        url = "https://jsonwhois.com/api/v1/whois"
        headers = {
            "Accept": "application/json",
            "Authorization": "Token token={}".format(self.conf.get("api_key")),
        }
        params = {"domain": domain}
        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            resp = response.json()
            resp["response_code"] = response.status_code
            return resp
        raise Exception(response.reason)
