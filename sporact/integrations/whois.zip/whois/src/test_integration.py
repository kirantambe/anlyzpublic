import requests
from sporact_base.sporact_base_action import SporactBaseAction


class TestIntegration(SporactBaseAction):
    def run(self, conf, inputs):
        # Domain format should be google.com. Just google will not work
        domain = inputs[0]["value"]
        params = {"domain": domain}
        headers = {
            "Accept": "application/json",
            "Authorization": "Token token={}".format(conf.get("api_key")),
        }
        url = "https://jsonwhois.com/api/v1/whois"
        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            if "domain" in response.json():
                 response_dict = (("message", "Successfully tested the configuration!"), ("status", "success"))
                 return response_dict
            response_dict = (("message", "Invalid configuration!"), ("status", "failed"))

        else:
            response_dict = (("message", "Invalid configuration!"), ("status", "failed"))
        return response_dict