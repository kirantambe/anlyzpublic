from src.query_whois import QueryWhoIsAction
from .config import WHOIS_API_KEY
import unittest


class TestQueryWhoIsAction(unittest.TestCase):
    def test_query_whois(self):
        action = QueryWhoIsAction({"api_key": WHOIS_API_KEY})
        res = action.run("google.com")
        self.assertTrue("response_code" in res)
        self.assertEqual(res.get("response_code"), 200)
