import datetime

import requests
import logging
from sporact_base.sporact_base_action import SporactBaseAction

LOG = logging.getLogger(__name__)
# default settings
V1_URL = "https://api.xdr.trendmicro.com"


def check_datetime_aware(d):
    return (d.tzinfo is not None) and (d.tzinfo.utcoffset(d) is not None)


class TmV1Client:
    base_url_default = V1_URL
    WB_STATUS_IN_PROGRESS = 1

    def __init__(self, token, base_url=None):
        if not token:
            raise ValueError("Authentication token missing")
        self.token = token
        self.base_url = base_url or TmV1Client.base_url_default

    def make_headers(self):
        return {
            "Authorization": "Bearer " + self.token,
            "Content-Type": "application/json;charset=utf-8",
        }

    def get(self, path, **kwargs):
        kwargs.setdefault("headers", {}).update(self.make_headers())
        r = requests.get(self.base_url + path, **kwargs)
        if (200 == r.status_code) and (
                "application/json" in r.headers.get("Content-Type", "")
        ):
            return r.json()
        try:
            rjson = r.json()
            message = rjson["error"]["message"]
            raise RuntimeError(message)
        except:
            raise RuntimeError(
                f"Request unsuccessful (GET {path}):" f" {r.status_code} {r.text}"
            )

    def put(self, path, **kwargs):
        kwargs.setdefault("headers", {}).update(self.make_headers())
        r = requests.put(self.base_url + path, **kwargs)
        if (200 == r.status_code) and (
                "application/json" in r.headers.get("Content-Type", "")
        ):
            return r.json()

        try:
            rjson = r.json()
            message = rjson["error"]["message"]
            raise RuntimeError(message)
        except:
            raise RuntimeError(
                f"Request unsuccessful (PUT {path}):" f" {r.status_code} {r.text}"
            )

    def post(self, path, **kwargs):
        LOG.info(f"Making post request to {path} with parameters: {kwargs}")
        kwargs.setdefault("headers", {}).update(self.make_headers())
        r = requests.post(self.base_url + path, **kwargs)
        if (200 == r.status_code) and (
                "application/json" in r.headers.get("Content-Type", "")
        ):
            return r.json()

        try:
            rjson = r.json()
            message = rjson["error"]["message"]
            raise RuntimeError(message)
        except:
            raise RuntimeError(
                f"Request unsuccessful (POST {path}):" f" {r.status_code} {r.text}"
            )

    def get_siem(self, start, end, offset=None, size=None):
        if not check_datetime_aware(start):
            start = start.astimezone()
        if not check_datetime_aware(end):
            end = end.astimezone()
        start = start.astimezone(datetime.timezone.utc)
        end = end.astimezone(datetime.timezone.utc)
        start = start.isoformat(timespec="milliseconds").replace("+00:00", "Z")
        end = end.isoformat(timespec="milliseconds").replace("+00:00", "Z")
        # API returns data in the range of [offset, offset+limit)
        return self.get(
            "/v2.0/siem/events",
            params=dict(
                [("startDateTime", start), ("endDateTime", end)]
                + ([("offset", offset)] if offset is not None else [])
                + ([("limit", size)] if size is not None else [])
            ),
        )["data"]["workbenchRecords"]

    def get_workbench(self, workbench_id):
        return self.get(f"/v2.0/xdr/workbench/workbenches/{workbench_id}")["data"]

    def update_workbench(self, workbench_id, status):
        return self.put(
            f"/v2.0/xdr/workbench/workbenches/{workbench_id}",
            json={"investigationStatus": status},
        )


class BaseTMAction(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        if "server_selection" in self.conf:
            server_selection = self.conf.get("server_selection")
        else:
            server_selection = None
        self.tm = TmV1Client(self.conf.get("api_key"), server_selection)
