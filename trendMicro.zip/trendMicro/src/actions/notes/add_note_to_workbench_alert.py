import requests
from ..base_tm_action import BaseTMAction


class AddNoteToWorkbenchAlert(BaseTMAction):
    def run(self, workbench_id, content):
        return {"result": self.tm.post(f"/v2.0/xdr/workbench/workbenches/{workbench_id}/notes", json={"content": content}).get("info", {"code": 0, "msg": "ERROR"})}
