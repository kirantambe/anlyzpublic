import requests
import json

from sporact_base.sporact_base_action import SporactBaseAction


class CaseStatusToInProgressAction(SporactBaseAction):
    def __init__(self, extracontent):
        super().__init__(extracontent)
        self.SPORACT_URL = "http://api:8000/api/"

    def run(self, status):
        access_token = self.sporact.get("api_key")
        headers = {
            "Content-Type": "application/json",
            "X-Api-Key": f"{access_token}",
        }
        STATUS_CODES = {"In Progress": 2}
        print("status",status)
        print("status",type(status))
        if status in [None, "", "None"]:
            case_status = 2
        else:
            case_status = STATUS_CODES[status]
        payload = json.dumps(
            {"status": case_status, "added_by_playbook": True}
        )
        response = requests.request(
            'PATCH',
            '{}cases/case/{}/'.format(self.SPORACT_URL, self.case.get('uid')),
            headers=headers,
            data=payload
        )
        if response.status_code == 200:
            return response.json()